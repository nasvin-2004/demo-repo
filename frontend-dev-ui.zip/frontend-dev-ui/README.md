# QConnect - College Management Platform

QConnect is a comprehensive college management platform designed to streamline academic operations, enhance student engagement, and improve communication between students, faculty, and administration.

## Features

- **Student Management**: Complete student lifecycle management from enrollment to graduation
- **Academic Tracking**: Real-time progress monitoring and performance analytics
- **Role-based Access**: Secure access control for students, faculty, and administrators
- **Communication Hub**: Integrated messaging and notification system
- **Assignment Management**: Digital assignment submission and grading system
- **User Management**: Comprehensive user administration and profile management
- **Contact System**: Built-in support and communication channels

## Technology Stack

- **Frontend**: Astro with React components
- **Styling**: Tailwind CSS
- **Backend**: Node.js with Fastify
- **Database**: Prisma ORM with PostgreSQL
- **Authentication**: JWT-based authentication
- **Deployment**: Docker containerization

## Getting Started

### Prerequisites

- Node.js (v18 or higher)
- npm or yarn
- PostgreSQL database
- Docker (optional, for containerized deployment)

### Installation

1. Clone the repository:
```bash
git clone https://github.com/your-org/QConnect.git
cd QConnect
```

2. Install dependencies:
```bash
# Frontend
cd QConnect-Fe
npm install

# Backend
cd ../QConnect-Auth-Service
npm install
```

3. Set up environment variables:
```bash
# Copy environment files
cp .env.example .env
# Edit .env with your configuration
```

4. Set up the database:
```bash
cd QConnect-Auth-Service
npx prisma generate
npx prisma db push
```

5. Start the development servers:
```bash
# Backend (Terminal 1)
cd QConnect-Auth-Service
npm run dev

# Frontend (Terminal 2)
cd QConnect-Fe
npm run dev
```

## Project Structure

```
QConnect/
├── QConnect-Fe/                 # Frontend (Astro + React)
│   ├── src/
│   │   ├── components/          # React components
│   │   ├── pages/              # Astro pages
│   │   ├── layouts/            # Page layouts
│   │   └── lib/                # Utilities and services
│   └── public/                 # Static assets
└── QConnect-Auth-Service/       # Backend (Node.js + Fastify)
    ├── src/
    │   ├── api/                # API routes and controllers
    │   ├── config/             # Configuration files
    │   ├── services/           # Business logic
    │   └── utils/              # Utility functions
    └── prisma/                 # Database schema
```

## Key Features

### For Students
- View academic progress and grades
- Submit assignments digitally
- Access course materials and resources
- Communicate with faculty and peers
- Track attendance and schedules

### For Faculty
- Manage courses and assignments
- Grade submissions and provide feedback
- Monitor student progress
- Communicate with students and administration
- Generate reports and analytics

### For Administrators
- Manage user roles and permissions
- Oversee academic programs
- Generate institutional reports
- Configure system settings
- Monitor platform usage

## API Documentation

The backend provides RESTful APIs for all platform functionality. API documentation is available at `/api/docs` when running the development server.

## Contributing

We welcome contributions! Please read our [Contributing Guidelines](CONTRIBUTING.md) for more information.

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## Support

For support and questions, please contact us at support@qconnect.edu or create an issue in this repository.
