// @ts-check

import tailwindcss from '@tailwindcss/vite';
import { defineConfig } from 'astro/config';
import node from '@astrojs/node';
import react from '@astrojs/react';

// https://astro.build/config
export default defineConfig({
	output: 'server',
	adapter: node({
		mode: 'standalone',
	}),
	viewTransitions: true, // ✅ Enable Astro View Transitions
	vite: {
		// eslint-disable-next-line @typescript-eslint/ban-ts-comment
		// @ts-ignore
		plugins: [tailwindcss()],
		preview: {
			allowedHosts: ['alpha-qconnect.quickrecruit.com', 'localhost', '0.0.0.0'],
		},
	},

	integrations: [react()],
});
