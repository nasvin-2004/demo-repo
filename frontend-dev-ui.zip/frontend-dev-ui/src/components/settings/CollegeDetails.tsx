'use client';
import { useEffect, useState } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from '@/components/ui/select';
import { Upload, Plus, Trash2 } from 'lucide-react';
import { fetchCollege } from '@/services/college.service';
import type { Address, College } from '@/services/college.service';
import { cn } from '@/lib/utils';
import { countryCodesList } from '@/lib/constants';
import { ErrorHandler } from '@/lib/error-handler';
import { Checkbox } from '@/components/ui/checkbox';
import clsx from 'clsx';
import { CollegeTypeCase } from '@/services/college.service';
import type { FilterValue } from '@/components/common/Filter';

export default function CollegeDetails() {
	const [college, setCollege] = useState<College | null>(null);
	const [editing, setEditing] = useState(false);
	const [loading, setLoading] = useState(true);
	const [logoPreview, setLogoPreview] = useState<string>('');
	// const [institutionList, setInstitutionList] = useState<
	// 	{ enterpriseId: string; enterpriseName: string }[]
	// >([]);

	useEffect(() => {
		async function loadData() {
			setLoading(true);
			try {
				const response = await fetchCollege();
				if (response.success && response.data) {
					setCollege(response.data);
					setLogoPreview(response.data.logoUrl || '');
				} else {
					setCollege(null);
				}
			} catch (err) {
				ErrorHandler.logError(err, 'Fetching college');
				setCollege(null);
			} finally {
				setLoading(false);
			}
		}
		loadData();
	}, []);

	const handleChange = (key: keyof College, value: FilterValue) => {
		if (!college) return;
		setCollege(prev => (prev ? { ...prev, [key]: value } : prev));
	};

	const handleAddressChange = (index: number, key: string, value: FilterValue) => {
		if (!college) return;
		const updatedAddresses = [...(college.Address || [])];
		updatedAddresses[index] = { ...updatedAddresses[index], [key]: value };
		setCollege({ ...college, Address: updatedAddresses });
	};

	const addAddress = () => {
		if (!college) return;
		const newAddress = {
			addressLine1: '',
			addressLine2: '',
			city: '',
			state: '',
			country: '',
			pincode: '',
		};
		setCollege({
			...college,
			Address: [...(college.Address || []), newAddress],
		});
	};

	const removeAddress = (index: number) => {
		if (!college) return;
		const updatedAddresses = (college.Address || []).filter((_, i) => i !== index);
		setCollege({ ...college, Address: updatedAddresses });
	};

	const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const reader = new FileReader();
		reader.onloadend = () => {
			const base64 = reader.result as string;
			setLogoPreview(base64);
			handleChange('logoUrl', base64);
		};
		reader.readAsDataURL(file);
	};

	// const handleSave = async () => {
	// 	if (!college) return;
	// 	try {
	// 		const res = await updateCollege(collegeId, college);
	// 		if (res.success) {
	// 			setEditing(false);
	// 		} else {
	// 			toast.error(`Update failed: ${res.message}`);
	// 		}
	// 	} catch (err) {
	// 		ErrorHandler.logError(err, 'Updating college');
	// 	}
	// };

	if (loading) return <p className="py-4 text-center text-gray-500">Loading College...</p>;
	if (!college) return <p className="py-4 text-center text-red-500">College not found.</p>;

	return (
		<div className="h-fit min-h-[calc(99vh-5rem)] flex-1 rounded-lg bg-white p-6 shadow-sm">
			{/* Header */}
			<div className="mb-6 flex items-start justify-between">
				<Label className="text-lg font-semibold text-gray-800">College Details</Label>
			</div>

			{/* Logo + Basic Info */}
			<div className="mb-8 grid grid-cols-1 items-center gap-6 md:grid-cols-2">
				<div className="group relative mx-auto h-36 w-36 overflow-hidden rounded-full border border-gray-300 bg-gray-100">
					{logoPreview ? (
						<img src={logoPreview} alt="Logo" className="h-full w-full object-cover" />
					) : (
						<div className="flex h-full items-center justify-center text-sm text-gray-400">
							No Logo
						</div>
					)}

					{editing && (
						<label
							className="absolute inset-0 flex cursor-pointer items-center justify-center rounded-full bg-black/40 opacity-100 transition group-hover:opacity-0"
							title="Click to upload logo">
							<div className="flex flex-col items-center justify-center text-white">
								<Upload className="mb-1 h-7 w-7" />
								<span className="text-xs font-medium">Upload</span>
							</div>
							<input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
						</label>
					)}
				</div>

				<div className="flex w-full flex-col gap-5">
					{/* College Name */}
					<div className="flex flex-col space-y-1">
						<Label className="text-sm text-gray-600">College Name</Label>
						<Input
							value={college.collegeName || ''}
							readOnly={!editing}
							onChange={e => handleChange('collegeName', e.target.value)}
							className={cn(
								'h-11 border-gray-300 text-gray-800',
								!editing && 'cursor-not-allowed bg-gray-50',
							)}
						/>
					</div>

					{/* Institution Name */}
					<div className="flex flex-col space-y-1">
						<Label className="text-sm text-gray-600">Institution Name</Label>
						<Input
							value={college.institutionName || ''}
							readOnly
							className="h-11 cursor-not-allowed border-gray-300 bg-gray-50 text-gray-800"
						/>
					</div>
				</div>
			</div>

			{/* Core Info Section */}
			<div className="mb-8 grid grid-cols-1 gap-5 md:grid-cols-2">
				<div className="flex flex-col space-y-1">
					<Label className="text-sm text-gray-600">Primary Phone</Label>
					{editing ? (
						<div className="flex">
							{/* Country Code Dropdown */}
							<Select
								value={college.phoneNumberCountryCode || '+91'}
								onValueChange={v => handleChange('phoneNumberCountryCode', v)}>
								<SelectTrigger className="!h-11 min-w-[110px] rounded-r-none bg-white text-sm">
									<SelectValue placeholder="Code" />
								</SelectTrigger>
								<SelectContent className="max-h-60 overflow-y-auto">
									{countryCodesList.map(c => (
										<SelectItem key={c.code} value={c.dialCode}>
											<div className="flex items-center gap-2">
												<span className="text-lg">{c.flag}</span>
												<span className="text-muted-foreground ml-auto">{c.dialCode}</span>
											</div>
										</SelectItem>
									))}
								</SelectContent>
							</Select>
							{/* Phone Number Input */}
							<Input
								type="tel"
								value={college.phoneNumber || ''}
								onChange={e => handleChange('phoneNumber', e.target.value)}
								className="!h-11 flex-1 rounded-l-none bg-transparent text-gray-800 focus-visible:border-gray-400 focus-visible:ring-0"
								placeholder="Enter phone number"
							/>
						</div>
					) : (
						(() => {
							const selected =
								countryCodesList.find(c => c.dialCode === college.phoneNumberCountryCode) ||
								countryCodesList.find(c => c.dialCode === '+91');
							const combinedValue = `${selected?.flag || '🌐'} ${selected?.dialCode || '+91'} ${
								college.phoneNumber || ''
							}`;
							return (
								<Input
									readOnly
									value={combinedValue.trim()}
									className="!h-11 cursor-not-allowed border-gray-300 bg-gray-50 text-gray-800"
								/>
							);
						})()
					)}
				</div>

				<div className="flex flex-col space-y-1">
					<Label className="text-sm text-gray-600">College Type</Label>
					{editing ? (
						<Select
							value={college.collegeType || ''}
							onValueChange={v => handleChange('collegeType', v)}>
							<SelectTrigger className="!h-11 w-full">
								<SelectValue placeholder="Select Type" />
							</SelectTrigger>
							<SelectContent>
								<SelectItem value="GOVERNMENT">Government</SelectItem>
								<SelectItem value="AIDED">Aided</SelectItem>
								<SelectItem value="PRIVATE">Private</SelectItem>
								<SelectItem value="SELF_FINANCED">Self Financed</SelectItem>
							</SelectContent>
						</Select>
					) : (
						<Input
							value={CollegeTypeCase[college.collegeType] || ''}
							readOnly
							className="h-11 cursor-not-allowed border-gray-300 bg-gray-50 text-gray-800"
						/>
					)}
				</div>

				{[
					{ key: 'collegeCode', label: 'College Code' },
					{ key: 'email', label: 'Email' },
					{ key: 'websiteUrl', label: 'Website URL' },
					{ key: 'naacGrade', label: 'NAAC Grade' },
					{ key: 'naacScore', label: 'NAAC Score' },
					{ key: 'nirfRanking', label: 'NIRF Ranking' },
					{ key: 'affliation', label: 'Affiliation' },
					{ key: 'afflicationCode', label: 'Affiliation Code' },
					{ key: 'accreditationValidTill', label: 'Accreditation Valid Till', type: 'date' },
				].map(f => (
					<div key={f.key} className="flex flex-col space-y-1">
						<Label className="text-sm text-gray-600">{f.label}</Label>
						<Input
							type={f.type || 'text'}
							value={String(college[f.key as keyof College]) || ''}
							readOnly={!editing}
							onChange={e => handleChange(f.key as keyof College, e.target.value)}
							className={cn(
								'h-11 border-gray-300 text-gray-800',
								!editing && 'cursor-not-allowed bg-gray-50',
							)}
						/>
					</div>
				))}

				{[
					{ key: 'ugcApproved', label: 'UGC Approved' },
					{ key: 'aicteApproved', label: 'AICTE Approved' },
					{ key: 'nbaAccredited', label: 'NBA Accredited' },
					{ key: 'autonomousStatus', label: 'Autonomous Status' },
					{ key: 'isActive', label: 'Active Status' },
				].map(f => (
					<div key={f.key} className="flex flex-col space-y-1">
						<Label className="text-sm text-gray-600">{f.label}</Label>
						{editing ? (
							<Select
								value={String(college[f.key as keyof College]) ? 'true' : 'false'}
								onValueChange={v => handleChange(f.key as keyof College, v === 'true')}>
								<SelectTrigger className="!h-11 w-full">
									<SelectValue placeholder="Select" />
								</SelectTrigger>
								<SelectContent>
									<SelectItem value="true">Yes</SelectItem>
									<SelectItem value="false">No</SelectItem>
								</SelectContent>
							</Select>
						) : (
							<Input
								value={String(college[f.key as keyof College]) ? 'Yes' : 'No'}
								readOnly
								className="h-11 cursor-not-allowed border-gray-300 bg-gray-50 text-gray-800"
							/>
						)}
					</div>
				))}
			</div>

			{/* Description */}
			<div className="mb-10 flex flex-col space-y-1">
				<Label className="text-sm text-gray-600">Description</Label>
				<Input
					value={college.description || ''}
					readOnly={!editing}
					onChange={e => handleChange('description', e.target.value)}
					className={cn(
						'h-11 border-gray-300 text-gray-800',
						!editing && 'cursor-not-allowed bg-gray-50',
					)}
				/>
			</div>

			{/* Address Section */}
			<div>
				<div className="mb-2 flex items-center justify-between">
					<Label className="text-md font-semibold text-gray-700">Address</Label>
				</div>

				{college.Address?.length ? (
					college.Address.map((addr, i) => (
						<div
							key={i}
							className="mt-4 grid grid-cols-1 gap-5 rounded-lg border p-4 md:grid-cols-2">
							<div className="col-span-2 flex justify-between">
								<Label className="text-[15px] text-gray-600">Address {i + 1}</Label>
								{editing && (
									// <Button
									//   variant="ghost"
									//   onClick={() => removeAddress(i)}
									//   className="text-[var(--brandRed)]/80 hover:text-[var(--brandRed)] hover:!bg-transparent cursor-pointer"
									// >
									<Trash2
										className="text-[var(--brandRed)]/80 h-5 w-5 cursor-pointer hover:!bg-transparent hover:text-[var(--brandRed)]"
										onClick={() => removeAddress(i)}
									/>
									// </Button>
								)}
							</div>
							{[
								{ key: 'addressLine1', label: 'Address Line 1' },
								{ key: 'addressLine2', label: 'Address Line 2' },
								{ key: 'city', label: 'City' },
								{ key: 'state', label: 'State' },
								{ key: 'country', label: 'Country' },
								{ key: 'pincode', label: 'Pincode' },
							].map(f => (
								<div key={f.key} className="flex flex-col space-y-1">
									<Label className="text-sm text-gray-600">{f.label}</Label>
									<Input
										value={String(addr[f.key as keyof Address]) || ''}
										readOnly={!editing}
										onChange={e => handleAddressChange(i, f.key, e.target.value)}
										className={cn(
											'h-11 border-gray-300 text-gray-800',
											!editing && 'cursor-not-allowed bg-gray-50',
										)}
									/>
								</div>
							))}
							<div className="flex items-center gap-2">
								<Checkbox
									checked={addr.isPrimary ?? false}
									onCheckedChange={(checked: boolean) =>
										handleAddressChange(i, 'isPrimary', checked)
									}
									disabled={!editing}
									className={clsx(
										'data-[state=checked]:border-[var(--brandColor)] data-[state=checked]:bg-[var(--brandColor)]',
										'rounded transition-colors duration-200',
										!editing && 'cursor-not-allowed opacity-50',
									)}
								/>
								<Label className="text-muted-foreground select-none text-sm font-medium ">
									Primary address
								</Label>
							</div>
						</div>
					))
				) : (
					<p className="mt-3 text-gray-500">No address available</p>
				)}
			</div>

			{/* Actions */}
			{editing && (
				<div className="mt-8 flex items-center justify-between">
					<Button
						onClick={addAddress}
						variant="outline"
						className="flex items-center gap-2 bg-[var(--brandColor)] text-white hover:!bg-[var(--brandColor-dark)] hover:text-white">
						<Plus className="h-4 w-4" />
						Add Address
					</Button>
					<div className="flex gap-4">
						<Button
							className="bg-[var(--brandColor)] text-white hover:bg-[var(--brandColor-dark)]"
							// onClick={handleSave}>
						>
							Save
						</Button>
						<Button
							variant="outline"
							onClick={() => {
								setEditing(false);
								window.location.reload();
							}}
							className="border-[var(--brandColor)] text-[var(--brandColor)] hover:text-[var(--brandColor-dark)]">
							Cancel
						</Button>
					</div>
				</div>
			)}
		</div>
	);
}
