import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { updateProfile } from '@/services/auth.service';
import { toast } from 'sonner';
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from '@/components/ui/select';
import { CheckCircleIcon, Edit3, XIcon } from 'lucide-react';
import { useStore } from '@nanostores/react';
import { $loadingProfile, $profile, loadProfileData } from '@/stores/profileStore';
interface ProfileField {
	label: string;
	value: string | null;
	editable: boolean;
	icon?: boolean;
	type?: 'select';
}
const timezones = ['IST (India)', 'EST (US)', 'PST (US)'];
const industries = ['Tech', 'Finance', 'Marketing'];
export default function ProfileInfo() {
	const profile = useStore($profile);
	const loading = useStore($loadingProfile);
	const [editing, setEditing] = useState(false);
	const [formData, setFormData] = useState<ProfileField[]>([]);

	useEffect(() => {
		if (profile) {
			setFormData([
				{ label: 'Name', value: profile.name, editable: false },
				{ label: 'Role', value: profile.role, editable: false },
				{
					label: 'Email',
					value: profile.email,
					icon: false,
					editable: false,
				},
				{ label: 'Phone Number', value: profile.phoneNumber, editable: true },
			]);
		}
	}, [profile]);
	// if (!profile) return null; // ensures profile is not undefined
	const handleSelectChange = (label: string, value: string) => {
		setFormData(prev => prev.map(item => (item.label === label ? { ...item, value } : item)));
	};
	const handleSave = async () => {
		const phoneField = formData.find(f => f.label === 'Phone Number');
		if (!phoneField) return;
		const res = await updateProfile(phoneField.value || '');
		if (res.success) {
			toast.success(res.message || 'Updated successfully');
			// update local profile store
			loadProfileData();
			setEditing(false);
		} else {
			toast.error(res.message || 'Update failed');
		}
	};
	if (loading || !formData) {
		return <p className="py-4 text-center text-gray-500">Loading profile...</p>;
	}
	return (
		<div className="h-fit min-h-[calc(99vh-5rem)] flex-1 rounded-lg bg-white p-6">
			{/* Header */}
			<div className="mb-2 flex items-start justify-between">
				<Label className="text-lg font-semibold text-gray-800">Personal Info</Label>
				<Button
					variant="ghost"
					onClick={() => setEditing(!editing)}
					className="cursor-pointer hover:!bg-transparent">
					{editing ? (
						<XIcon className="size-5 text-red-600" />
					) : (
						<Edit3 className="size-4 text-[var(--brandColor)]" />
					)}
				</Button>
			</div>
			{/* Form Section */}
			<div className="space-y-6">
				<form id="apply" className="mx-auto w-full">
					<div className="grid grid-cols-1 gap-5 md:grid-cols-2">
						{formData.map(item => (
							<div key={item.label} className="flex flex-col space-y-2">
								<Label className="flex items-center gap-1 text-sm font-medium text-gray-500">
									{item.label}
									{item.icon && <CheckCircleIcon className="h-4 w-4 text-[var(--brandColor)]" />}
								</Label>
								{/* When edit mode OFF — show readonly Input for everything */}
								{!editing ? (
									<Input
										readOnly
										value={item.value || 'No Data'}
										className="h-11 cursor-not-allowed border border-gray-300 bg-slate-50 text-gray-800"
									/>
								) : item.type === 'select' ? (
									<Select onValueChange={val => handleSelectChange(item.label, val)}>
										<SelectTrigger className="!h-11 w-full border border-gray-300 text-gray-700">
											<SelectValue placeholder={item.value || 'No Data'} />
										</SelectTrigger>
										<SelectContent>
											{(item.label === 'Time Zone' ? timezones : industries).map(option => (
												<SelectItem key={option} value={option}>
													{option}
												</SelectItem>
											))}
										</SelectContent>
									</Select>
								) : (
									// <Input
									//  value={item.value || ''}
									//  readOnly={!item.editable}
									//  onFocus={e => {
									//      if (!item.editable) e.target.blur();
									//  }}
									//  className={`h-11 border border-gray-300 text-gray-700 ${
									//      !item.editable
									//          ? 'cursor-not-allowed bg-slate-50 text-gray-800'
									//          : 'cursor-pointer'
									//  }`}
									// />
									<Input
										value={item.value || ''}
										onChange={e => {
											if (editing && item.label === 'Phone Number') {
												setFormData(prev =>
													prev.map(f =>
														f.label === 'Phone Number' ? { ...f, value: e.target.value } : f,
													),
												);
											}
										}}
										readOnly={item.label !== 'Phone Number' || !editing}
										className={`h-11 border border-gray-300 text-gray-700 ${
											item.label !== 'Phone Number' || !editing
												? 'cursor-not-allowed bg-slate-50 text-gray-800'
												: 'cursor-text'
										}`}
									/>
								)}
							</div>
						))}
					</div>
				</form>
				{/* App Version */}
				<div className="flex flex-row justify-between pt-4">
					<h3 className="text-lg text-gray-700">
						App Version - <span className="font-semibold">1.0.0</span>
					</h3>
					{editing && (
						<div className="flex gap-5">
							<Button
								onClick={handleSave}
								className="bg-[var(--brandColor)] text-white hover:bg-[var(--brandColor-dark)]">
								Save
							</Button>
							<Button
								variant="outline"
								className="hover: hover: border-[var(--brandColor)] border-[var(--brandColor-dark)] !text-[var(--brandColor-dark)] text-[var(--brandColor)]"
								onClick={() => setEditing(false)}>
								Cancel
							</Button>
						</div>
					)}
				</div>
			</div>
		</div>
	);
}
