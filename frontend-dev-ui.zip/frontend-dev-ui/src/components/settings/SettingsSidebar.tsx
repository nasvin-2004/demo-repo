'use client';

import clsx from 'clsx';
import { BadgeInfoIcon, UserRoundIcon, KeyRoundIcon } from 'lucide-react';
import { Button } from '../ui/button';

const SIDEBAR_ITEMS = [
	{ key: 'profile', label: 'Profile', Icon: UserRoundIcon },
	{ key: 'college', label: 'College Details', Icon: BadgeInfoIcon },
	{ key: 'password', label: 'Password', Icon: KeyRoundIcon },
];

export default function SettingsSidebar({
	active,
	onSelect,
}: {
	active: string;
	onSelect: (key: string) => void;
}) {
	return (
		<div className="h-fit w-full rounded-lg bg-white p-4 md:min-h-[calc(99vh-5rem)] md:w-1/5">
			<div className="flex flex-col gap-1.5">
				{SIDEBAR_ITEMS.map(({ key, label, Icon }) => {
					const isActive = active === key;
					return (
						<Button
							key={key}
							onClick={() => onSelect(key)}
							variant="ghost"
							className={clsx(
								'flex cursor-pointer items-center justify-start gap-2 rounded-md px-3 py-2.5 text-left transition-all',
								isActive
									? 'bg-[var(--brandAccent)] text-[var(--brandColor-dark)]'
									: 'hover:bg-[var(--brandAccent)]/50 text-gray-500 hover:text-[var(--brandColor)]',
							)}>
							<Icon className="h-4 w-4 flex-shrink-0" />
							<span className="text-sm font-medium">{label}</span>
						</Button>
					);
				})}
			</div>
		</div>
	);
}
