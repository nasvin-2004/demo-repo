import { useState } from 'react';
import SettingsSidebar from '@/components/settings/SettingsSidebar';
import ProfileInfo from '@/components/settings/ProfileInfo';
import CollegeDetails from '@/components/settings/CollegeDetails';
import PasswordSettings from '@/components/settings/PasswordSettings';

export default function SettingsPage() {
	const [active, setActive] = useState('profile');

	const renderContent = () => {
		switch (active) {
			case 'profile':
				return <ProfileInfo />;
			case 'college':
				return <CollegeDetails />;
			case 'password':
				return <PasswordSettings />;
			default:
				return null;
		}
	};

	return (
		<section className="w-full px-4 py-3">
			<div className="flex flex-col gap-2 md:flex-row md:gap-3.5">
				<SettingsSidebar active={active} onSelect={setActive} />
				{renderContent()}
			</div>
		</section>
	);
}
