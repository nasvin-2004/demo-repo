import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useStore } from '@nanostores/react';
import { $profile } from '@/stores/profileStore';
import { forgotPassword } from '@/services/auth.service';
import { toast } from 'sonner';
import { KeyRoundIcon } from 'lucide-react';

export default function PasswordSettings() {
	const profile = useStore($profile);
	const [isLoading, setIsLoading] = useState(false);

	const handleSendResetLink = async () => {
		if (!profile?.email) {
			toast.error('Email not found. Please try again.');
			return;
		}

		setIsLoading(true);
		try {
			const response = await forgotPassword(profile.email);

			if (response.success) {
				toast.success('Password reset link sent to your email!');
			} else {
				toast.error(response.message || 'Failed to send password reset link');
			}
		} catch (error) {
			// eslint-disable-next-line no-console
			console.error('Send reset link error:', error);
			toast.error('Something went wrong. Please try again.');
		} finally {
			setIsLoading(false);
		}
	};

	return (
		<div className="h-fit min-h-[calc(99vh-5rem)] flex-1 rounded-lg bg-white p-6">
			{/* Header */}
			<div className="mb-6 flex items-start justify-between">
				<Label className="text-lg font-semibold text-gray-800">Password Settings</Label>
			</div>

			{/* Content Section */}
			<div className="space-y-6">
				<div className="flex flex-col gap-4 rounded-lg border border-gray-200 bg-gray-50 p-6">
					<div className="flex items-start gap-4">
						<div className="flex h-10 w-10 items-center justify-center rounded-full bg-[var(--brandAccent)]">
							<KeyRoundIcon className="h-5 w-5 text-[var(--brandColor)]" />
						</div>
						<div className="flex-1">
							<h3 className="mb-2 text-base font-semibold text-gray-800">Forgot Your Password?</h3>
							<p className="mb-4 text-sm text-gray-600">
								If you forgot your password, click the button below to receive a password reset link
								in your email. The link will be valid for 10 minutes.
							</p>
							<Button
								onClick={handleSendResetLink}
								disabled={isLoading}
								className="w-full bg-[var(--brandColor)] text-white hover:bg-[var(--brandColor-dark)] disabled:cursor-not-allowed disabled:opacity-50 md:w-auto">
								{isLoading ? 'Sending...' : 'Send Password Reset Link'}
							</Button>
						</div>
					</div>
				</div>

				{/* Info Section */}
				<div className="rounded-lg border border-blue-200 bg-blue-50 p-4">
					<p className="text-sm text-blue-800">
						<strong>Note:</strong> After clicking the button, check your email inbox for the
						password reset link. Click on the link to reset your password. Make sure to check your
						spam folder if you don&apos;t see the email.
					</p>
				</div>
			</div>
		</div>
	);
}
