import { Label } from '@/components/ui/label';
import { CircleIcon, EllipsisVerticalIcon, InboxIcon, PlusIcon, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from '@/components/ui/table';
import clsx from 'clsx';
import { useState } from 'react';
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuTrigger,
} from '../ui/dropdown-menu';
import StudentModal from './StudentModal';
import CommonModal from '../common/Modal';
import { toast } from 'sonner';
import { ErrorHandler } from '@/lib/error-handler';
import { deleteStudent, updateUserStatus } from '@/services';
import PaginationBar from '../common/Pagination';
import HoverSearchInfoPopover from '@/components/common/SearchInfo';

export type Student = {
	studentId: string;
	userId: string;
	name: string;
	email: string;
	phoneNumber: string;
	rollNumber: string;
	program: string;
	departmentId: string;
	department: string;
	section: string;
	graduationYear: number;
	batch: string;
	admissionNumber: string;
	status: 'ACTIVE' | 'INACTIVE' | 'PENDING';
};

export const StatusCase = {
	ACTIVE: 'Active',
	INACTIVE: 'Inactive',
	PENDING: 'Pending',
};

interface StudentTableProps {
	students: Student[];
	search: string;
	onSearchChange: (value: string) => void;
	page: number;
	totalPages: number;
	total: number;
	onPageChange: (page: number) => void;
	limit: number;
	onLimitChange: (limit: number) => void;
}

export default function StudentTable({
	students,
	search,
	onSearchChange,
	page,
	totalPages,
	total,
	onPageChange,
	limit,
	onLimitChange,
}: StudentTableProps) {
	const [open, setOpen] = useState(false);
	const [editStudent, setEditStudent] = useState<Student | null>(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [confirmAction, setConfirmAction] = useState<'ACTIVATE' | 'DEACTIVATE' | 'DELETE' | null>(
		null,
	);
	const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
	const [modalMode, setModalMode] = useState<'edit' | 'view' | 'add'>('edit');

	const editStudentData = (student: Student) => {
		setEditStudent(student);
	};

	const handleConfirm = async () => {
		if (!selectedStudent || !confirmAction) return;
		try {
			if (confirmAction === 'DELETE') {
				const response = await deleteStudent(selectedStudent.studentId);
				if (response.success) {
					toast.success(response.message);
					window.location.reload();
				} else {
					toast.error(response.message);
				}
			} else {
				const status = confirmAction === 'ACTIVATE' ? 'ACTIVE' : 'INACTIVE';
				const response = await updateUserStatus({ userId: selectedStudent.userId, status });
				if (response.success) {
					toast.success(response.message);
					window.location.reload();
				} else {
					toast.error(response.message);
				}
			}
		} catch (err) {
			ErrorHandler.logError(err, 'Handling student action');
			toast.error('Unexpected error performing action');
		} finally {
			setConfirmOpen(false);
			setConfirmAction(null);
			setSelectedStudent(null);
		}
	};

	return (
		<div className="h-fit min-h-[calc(99vh-5rem)] flex-1 rounded-lg bg-white p-6">
			{/* Header Section */}
			<div className="mb-4 flex items-center justify-between">
				<Label className="text-lg font-semibold text-gray-700">Students</Label>
				<div className="flex flex-row items-center">
					<div>
						<span className="px-3 text-sm text-gray-500">
							Showing {page} of {totalPages} ({total} students)
						</span>
					</div>
					<Button
						className="cursor-pointer gap-2 bg-[var(--brandColor)] px-4 py-2 text-white hover:bg-[var(--brandColor-dark)]"
						onClick={() => {
							setEditStudent(null);
							setModalMode('add');
							setOpen(true);
						}}>
						<PlusIcon className="h-4 w-4" />
						<span className="font-medium">Add Student</span>
					</Button>
				</div>
			</div>

			{/* Search Bar Section with Info Popover */}
			<div className="flex items-center gap-3 pb-4">
				<div className="w-3xs relative flex items-center">
					<span className="absolute left-3">
						<Search className="h-4 w-4 text-gray-400" />
					</span>
					<input
						type="text"
						placeholder="Search Students"
						value={search}
						onChange={e => onSearchChange(e.target.value)}
						className="w-full rounded-md border border-gray-300 py-2 pl-9 pr-9 text-sm focus:border-[var(--brandColor)] focus:ring-0"
					/>
					<span className="absolute right-3 z-20">
						<HoverSearchInfoPopover fields={['Name', 'Email', 'PhoneNo', 'RollNo']} align="end" />
					</span>
				</div>
				<Button className="cursor-pointer gap-2 bg-[var(--brandColor)] px-6 py-2 text-white hover:bg-[var(--brandColor-dark)]">
					<Search />
					<span className="font-medium">Search</span>
				</Button>
			</div>

			<div className="flex min-h-[50vh] flex-col justify-between overflow-hidden rounded-md">
				<div className="flex-1">
					<Table>
						<TableHeader className="bg-gray-100/70">
							<TableRow className="!border-b-0">
								{['S. No', 'Name', 'Email/Phone', 'RollNo', 'Course', 'Login Status', 'Action'].map(
									h => (
										<TableHead key={h} className="px-4 py-3 font-semibold text-gray-500/80">
											{h}
										</TableHead>
									),
								)}
							</TableRow>
						</TableHeader>
						<TableBody>
							{students.length > 0 ? (
								students.map((student, index) => (
									<TableRow
										key={index}
										onClick={() => {
											editStudentData(student);
											setModalMode('view');
											setOpen(true);
										}}
										className="cursor-pointer border-b transition-colors last:border-b-0 hover:bg-gray-50/70">
										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{(page - 1) * limit + (index + 1)}
										</TableCell>
										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{student.name}
										</TableCell>
										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{student.email}
											<br />
											{student.phoneNumber}
										</TableCell>
										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{student.rollNumber}
										</TableCell>
										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{`${student.program}/${student.department}-${student.section}`}
										</TableCell>
										<TableCell className="px-4 py-3">
											<div className="flex items-center gap-2 text-gray-500/90">
												<CircleIcon
													className={clsx(
														'h-3 w-3 fill-current',
														student.status === 'ACTIVE'
															? 'text-[var(--brandColor)]'
															: student.status === 'PENDING'
																? 'text-[var(--brandYellow)]'
																: 'text-[var(--brandRed)]',
													)}
												/>
												<span className="font-medium">{StatusCase[student.status]}</span>
											</div>
										</TableCell>
										<TableCell className="px-4 py-3">
											<DropdownMenu>
												<DropdownMenuTrigger asChild>
													<Button
														variant="outline"
														className="size-8.5 cursor-pointer border-gray-200 text-[var(--brandColor)] !shadow-none hover:!border-[var(--brandColor)] hover:!bg-[var(--brandAccent)] hover:!text-[var(--brandColor-dark)]">
														<EllipsisVerticalIcon />
													</Button>
												</DropdownMenuTrigger>
												<DropdownMenuContent
													align="end"
													className="w-36 text-gray-500"
													role="menu"
													aria-label={`Actions for ${student.name}`}>
													{(student.status === 'ACTIVE' || student.status === 'INACTIVE') && (
														<DropdownMenuItem
															onClick={e => {
																e.stopPropagation();
																editStudentData(student);
																setModalMode('edit');
																setOpen(true);
															}}
															role="menuitem"
															aria-label={`Edit ${student['name']}`}>
															Edit
														</DropdownMenuItem>
													)}
													{(student.status === 'ACTIVE' || student.status === 'INACTIVE') && (
														<DropdownMenuItem
															onClick={e => {
																e.stopPropagation();
																setSelectedStudent(student);
																setConfirmAction('DELETE');
																setConfirmOpen(true);
															}}
															role="menuitem"
															aria-label={`Delete ${student['name']}`}>
															Delete
														</DropdownMenuItem>
													)}
													{student.status === 'ACTIVE' && (
														<DropdownMenuItem
															onClick={e => {
																e.stopPropagation();
																setSelectedStudent(student);
																setConfirmAction('DEACTIVATE');
																setConfirmOpen(true);
															}}
															role="menuitem"
															aria-label={`Deactivate ${student['name']}`}>
															Inactive
														</DropdownMenuItem>
													)}
													{student.status === 'INACTIVE' && (
														<DropdownMenuItem
															onClick={e => {
																e.stopPropagation();
																setSelectedStudent(student);
																setConfirmAction('ACTIVATE');
																setConfirmOpen(true);
															}}
															role="menuitem"
															aria-label={`Activate ${student['name']}`}>
															Activate
														</DropdownMenuItem>
													)}
													{student.status === 'PENDING' && (
														<>
															<DropdownMenuItem
																onClick={e => {
																	e.stopPropagation();
																	toast.info(`Send mail to ${student['name']}`);
																}}
																role="menuitem"
																aria-label={`Send mail to ${student['name']}`}>
																Send Mail
															</DropdownMenuItem>
															<DropdownMenuItem
																role="menuitem"
																aria-label={`Revoke ${student['name']}`}>
																Revoke
															</DropdownMenuItem>
														</>
													)}
												</DropdownMenuContent>
											</DropdownMenu>
										</TableCell>
									</TableRow>
								))
							) : (
								<TableRow>
									<TableCell colSpan={7} className="py-12 text-center">
										<div className="flex flex-col items-center gap-2 text-gray-400">
											<InboxIcon className="h-10 w-10" />
											<span className="text-sm font-medium">No data</span>
										</div>
									</TableCell>
								</TableRow>
							)}
						</TableBody>
					</Table>
				</div>
			</div>

			<div className="flex justify-end px-2">
				<PaginationBar
					page={page}
					totalPages={totalPages}
					limit={limit}
					onLimitChange={onLimitChange}
					onPageChange={onPageChange}
				/>
			</div>

			<StudentModal open={open} onOpenChange={setOpen} student={editStudent} mode={modalMode} />
			<CommonModal
				isOpen={confirmOpen}
				onOpenChange={setConfirmOpen}
				title={`Confirm ${confirmAction === 'ACTIVATE' ? 'Activation' : 'Deactivation'}`}
				description={`Are you sure you want to ${confirmAction?.toLowerCase()} ${selectedStudent?.['name']}?`}
				confirmText="Yes"
				cancelText="Cancel"
				onConfirm={handleConfirm}
			/>
		</div>
	);
}
