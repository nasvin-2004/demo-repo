'use client';

import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useState, useEffect } from 'react';
import { StatusCase, type Student } from './StudentsTable';
import { toast } from 'sonner';
import { ErrorHandler } from '@/lib/error-handler';
import { createStudent, updateStudent, getProgramsWithDepartments } from '@/services';
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from '@/components/ui/select';

export default function StudentModal({
	open,
	onOpenChange,
	student,
	mode,
}: {
	open: boolean;
	onOpenChange: (b: boolean) => void;
	student: Student | null;
	mode: 'edit' | 'add' | 'view';
}) {
	const [form, setForm] = useState<Partial<Student>>({
		name: '',
		email: '',
		phoneNumber: '',
		rollNumber: '',
		program: '',
		department: '',
		section: '',
		graduationYear: 0,
		batch: '',
		admissionNumber: '',
		status: 'ACTIVE',
	});

	const [programData, setProgramData] = useState<
		{ programId: string; programName: string; departments: { id: string; name: string }[] }[]
	>([]);
	const [departments, setDepartments] = useState<{ id: string; name: string }[]>([]);

	const isView = mode === 'view';
	const isAdd = mode === 'add';
	const isEdit = mode === 'edit';

	useEffect(() => {
		if (student) {
			setForm(student);
		} else {
			setForm({
				name: '',
				email: '',
				phoneNumber: '',
				rollNumber: '',
				program: '',
				departmentId: '',
				department: '',
				section: '',
				graduationYear: 0,
				batch: '',
				admissionNumber: '',
				status: 'ACTIVE',
			});
		}
	}, [student]);

	useEffect(() => {
		const fetchProgramDepartments = async () => {
			const res = await getProgramsWithDepartments();
			if (res.success && res.data) setProgramData(res.data);
			else toast.error(res.message || 'Failed to load program and department data');
		};

		fetchProgramDepartments();
	}, []);

	useEffect(() => {
		if (form.program) {
			const selectedProgram = programData.find(p => p.programName === form.program);
			setDepartments(selectedProgram ? selectedProgram.departments : []);
		} else {
			setDepartments([]);
		}
	}, [form.program, programData]);

	const handleSubmit = async () => {
		try {
			let response;
			const graduationYear = Number(form.graduationYear);

			if (isEdit) {
				response = await updateStudent({
					studentId: form.studentId as string,
					userId: form.userId as string,
					name: form.name as string,
					email: form.email as string,
					rollNumber: form.rollNumber as string,

					graduationYear,
					batch: form.batch as string,
					section: form.section as string,
					admissionNumber: form.admissionNumber as string,
					departmentId: form.departmentId as string,
					phoneNumber: form.phoneNumber as string,
				});
			} else if (isAdd) {
				response = await createStudent({
					name: form.name as string,
					email: form.email as string,
					rollNumber: form.rollNumber as string,
					graduationYear,
					batch: form.batch as string,
					section: form.section as string,
					admissionNumber: form.admissionNumber as string,
					departmentId: form.departmentId as string,
					phoneNumber: form.phoneNumber as string,
				});
			}

			if (response?.success) {
				if (response?.limitReached) {
					toast.error(response.message || 'Student limit reached! Update your Plan');
					onOpenChange(false);
				} else {
					toast.success(response.message);
					onOpenChange(false);
					window.location.reload();
				}
			} else {
				toast.error(response?.message || 'Failed to save student');
			}
		} catch (err) {
			ErrorHandler.logError(err, 'Submitting student');
			toast.error('Unexpected error while saving student');
		}
	};

	return (
		<Dialog open={open} onOpenChange={onOpenChange}>
			<DialogContent className="max-w-[500px] rounded-lg bg-white p-6">
				<DialogHeader>
					<DialogTitle className="text-lg font-semibold text-gray-600">
						{isEdit ? 'Edit Student' : isView ? 'View Student' : 'Add New Student'}
					</DialogTitle>
					<DialogDescription className="sr-only">
						{mode === 'view'
							? 'View student details'
							: mode === 'edit'
								? 'Edit student information'
								: 'Add a new student'}
					</DialogDescription>
				</DialogHeader>

				<div className="grid grid-cols-2 gap-4 py-4">
					{/* Name */}
					<div className="flex flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">Name</Label>
						<Input
							value={form.name || ''}
							placeholder="Enter name"
							type="text"
							onChange={e => setForm({ ...form, name: e.target.value })}
							disabled={isView}
							className={isView ? 'cursor-not-allowed bg-gray-100' : ''}
						/>
					</div>

					{/* Email */}
					<div className="flex flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">Email</Label>
						<Input
							value={form.email || ''}
							placeholder="Enter email"
							type="email"
							onChange={e => setForm({ ...form, email: e.target.value })}
							disabled={isView}
							className={isView ? 'cursor-not-allowed bg-gray-100' : ''}
						/>
					</div>

					{/* Roll Number */}
					<div className="flex flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">Roll Number</Label>
						<Input
							value={form.rollNumber || ''}
							placeholder="Enter roll number"
							type="text"
							onChange={e => setForm({ ...form, rollNumber: e.target.value })}
							disabled={isView}
							className={isView ? 'cursor-not-allowed bg-gray-100' : ''}
						/>
					</div>

					{/* Admission Number */}
					<div className="flex flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">
							Admission Number
						</Label>
						<Input
							value={form.admissionNumber || ''}
							placeholder="Enter admission number"
							type="text"
							onChange={e => setForm({ ...form, admissionNumber: e.target.value })}
							disabled={isView}
							className={isView ? 'cursor-not-allowed bg-gray-100' : ''}
						/>
					</div>

					{/* Phone Number */}
					<div className="flex flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">Phone Number</Label>
						<Input
							value={form.phoneNumber || ''}
							placeholder="Enter phone number"
							type="text"
							onChange={e => setForm({ ...form, phoneNumber: e.target.value })}
							disabled={isView}
							className={isView ? 'cursor-not-allowed bg-gray-100' : ''}
						/>
					</div>

					{/* Program dropdown */}
					<div className="flex flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">Program</Label>
						{isView ? (
							<Input
								value={form.program || '—'}
								disabled
								className="border-input cursor-not-allowed border bg-gray-100 text-gray-700"
							/>
						) : (
							<Select
								value={form.program || ''}
								onValueChange={value => {
									const selectedProgram = programData.find(p => p.programName === value);
									setForm({
										...form,
										program: value,
										departmentId: '',
										department: '',
									});
									setDepartments(selectedProgram?.departments || []);
								}}
								disabled={isView}>
								<SelectTrigger className="w-full">
									<SelectValue placeholder="Select Program" />
								</SelectTrigger>
								<SelectContent>
									{programData.map(program => (
										<SelectItem key={program.programId} value={program.programName}>
											{program.programName}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						)}
					</div>

					{/* Department dropdown */}
					<div className="flex flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">Department</Label>
						{isView ? (
							<Input
								value={form.department || '—'}
								disabled
								className="cursor-not-allowed bg-gray-100"
							/>
						) : (
							<Select
								value={form.departmentId || ''}
								onValueChange={value => {
									const selectedDept = departments.find(d => d.id === value);
									setForm({
										...form,
										departmentId: selectedDept?.id || '',
										department: selectedDept?.name || '',
									});
								}}
								disabled={!form.program}>
								<SelectTrigger className="w-full">
									<SelectValue placeholder="Select Department" />
								</SelectTrigger>
								<SelectContent>
									{departments.map(dept => (
										<SelectItem key={dept.id} value={dept.id}>
											{dept.name}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						)}
					</div>

					{/* Section */}
					<div className="flex flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">Section</Label>
						<Input
							value={form.section || ''}
							placeholder="Enter section"
							type="text"
							onChange={e => setForm({ ...form, section: e.target.value })}
							disabled={isView}
							className={isView ? 'cursor-not-allowed bg-gray-100' : ''}
						/>
					</div>

					{/* Graduation Year */}
					<div className="flex flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">
							Graduation Year
						</Label>
						<Input
							value={form.graduationYear || ''}
							placeholder="Enter graduation year"
							type="text"
							onChange={e => setForm({ ...form, graduationYear: Number(e.target.value) })}
							disabled={isView}
							className={isView ? 'cursor-not-allowed bg-gray-100' : ''}
						/>
					</div>

					{/* Batch */}
					<div className="flex flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">Batch</Label>
						<Input
							value={form.batch || ''}
							placeholder="Enter batch"
							type="text"
							onChange={e => setForm({ ...form, batch: e.target.value })}
							disabled={isView}
							className={isView ? 'cursor-not-allowed bg-gray-100' : ''}
						/>
					</div>

					{/* Status */}
					{isView && (
						<div className="flex flex-col">
							<Label className="text-muted-foreground mb-1 text-sm font-medium">Status</Label>
							<Input
								value={StatusCase[form.status as 'ACTIVE' | 'INACTIVE' | 'PENDING']}
								disabled
								className="cursor-not-allowed bg-gray-100"
							/>
						</div>
					)}
				</div>

				{/* Buttons */}
				{!isView && (
					<DialogFooter className="flex justify-end gap-3 pt-6">
						<Button
							variant="outline"
							onClick={() => onOpenChange(false)}
							className="border-gray-300 text-gray-600">
							Cancel
						</Button>
						<Button
							onClick={handleSubmit}
							className="bg-[var(--brandColor)] text-white hover:bg-[var(--brandColor-dark)]">
							{isEdit ? 'Update' : 'Add'}
						</Button>
					</DialogFooter>
				)}
			</DialogContent>
		</Dialog>
	);
}
