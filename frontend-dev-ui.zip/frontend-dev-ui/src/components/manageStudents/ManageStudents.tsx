import React, { useEffect, useState } from 'react';
import GlobalFilter, { type FilterFieldType, type FilterValue } from '@/components/common/Filter';
import StudentsTable, { type Student } from '@/components/manageStudents/StudentsTable';
import { getStudents, getProgramsWithDepartments } from '@/services';
import { toast } from 'sonner';

interface Program {
	departments: Department[];
}

interface Department {
	id: string;
	name: string;
}

const StudentManager: React.FC = () => {
	const [students, setStudents] = useState<Student[]>([]);
	const [filterValues, setFilterValues] = useState<Record<string, FilterValue>>({});
	const [departments, setDepartments] = useState<{ value: string; label: string }[]>([]);
	const [search, setSearch] = useState('');
	const [page, setPage] = useState(1);
	const [limit, setLimit] = useState(10); // changed to match defaults
	const [meta, setMeta] = useState({ total: 0, totalPages: 1, page: 1, limit: 10 });

	// 🔹 Fetch departments on mount
	useEffect(() => {
		const fetchDepartments = async () => {
			const res = await getProgramsWithDepartments();
			if (res.success && res.data) {
				// Flatten programs + their departments
				const deptOptions = res.data.flatMap((program: Program) =>
					program.departments.map((dept: Department) => ({
						value: dept.id,
						label: dept.name,
					})),
				);
				setDepartments(deptOptions);
			} else {
				toast.error(res.message || 'Failed to fetch departments');
			}
		};
		fetchDepartments();
	}, []);

	// 🔹 Fetch students whenever filters/search/pagination change
	useEffect(() => {
		const fetchStudents = async () => {
			const response = await getStudents({
				page,
				limit,
				search,
				departmentId: filterValues.departmentId as string,
				status: filterValues.status as string,
			});

			if (response.success && response.data) {
				setStudents(response.data.students);
				setMeta(response.data.meta);
			} else {
				toast.error(response.message || 'Error fetching students');
				setStudents([]);
			}
		};
		fetchStudents();
	}, [page, limit, search, filterValues]);

	// 🔹 Filter fields (dynamic departments)
	const filterFields: FilterFieldType[] = [
		{
			type: 'select',
			id: 'departmentId',
			label: 'Department',
			options: departments,
		},
		{
			type: 'select',
			id: 'status',
			label: 'Status',
			options: [
				{ value: 'ACTIVE', label: 'Active' },
				{ value: 'INACTIVE', label: 'Inactive' },
				{ value: 'PENDING', label: 'Pending' },
			],
		},
	];

	return (
		<div className="flex min-h-[calc(99vh-5rem)] w-full flex-col gap-4 px-4 py-3 md:flex-row md:gap-3.5">
			<GlobalFilter fields={filterFields} initialValues={filterValues} onChange={setFilterValues} />

			<div className="flex flex-1 flex-col gap-3">
				<StudentsTable
					students={students}
					search={search}
					onSearchChange={setSearch}
					page={meta.page}
					totalPages={meta.totalPages}
					total={meta.total}
					onPageChange={setPage}
					limit={meta.limit}
					onLimitChange={newLimit => {
						setLimit(newLimit);
						setPage(1);
					}}
				/>
			</div>
		</div>
	);
};

export default StudentManager;
