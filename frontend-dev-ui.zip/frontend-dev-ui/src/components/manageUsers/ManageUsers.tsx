import React, { useEffect, useState } from 'react';
import GlobalFilter, { type FilterFieldType, type FilterValue } from '@/components/common/Filter';
import UsersTable, { type User } from '@/components/manageUsers/UsersTable';
import { getUsers, getRolesForUser } from '@/services';
import { toast } from 'sonner';

interface Role {
	roleId: string;
	name: string;
}

const UserManager: React.FC = () => {
	const [users, setUsers] = useState<User[]>([]);
	const [filterValues, setFilterValues] = useState<Record<string, FilterValue>>({});
	const [roles, setRoles] = useState<{ value: string; label: string }[]>([]);
	const [search, setSearch] = useState('');
	const [page, setPage] = useState(1);
	const [limit, setLimit] = useState(10);
	const [meta, setMeta] = useState({ total: 0, totalPages: 1, page: 1, limit: 10 });

	// 🔹 Fetch roles (same logic as in UserModal)
	useEffect(() => {
		const fetchRoles = async () => {
			try {
				const response = await getRolesForUser();
				if (response.success && response.data) {
					const roleOptions = response.data.map((role: Role) => ({
						value: role.roleId,
						label: role.name,
					}));
					setRoles(roleOptions);
				} else {
					toast.error(response.message || 'Error fetching roles');
				}
			} catch {
				toast.error('Error fetching roles');
			}
		};
		fetchRoles();
	}, []);

	// 🔹 Fetch users when filters/search/pagination change
	useEffect(() => {
		const fetchUsers = async () => {
			const response = await getUsers({
				page,
				limit,
				search,
				roleId: filterValues.roleId as string,
				status: filterValues.status as string,
			});

			if (response.success && response.data) {
				if (Array.isArray(response.data.users)) {
					setUsers(response.data.users);
					setMeta(response.data.meta);
				}
			} else {
				toast.error(response.message || 'Error fetching users');
				setUsers([]);
			}
		};
		fetchUsers();
	}, [page, limit, search, filterValues]);

	// 🔹 Define filter fields
	const filterFields: FilterFieldType[] = [
		{
			type: 'select',
			id: 'roleId',
			label: 'Role',
			options: roles,
		},
		{
			type: 'select',
			id: 'status',
			label: 'Status',
			options: [
				{ value: 'ACTIVE', label: 'Active' },
				{ value: 'INACTIVE', label: 'Inactive' },
				{ value: 'PENDING', label: 'Pending' },
			],
		},
	];

	return (
		<div className="flex min-h-[calc(99vh-5rem)] w-full flex-col gap-4 px-4 py-3 md:flex-row md:gap-3.5">
			{/* 🔹 Sidebar Filters */}
			<GlobalFilter fields={filterFields} initialValues={filterValues} onChange={setFilterValues} />

			{/* 🔹 Users Table */}
			<div className="flex flex-1 flex-col gap-3">
				<UsersTable
					users={users}
					search={search}
					onSearchChange={setSearch}
					page={meta.page}
					totalPages={meta.totalPages}
					total={meta.total}
					onPageChange={setPage}
					limit={meta.limit}
					onLimitChange={newLimit => {
						setLimit(newLimit);
						setPage(1);
					}}
				/>
			</div>
		</div>
	);
};

export default UserManager;
