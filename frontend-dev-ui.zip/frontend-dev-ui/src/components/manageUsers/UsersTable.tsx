import { Label } from '@/components/ui/label';
import { CircleIcon, EllipsisVerticalIcon, InboxIcon, PlusIcon, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from '@/components/ui/table';
import clsx from 'clsx';
import { useState } from 'react';
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuTrigger,
} from '../ui/dropdown-menu';
import UserModal from './UserModal';
import CommonModal from '../common/Modal';
import { toast } from 'sonner';
import { updateUserStatus } from '@/services';
import PaginationBar from '../common/Pagination';
import HoverSearchInfoPopover from '@/components/common/SearchInfo'; // <-- use your path

export type User = {
	userId: string;
	userName: string;
	email: string;
	role: string;
	roleId: string;
	phoneNumber?: string;
	status: 'ACTIVE' | 'INACTIVE' | 'PENDING';
};

export const StatusCase = {
	ACTIVE: 'Active',
	INACTIVE: 'Inactive',
	PENDING: 'Pending',
};

interface UsersTableProps {
	users: User[];
	search: string;
	onSearchChange: (value: string) => void;
	page: number;
	totalPages: number;
	total: number;
	onPageChange: (page: number) => void;
	limit: number;
	onLimitChange: (limit: number) => void;
}

export default function UsersTable({
	users,
	search,
	onSearchChange,
	page,
	totalPages,
	total,
	onPageChange,
	limit,
	onLimitChange,
}: UsersTableProps) {
	const [open, setOpen] = useState(false);
	const [editUser, setEditUser] = useState<User | null>(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [confirmAction, setConfirmAction] = useState<'ACTIVATE' | 'DEACTIVATE' | null>(null);
	const [selectedUser, setSelectedUser] = useState<User | null>(null);
	const [modalMode, setModalMode] = useState<'edit' | 'view' | 'add'>('edit');

	const editUserData = (user: User) => {
		setEditUser(user);
	};

	const handleConfirm = async () => {
		if (!selectedUser || !confirmAction) return;
		const status = confirmAction === 'ACTIVATE' ? 'ACTIVE' : 'INACTIVE';
		const res = await updateUserStatus({ userId: selectedUser.userId, status });
		if (res.success) {
			toast.success(
				`User ${selectedUser.userName} has been ${status === 'ACTIVE' ? 'activated' : 'deactivated'} successfully`,
			);
			window.location.reload();
		} else {
			toast.error(res.message || 'Failed to update user status');
		}
		setConfirmOpen(false);
		setConfirmAction(null);
		setSelectedUser(null);
	};

	return (
		<div className="h-fit min-h-[calc(99vh-5rem)] flex-1 rounded-lg bg-white p-6">
			{/* Header Section */}
			<div className="mb-4 flex items-center justify-between">
				<Label className="text-lg font-semibold text-gray-700">Users</Label>
				<div className="flex flex-row items-center">
					<div>
						<span className="px-3 text-sm text-gray-500">
							Showing {page} of {totalPages} ({total} users)
						</span>
					</div>
					<Button
						className="gap-2 bg-[var(--brandColor)] px-4 py-2 text-white hover:bg-[var(--brandColor-dark)]"
						onClick={() => {
							setEditUser(null);
							setModalMode('add');
							setOpen(true);
						}}>
						<PlusIcon className="h-4 w-4" />
						<span className="font-medium">Add User</span>
					</Button>
				</div>
			</div>

			{/* Search Section (with search info popover) */}
			<div className="flex items-center gap-3 pb-4">
				<div className="w-3xs relative flex items-center">
					<span className="absolute left-3">
						<Search className="h-4 w-4 text-gray-400" />
					</span>
					<input
						type="text"
						placeholder="Search Users"
						value={search}
						onChange={e => onSearchChange(e.target.value)}
						className="w-full rounded-md border border-gray-300 py-2 pl-9 pr-12 text-sm focus:border-[var(--brandColor)] focus:ring-0"
					/>
					<span className="absolute right-3 z-10">
						<HoverSearchInfoPopover fields={['Name', 'Email', 'PhoneNo']} align="end" />
					</span>
				</div>
				<Button className="gap-2 bg-[var(--brandColor)] px-6 py-2 text-white hover:bg-[var(--brandColor-dark)]">
					<Search />
					<span className="font-medium">Search</span>
				</Button>
			</div>

			{/* Table Section */}
			<div className="flex max-h-[65vh] min-h-[50vh] flex-col justify-between overflow-hidden rounded-md">
				<div className="scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-transparent flex-1 overflow-y-auto">
					<Table>
						<TableHeader className="bg-gray-100/70">
							<TableRow className="!border-b-0">
								{['S. No', 'Name', 'Role', 'Email/Phone', 'Login Status', 'Action'].map(h => (
									<TableHead key={h} className="px-4 py-3 font-semibold text-gray-500/80">
										{h}
									</TableHead>
								))}
							</TableRow>
						</TableHeader>
						<TableBody>
							{users.length > 0 ? (
								users.map((user, index) => (
									<TableRow
										key={user.userId}
										onClick={() => {
											setEditUser(user);
											setModalMode('view');
											setOpen(true);
										}}
										className="cursor-pointer border-b transition-colors last:border-b-0 hover:bg-gray-50/70">
										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{(page - 1) * limit + (index + 1)}
										</TableCell>
										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{user.userName}
										</TableCell>
										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{user.role || '—'}
										</TableCell>
										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{user.email}
											<br />
											{user.phoneNumber}
										</TableCell>
										<TableCell className="px-4 py-3">
											<div className="flex items-center gap-2 text-gray-500/90">
												<CircleIcon
													className={clsx(
														'h-3 w-3 fill-current',
														user.status === 'ACTIVE'
															? 'text-[var(--brandColor)]'
															: user.status === 'PENDING'
																? 'text-[var(--brandYellow)]'
																: 'text-[var(--brandRed)]',
													)}
													aria-hidden="true"
												/>
												<span
													className="font-medium"
													aria-label={`User status: ${StatusCase[user.status]}`}>
													{StatusCase[user.status]}
												</span>
											</div>
										</TableCell>
										<TableCell className="px-4 py-3">
											<DropdownMenu>
												<DropdownMenuTrigger asChild>
													<Button
														variant="outline"
														className="size-8.5 cursor-pointer border-gray-200 text-[var(--brandColor)] !shadow-none hover:!border-[var(--brandColor)] hover:!bg-[var(--brandAccent)] hover:!text-[var(--brandColor-dark)]"
														aria-label={`Actions for ${user.userName}`}>
														<EllipsisVerticalIcon aria-hidden="true" />
													</Button>
												</DropdownMenuTrigger>
												<DropdownMenuContent
													align="end"
													className="w-36 text-gray-500"
													role="menu"
													aria-label={`Actions for ${user.userName}`}>
													{(user.status === 'ACTIVE' || user.status === 'INACTIVE') && (
														<DropdownMenuItem
															onClick={e => {
																e.stopPropagation();
																editUserData(user);
																setModalMode('edit');
																setOpen(true);
															}}
															role="menuitem"
															aria-label={`Edit ${user.userName}`}>
															Edit
														</DropdownMenuItem>
													)}
													{user.status === 'ACTIVE' && (
														<DropdownMenuItem
															onClick={e => {
																e.stopPropagation();
																setSelectedUser(user);
																setConfirmAction('DEACTIVATE');
																setConfirmOpen(true);
															}}
															role="menuitem"
															aria-label={`Deactivate ${user.userName}`}>
															Deactivate
														</DropdownMenuItem>
													)}
													{user.status === 'INACTIVE' && (
														<DropdownMenuItem
															onClick={e => {
																e.stopPropagation();
																setSelectedUser(user);
																setConfirmAction('ACTIVATE');
																setConfirmOpen(true);
															}}
															role="menuitem"
															aria-label={`Activate ${user.userName}`}>
															Activate
														</DropdownMenuItem>
													)}
													{user.status === 'PENDING' && (
														<>
															<DropdownMenuItem
																onClick={e => {
																	e.stopPropagation();
																	toast.info(`Send mail to ${user.userName}`);
																}}
																role="menuitem"
																aria-label={`Send mail to ${user.userName}`}>
																Send Mail
															</DropdownMenuItem>
															<DropdownMenuItem
																role="menuitem"
																aria-label={`Revoke ${user.userName}`}>
																Revoke
															</DropdownMenuItem>
														</>
													)}
												</DropdownMenuContent>
											</DropdownMenu>
										</TableCell>
									</TableRow>
								))
							) : (
								<TableRow>
									<TableCell colSpan={6} className="py-12 text-center">
										<div className="flex flex-col items-center gap-2 text-gray-400">
											<InboxIcon className="h-10 w-10" />
											<span className="text-sm font-medium">No data</span>
										</div>
									</TableCell>
								</TableRow>
							)}
						</TableBody>
					</Table>
				</div>
			</div>

			<div className="mt-4 flex justify-end">
				<PaginationBar
					page={page}
					totalPages={totalPages}
					limit={limit}
					onLimitChange={onLimitChange}
					onPageChange={onPageChange}
				/>
			</div>

			<UserModal open={open} onOpenChange={setOpen} user={editUser} mode={modalMode} />
			<CommonModal
				isOpen={confirmOpen}
				onOpenChange={setConfirmOpen}
				title={`Confirm ${confirmAction === 'ACTIVATE' ? 'Activation' : 'Deactivation'}`}
				description={`Are you sure you want to ${confirmAction?.toLowerCase()} ${selectedUser?.userName}?`}
				confirmText="Yes"
				cancelText="Cancel"
				onConfirm={handleConfirm}
			/>
		</div>
	);
}
