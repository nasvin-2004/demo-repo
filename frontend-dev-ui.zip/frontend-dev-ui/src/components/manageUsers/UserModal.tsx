'use client';

import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from '@/components/ui/select';
import { useState, useEffect } from 'react';
import { StatusCase, type User } from './UsersTable';
import { toast } from 'sonner';
import { addUser, getRolesForUser, updateUser, type SimpleRole } from '@/services';

export default function UserModal({
	open,
	onOpenChange,
	user,
	mode,
}: {
	open: boolean;
	onOpenChange: (b: boolean) => void;
	user: User | null;
	mode: 'edit' | 'view' | 'add';
}) {
	const [form, setForm] = useState<Partial<User>>({
		userName: '',
		email: '',
		role: '',
		status: 'ACTIVE',
	});
	const [roles, setRoles] = useState<SimpleRole[]>([]);

	const fields = [
		{ id: 'userName', label: 'Name', placeholder: 'Enter name', type: 'text' },
		{ id: 'email', label: 'Email', placeholder: 'Enter email', type: 'email' },
		{ id: 'phoneNumber', label: 'Phone', placeholder: 'Enter phone', type: 'text' },
	];

	useEffect(() => {
		if (user) setForm(user);
		else setForm({ userName: '', email: '', role: '', status: 'ACTIVE' });
	}, [user]);

	useEffect(() => {
		const fetchRoles = async () => {
			const response = await getRolesForUser();
			if (response.success && response.data) {
				setRoles(response.data);
			} else {
				toast.error(response.message || 'Error fetching roles');
			}
		};
		fetchRoles();
	}, []);

	useEffect(() => {
		if (user && roles.length) {
			const matchedRole = roles.find(r => r.roleId === user.roleId);
			setForm(prev => ({
				...prev,
				...user,
				roleId: user.roleId,
				role: matchedRole ? matchedRole.name : user.role || '',
			}));
		}
	}, [user, roles]);

	const isView = mode === 'view';
	const isAdd = mode === 'add';
	const isEdit = mode === 'edit';

	const handleSubmit = async () => {
		let response;
		if (isEdit) {
			response = await updateUser({
				userId: form.userId as string,
				userName: form.userName as string,
				email: form.email as string,
				phoneNumber: form.phoneNumber,
				roleId: form.roleId as string,
			});
		} else if (isAdd) {
			response = await addUser({
				userName: form.userName as string,
				email: form.email as string,
				phoneNumber: form.phoneNumber,
				roleId: form.roleId as string,
			});
		}

		if (response?.success) {
			toast.success(response.message || 'Operation successful');
			onOpenChange(false);
			window.location.reload();
		} else {
			toast.error(response?.message || 'Something went wrong');
		}
	};

	return (
		<Dialog open={open} onOpenChange={onOpenChange}>
			<DialogContent className="max-w-[500px] rounded-lg bg-white p-6">
				<DialogHeader>
					<DialogTitle className="text-lg font-semibold text-gray-600">
						{isEdit ? 'Edit User' : isView ? 'View User' : 'Add New User'}
					</DialogTitle>
					<DialogDescription className="sr-only">
						{mode === 'view'
							? 'View user details'
							: mode === 'edit'
								? 'Edit user information'
								: 'Add a new user'}
					</DialogDescription>
				</DialogHeader>

				<div className="space-y-5 py-4">
					{fields.map(field => (
						<div key={field.id} className="flex flex-col">
							<Label className="text-muted-foreground mb-1 text-sm font-medium">
								{field.label}
							</Label>
							<Input
								value={form[field.id as keyof typeof form] || ''}
								placeholder={field.placeholder}
								type={field.type}
								onChange={e => setForm({ ...form, [field.id]: e.target.value })}
								disabled={isView}
								className={isView ? 'cursor-not-allowed bg-gray-100' : ''}
							/>
						</div>
					))}

					{/* Role Select */}
					<div className="flex flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">Role</Label>
						{isView ? (
							<Input value={form.role || '—'} disabled className="cursor-not-allowed bg-gray-100" />
						) : (
							<Select
								value={form.roleId ?? ''}
								onValueChange={value =>
									setForm({
										...form,
										roleId: value,
										role: roles.find(r => r.roleId === value)?.name,
									})
								}>
								<SelectTrigger className="w-full">
									<SelectValue placeholder="Select role" />
								</SelectTrigger>
								<SelectContent>
									{roles.map((role, idx) => (
										<SelectItem key={role.roleId ?? idx} value={role.roleId}>
											{role.name}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						)}
					</div>

					{/* Status field (View Only) */}
					{isView && (
						<div className="flex flex-col">
							<Label className="text-muted-foreground mb-1 text-sm font-medium">Status</Label>
							<Input
								value={StatusCase[form.status as 'ACTIVE' | 'INACTIVE' | 'PENDING']}
								disabled
								className="cursor-not-allowed bg-gray-100"
							/>
						</div>
					)}
				</div>

				{/* Footer */}
				{!isView && (
					<DialogFooter className="flex justify-end gap-3 pt-6">
						<Button
							variant="outline"
							onClick={() => onOpenChange(false)}
							className="border-gray-300 text-gray-600">
							Cancel
						</Button>
						<Button
							onClick={handleSubmit}
							className="bg-[var(--brandColor)] text-white hover:bg-[var(--brandColor-dark)]">
							{isEdit ? 'Update' : 'Add'}
						</Button>
					</DialogFooter>
				)}
			</DialogContent>
		</Dialog>
	);
}
