import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import {
	ChevronDownIcon,
	ChevronLeftIcon,
	ChevronRightIcon,
	MessageCircleIcon,
} from 'lucide-react';

interface CandidateStatus {
	label: string;
	count: number;
	percentage: number;
	color: string;
}

export default function PipelineStatus() {
	const candidateStatuses: CandidateStatus[] = [
		{
			label: 'Selected',
			count: 8,
			percentage: 72.7,
			color: 'bg-green-500',
		},
		{
			label: 'Rejected',
			count: 3,
			percentage: 27.3,
			color: 'bg-gray-400',
		},
		{
			label: 'Drop Off',
			count: 0,
			percentage: 0.0,
			color: 'bg-green-500',
		},
		{
			label: 'No Show',
			count: 0,
			percentage: 0.0,
			color: 'bg-gray-400',
		},
	];

	return (
		<Card className="border-0 bg-white shadow-sm">
			<CardHeader className="pb-4">
				<div className="flex items-center justify-between">
					<CardTitle className="text-lg font-semibold text-gray-900">
						Pipeline Status - Internal
					</CardTitle>
					<Select defaultValue="last-month">
						<SelectTrigger className="h-8 w-32 text-sm">
							<SelectValue />
							<ChevronDownIcon className="ml-2 h-4 w-4" />
						</SelectTrigger>
						<SelectContent>
							<SelectItem value="last-week">Last Week</SelectItem>
							<SelectItem value="last-month">Last Month</SelectItem>
							<SelectItem value="last-quarter">Last Quarter</SelectItem>
						</SelectContent>
					</Select>
				</div>
			</CardHeader>
			<CardContent>
				<div className="flex flex-col items-center space-y-6">
					{/* Candidate Status Breakdown */}
					<div className="w-full space-y-3">
						{candidateStatuses.map((status, index) => (
							<div
								key={index}
								className="flex items-center justify-between rounded-lg bg-gray-50 p-3">
								<div className="flex items-center gap-3">
									<div className={`h-3 w-3 rounded-full ${status.color}`}></div>
									<span className="text-sm font-medium text-gray-700">{status.label}</span>
								</div>
								<span className="text-sm text-gray-600">
									{status.count} ({status.percentage}%) Candidates
								</span>
							</div>
						))}
					</div>

					{/* Navigation arrows */}
					<div className="flex w-full items-center justify-between">
						<Button variant="outline" size="icon" className="h-8 w-8">
							<ChevronLeftIcon className="h-4 w-4" />
						</Button>
						<Button variant="outline" size="icon" className="h-8 w-8">
							<ChevronRightIcon className="h-4 w-4" />
						</Button>
					</div>
				</div>

				{/* Chat button */}
				<div className="absolute bottom-4 right-4">
					<Button
						size="icon"
						className="h-12 w-12 rounded-full bg-green-500 shadow-lg hover:bg-green-600">
						<MessageCircleIcon className="h-6 w-6 text-white" />
					</Button>
				</div>
			</CardContent>
		</Card>
	);
}
