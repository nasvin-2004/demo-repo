import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from '@/components/ui/select';
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from '@/components/ui/table';
import { ChevronDownIcon } from 'lucide-react';

interface VacancyData {
	jobTitle: string;
	closeDate: string;
	clientName: string;
	extendDeadline: string;
}

export default function VacancyOverview() {
	const vacancyData: VacancyData[] = [
		{
			jobTitle: 'Web Developer',
			closeDate: '01 Nov 2025',
			clientName: 'Mastech Digital',
			extendDeadline: '01 Nov 2025',
		},
	];

	return (
		<Card className="border-0 bg-white shadow-sm">
			<CardHeader className="pb-4">
				<div className="flex items-center justify-between">
					<CardTitle className="text-lg font-semibold text-gray-900">Vacancy Overview</CardTitle>
				</div>
				<div className="flex items-center justify-between">
					<h3 className="text-sm font-medium text-gray-700">Positions Nearing Close Date</h3>
					<Select defaultValue="next-week">
						<SelectTrigger className="h-8 w-32 text-sm">
							<SelectValue />
							<ChevronDownIcon className="ml-2 h-4 w-4" />
						</SelectTrigger>
						<SelectContent>
							<SelectItem value="next-week">Next Week</SelectItem>
							<SelectItem value="next-month">Next Month</SelectItem>
							<SelectItem value="next-quarter">Next Quarter</SelectItem>
						</SelectContent>
					</Select>
				</div>
			</CardHeader>
			<CardContent>
				<Table>
					<TableHeader>
						<TableRow className="bg-gray-50">
							<TableHead className="font-medium text-gray-700">Job Title</TableHead>
							<TableHead className="font-medium text-gray-700">Close Date</TableHead>
							<TableHead className="font-medium text-gray-700">Client Name</TableHead>
							<TableHead className="font-medium text-gray-700">Extend Deadline</TableHead>
						</TableRow>
					</TableHeader>
					<TableBody>
						{vacancyData.map((vacancy, index) => (
							<TableRow key={index} className="hover:bg-gray-50">
								<TableCell className="font-medium">{vacancy.jobTitle}</TableCell>
								<TableCell>{vacancy.closeDate}</TableCell>
								<TableCell>{vacancy.clientName}</TableCell>
								<TableCell>{vacancy.extendDeadline}</TableCell>
							</TableRow>
						))}
					</TableBody>
				</Table>
			</CardContent>
		</Card>
	);
}
