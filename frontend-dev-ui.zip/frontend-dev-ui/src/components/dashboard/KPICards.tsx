import { FileTextIcon, UsersIcon, UserCheckIcon, ActivityIcon } from 'lucide-react';

interface KPICardProps {
	title: string;
	value: string;
	icon: React.ComponentType<{ className?: string }>;
}

const KPICard = ({ title, value, icon: Icon }: KPICardProps) => {
	return (
		<div className=" h-24 rounded-lg border-0 border-l-4 border-[#11B981] bg-white shadow-sm">
			<div className="h-full p-6">
				<div className="flex h-full items-center justify-start gap-4">
					{/* Icon */}
					<div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-100">
						<Icon className="h-4 w-4 text-teal-600" />
					</div>

					{/* Content */}
					<div>
						<p className="mb-1 text-[14px] text-[#758b89]">{title}</p>
						<p className="text-2xl font-bold text-black">{value}</p>
					</div>
				</div>
			</div>
		</div>
	);
};

export default function KPICards() {
	const kpiData = [
		{
			title: 'Active Vacancies',
			value: '130',
			icon: FileTextIcon,
		},
		{
			title: 'Open Positions',
			value: '219',
			icon: UsersIcon,
		},
		{
			title: 'Total Candidates',
			value: '190',
			icon: UserCheckIcon,
		},
		{
			title: 'Active Users',
			value: '17',
			icon: ActivityIcon,
		},
	];

	return (
		<div className="mb-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
			{kpiData.map((kpi, index) => (
				<KPICard key={index} title={kpi.title} value={kpi.value} icon={kpi.icon} />
			))}
		</div>
	);
}
