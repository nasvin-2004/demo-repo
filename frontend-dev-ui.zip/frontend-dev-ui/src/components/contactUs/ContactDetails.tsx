import { Mail, Phone } from 'lucide-react';

export default function ContactDetails() {
	return (
		<div className="flex hidden flex-col gap-7 lg:flex">
			<div className="h-70 flex w-80 flex-col items-center justify-center gap-4 rounded-lg bg-emerald-100/60 tracking-wide">
				<h1 className="text-[28px] font-bold text-[var(--brandColor)]">Why Subscribe?</h1>
				<div className="flex flex-col justify-center gap-2">
					<div className="flex items-center gap-2 ">
						<svg
							className="text-xs text-[var(--brandColor)]"
							viewBox="64 64 896 896"
							focusable="false"
							data-icon="check"
							width="1em"
							height="1em"
							fill="currentColor"
							aria-hidden="true">
							<path d="M912 190h-69.9c-9.8 0-19.1 4.5-25.1 12.2L404.7 724.5 207 474a32 32 0 00-25.1-12.2H112c-6.7 0-10.4 7.7-6.3 12.9l273.9 347c12.8 16.2 37.4 16.2 50.3 0l488.4-618.9c4.1-5.1.4-12.8-6.3-12.8z"></path>
						</svg>
						<p>Access to premium features</p>
					</div>
					<div className="flex items-center gap-2">
						<svg
							className="text-xs text-[var(--brandColor)]"
							viewBox="64 64 896 896"
							focusable="false"
							data-icon="check"
							width="1em"
							height="1em"
							fill="currentColor"
							aria-hidden="true">
							<path d="M912 190h-69.9c-9.8 0-19.1 4.5-25.1 12.2L404.7 724.5 207 474a32 32 0 00-25.1-12.2H112c-6.7 0-10.4 7.7-6.3 12.9l273.9 347c12.8 16.2 37.4 16.2 50.3 0l488.4-618.9c4.1-5.1.4-12.8-6.3-12.8z"></path>
						</svg>
						<p>Priority customer support</p>
					</div>
					<div className="flex items-center gap-2">
						<svg
							className="text-xs text-[var(--brandColor)]"
							viewBox="64 64 896 896"
							focusable="false"
							data-icon="check"
							width="1em"
							height="1em"
							fill="currentColor"
							aria-hidden="true">
							<path d="M912 190h-69.9c-9.8 0-19.1 4.5-25.1 12.2L404.7 724.5 207 474a32 32 0 00-25.1-12.2H112c-6.7 0-10.4 7.7-6.3 12.9l273.9 347c12.8 16.2 37.4 16.2 50.3 0l488.4-618.9c4.1-5.1.4-12.8-6.3-12.8z"></path>
						</svg>
						<p>Access to premium features</p>
					</div>
					<div className="flex items-center gap-2 ">
						<svg
							className="text-xs text-[var(--brandColor)]"
							viewBox="64 64 896 896"
							focusable="false"
							data-icon="check"
							width="1em"
							height="1em"
							fill="currentColor"
							aria-hidden="true">
							<path d="M912 190h-69.9c-9.8 0-19.1 4.5-25.1 12.2L404.7 724.5 207 474a32 32 0 00-25.1-12.2H112c-6.7 0-10.4 7.7-6.3 12.9l273.9 347c12.8 16.2 37.4 16.2 50.3 0l488.4-618.9c4.1-5.1.4-12.8-6.3-12.8z"></path>
						</svg>
						<p>Priority customer support</p>
					</div>
				</div>
			</div>
			<div className="flex flex-col gap-4">
				<div className="flex items-center gap-4 text-[var(--brandColor-dark)] hover:text-[#007e5e]">
					<Mail />
					<p className="text-[20px] text-gray-900 hover:text-[var(--brandColor-dark)]">
						contact@qconnect.com
					</p>
				</div>
				<div className="flex items-center gap-4 text-[var(--brandColor-dark)] hover:text-[#007e5e]">
					<Phone />
					<p className="text-[20px] text-gray-900 hover:text-[var(--brandColor-dark)]">
						+91 9999999999
					</p>
				</div>
			</div>
		</div>
	);
}
