export default function ContactHeader() {
	return (
		<div className="flex flex-col items-center justify-center p-8">
			<h1 className="p-2 text-[42px] font-black text-[var(--brandColor)]  ">Get In Touch</h1>
			<p className="text-center text-[18px] tracking-wide text-gray-700">
				Ready to start your subscription? Contact us today!
			</p>
		</div>
	);
}
