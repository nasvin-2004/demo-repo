'use client';
import { useState } from 'react';
import { Button } from '../ui/button';
import { Send } from 'lucide-react';
import { toast } from 'sonner';
import { ErrorHandler } from '@/lib/error-handler';
import { submitContactForm } from '@/services';

export default function ContactForm() {
	const [formData, setFormData] = useState({
		name: '',
		email: '',
		phone: '',
		message: '',
	});
	const [loading, setLoading] = useState(false);

	const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
		setFormData({ ...formData, [e.target.name]: e.target.value });
	};

	// const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
	// 	e.preventDefault();
	// 	setLoading(true);

	// 	try {
	// 		const res = await fetch('http://127.0.0.1:3000/contact/', {
	// 			method: 'POST',
	// 			headers: { 'Content-Type': 'application/json' },
	// 			body: JSON.stringify(formData),
	// 		});

	// 		const data = await res.json();

	// 		if (res.ok && data.success) {
	// 			toast.success("Request sent successfully! We'll get back to you shortly.");
	// 			setFormData({ name: '', email: '', phone: '', message: '' });
	// 		} else {
	// 			toast.error(data.message || 'Failed to send request. Please try again.');
	// 		}
	// 	} catch (err) {
	// 		ErrorHandler.logError(err);
	// 		toast.error('Something went wrong. Please try again later.');
	// 	} finally {
	// 		setLoading(false);
	// 	}
	// };

	const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
		setLoading(true);
		e.preventDefault();
		const response = await submitContactForm(formData);
		if (response.success) {
			toast.success("Request sent successfully! We'll get back to you shortly.");
			setFormData({ name: '', email: '', phone: '', message: '' });
		} else {
			toast.error(response.message || 'Failed to send request. Please try again.');
			ErrorHandler.logError(response.error);
		}
		setLoading(false);
	};

	return (
		<div className="w-[90vw] lg:w-[40vw]">
			<div className="rounded-lg border-2 border-emerald-500 bg-white p-8">
				<h2 className="mb-6 text-2xl font-semibold text-emerald-500">Request Subscription</h2>

				<form onSubmit={handleSubmit} className="space-y-4" aria-label="Contact form">
					<div>
						<label htmlFor="name" className="mb-2 block font-medium text-gray-700">
							Name
						</label>
						<input
							type="text"
							id="name"
							name="name"
							value={formData.name}
							onChange={handleChange}
							required
							className="w-full rounded-lg border-2 border-gray-200 px-4 py-2 transition focus:border-emerald-500 focus:outline-none"
							placeholder="Your name"
							aria-describedby="name-help"
						/>
						<div id="name-help" className="sr-only">
							Enter your full name
						</div>
					</div>

					<div>
						<label htmlFor="email" className="mb-2 block font-medium text-gray-700">
							Email
						</label>
						<input
							type="email"
							id="email"
							name="email"
							value={formData.email}
							onChange={handleChange}
							required
							className="w-full rounded-lg border-2 border-gray-200 px-4 py-2 transition focus:border-emerald-500 focus:outline-none"
							placeholder="Your email"
							aria-describedby="email-help"
						/>
						<div id="email-help" className="sr-only">
							Enter a valid email address
						</div>
					</div>

					<div>
						<label htmlFor="phone" className="mb-2 block font-medium text-gray-700">
							Phone
						</label>
						<input
							type="tel"
							id="phone"
							name="phone"
							value={formData.phone}
							onChange={handleChange}
							className="w-full rounded-lg border-2 border-gray-200 px-4 py-2 transition focus:border-emerald-500 focus:outline-none"
							placeholder="Your phone number"
							aria-describedby="phone-help"
						/>
						<div id="phone-help" className="sr-only">
							Enter your phone number (optional)
						</div>
					</div>

					<div>
						<label htmlFor="message" className="mb-2 block font-medium text-gray-700">
							Message
						</label>
						<textarea
							id="message"
							name="message"
							value={formData.message}
							onChange={handleChange}
							required
							rows={4}
							className="w-full resize-none rounded-lg border-2 border-gray-200 px-4 py-2 transition focus:border-emerald-500 focus:outline-none"
							placeholder="Tell us about your subscription needs..."
							aria-describedby="message-help"
						/>
						<div id="message-help" className="sr-only">
							Describe your subscription requirements
						</div>
					</div>

					<Button
						type="submit"
						disabled={loading}
						className="flex w-[50%] items-center justify-center space-x-2 justify-self-center rounded-lg bg-emerald-500 py-5 font-semibold text-white transition hover:bg-emerald-600"
						aria-label={loading ? 'Sending your request' : 'Send contact request'}>
						<span>{loading ? 'Sending...' : 'Send Request'}</span>
						<Send size={20} aria-hidden="true" />
					</Button>
				</form>
			</div>
		</div>
	);
}
