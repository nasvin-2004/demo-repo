import ContactDetails from './ContactDetails';
import ContactForm from './ContactForm';
import ContactHeader from './ContactHeader';

export default function ContactUs() {
	return (
		<div className="p-2">
			<ContactHeader />
			<div className="flex justify-center gap-10 ">
				<ContactDetails />
				<ContactForm />
			</div>
		</div>
	);
}
