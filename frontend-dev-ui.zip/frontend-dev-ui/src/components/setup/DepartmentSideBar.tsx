'use client';

import clsx from 'clsx';
import { GraduationCap, Building2Icon } from 'lucide-react';
import { Button } from '@/components/ui/button';

const SIDEBAR_ITEMS = [
	{ key: 'programs', label: 'Programs', Icon: GraduationCap },
	{ key: 'departments', label: 'Departments', Icon: Building2Icon },
];

export default function SettingsSidebar({
	active,
	onSelect,
}: {
	active: string;
	onSelect: (key: string) => void;
}) {
	const handleSelect = (key: string) => {
		const url = new URL(window.location.href);
		url.searchParams.set('tab', key);
		window.history.pushState({}, '', url.toString());
		onSelect(key);
	};

	return (
		<div className="h-fit w-full rounded-lg bg-white p-4 md:min-h-[calc(99vh-5rem)] md:w-1/5">
			<div className="flex flex-col gap-1.5">
				{SIDEBAR_ITEMS.map(({ key, label, Icon }) => {
					const isActive = active === key;
					return (
						<Button
							key={key}
							onClick={() => handleSelect(key)}
							variant="ghost"
							className={clsx(
								'flex cursor-pointer items-center justify-start gap-2 rounded-md px-3 py-2.5 transition-all',
								isActive
									? 'bg-[var(--brandAccent)] text-[var(--brandColor-dark)]'
									: 'hover:bg-[var(--brandAccent)]/50 text-gray-500 hover:text-[var(--brandColor)]',
							)}>
							<Icon className="h-4 w-4 flex-shrink-0" />
							<span className="text-sm font-medium">{label}</span>
						</Button>
					);
				})}
			</div>
		</div>
	);
}
