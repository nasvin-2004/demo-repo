'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { PlusIcon, EllipsisVerticalIcon, Search } from 'lucide-react';
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
	Select,
	SelectTrigger,
	SelectValue,
	SelectContent,
	SelectItem,
} from '@/components/ui/select';
import DepartmentModal from '@/components/setup/DepartmentModel';
import CommonModal from '@/components/common/Modal';
import { toast } from 'sonner';
import {
	getDepartments,
	createDepartment,
	editDepartment,
	deleteDepartment,
	type DepartmentData,
} from '@/services';
import { getPrograms, type ProgramData } from '@/services/program.service';

export type Department = {
	id: string;
	name: string;
	programId: string;
	programName: string;
};

const DepartmentManager: React.FC = () => {
	const [departments, setDepartments] = useState<Department[]>([]);
	const [programs, setPrograms] = useState<{ id: string; name: string }[]>([]);
	const [loading, setLoading] = useState(true);
	const [modalOpen, setModalOpen] = useState(false);
	const [modalMode, setModalMode] = useState<'add' | 'edit' | 'view'>('add');
	const [selectedDept, setSelectedDept] = useState<Department | null>(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [submitting, setSubmitting] = useState(false);
	const [search, setSearch] = useState('');
	const [selectedProgram, setSelectedProgram] = useState<string>('all');

	// Fetch departments
	const fetchDepartments = useCallback(async (searchTerm = '', programId?: string) => {
		const params: Record<string, string> = {};
		if (searchTerm) params.search = searchTerm;
		if (programId && programId !== 'all') params.programId = programId;

		const response = await getDepartments(params);
		if (response.success && response.data) {
			const formatted: Department[] = response.data.map((d: DepartmentData) => ({
				id: d.departmentId,
				name: d.departmentName,
				programId: d.programId,
				programName: d.programName,
			}));
			setDepartments(formatted);
		} else {
			toast.error(response.message || 'Failed to fetch departments');
		}
	}, []);

	// Fetch programs
	const fetchPrograms = useCallback(async () => {
		const response = await getPrograms();
		if (response.success && response.data) {
			const formatted = response.data.map((p: ProgramData) => ({
				id: p.programId,
				name: p.programName,
			}));
			setPrograms(formatted);
		} else {
			toast.error(response.message || 'Failed to fetch programs');
		}
	}, []);

	// Fetch initial data
	const fetchInitialData = useCallback(async () => {
		setLoading(true);
		await Promise.all([fetchDepartments(), fetchPrograms()]);
		setLoading(false);
	}, [fetchDepartments, fetchPrograms]);

	useEffect(() => {
		fetchInitialData();
	}, [fetchInitialData]);

	// Debounced search
	useEffect(() => {
		const delay = setTimeout(() => {
			fetchDepartments(search, selectedProgram);
		}, 400);
		return () => clearTimeout(delay);
	}, [search, selectedProgram, fetchDepartments]);

	// CRUD Handlers
	const handleAdd = () => {
		setModalMode('add');
		setSelectedDept(null);
		setModalOpen(true);
	};

	const handleEdit = (department: Department) => {
		setModalMode('edit');
		setSelectedDept(department);
		setModalOpen(true);
	};

	const handleView = (department: Department) => {
		setModalMode('view');
		setSelectedDept(department);
		setModalOpen(true);
	};

	const handleDelete = (department: Department) => {
		setSelectedDept(department);
		setConfirmOpen(true);
	};

	const confirmDelete = async () => {
		if (!selectedDept) return;
		setSubmitting(true);
		const response = await deleteDepartment(selectedDept.id);

		if (response.success) {
			setDepartments(prev => prev.filter(d => d.id !== selectedDept.id));
			toast.success(response.message || `Department "${selectedDept.name}" deleted successfully`);
		} else {
			toast.error(response.message || 'Failed to delete department');
		}

		setSubmitting(false);
		setConfirmOpen(false);
	};

	// Add / Edit submit
	const handleSubmit = async (data: {
		id?: string;
		name: string;
		programId?: string;
		programName?: string;
		newProgram?: boolean;
	}) => {
		if (!data.name.trim()) {
			toast.error('Department name is required');
			return;
		}

		// Validate before submitting
		if (data.newProgram && !data.programName) {
			toast.error('Program name is required');
			return;
		}
		if (!data.newProgram && !data.programId) {
			toast.error('Program ID is required');
			return;
		}

		setSubmitting(true);

		if (modalMode === 'add') {
			const payload = data.newProgram
				? { programName: data.programName, departmentName: data.name }
				: { programId: data.programId, departmentName: data.name };

			const response = await createDepartment(payload);

			if (response.success && response.data) {
				const newDept: Department = {
					id: response.data.departmentId,
					name: response.data.departmentName,
					programId: response.data.programId,
					programName: response.data.programName,
				};
				setDepartments(prev => [...prev, newDept]);
				await fetchPrograms();
				await fetchDepartments(search, selectedProgram);
				toast.success(response.message || 'Department added successfully');
				setModalOpen(false);
			} else {
				toast.error(response.message || 'Failed to create department');
			}
		} else if (modalMode === 'edit' && data.id) {
			const payload = data.newProgram
				? {
						departmentId: data.id,
						programName: data.programName,
						departmentName: data.name,
					}
				: {
						departmentId: data.id,
						programId: data.programId,
						departmentName: data.name,
					};

			const response = await editDepartment(payload);

			if (response.success && response.data) {
				setDepartments(prev =>
					prev.map(d =>
						d.id === data.id
							? {
									...d,
									name: response.data?.departmentName as string,
									programId: response.data?.programId as string,
									programName: response.data?.programName as string,
								}
							: d,
					),
				);
				await fetchPrograms();
				await fetchDepartments(search, selectedProgram);
				toast.success(response.message || 'Department updated successfully');
				setModalOpen(false);
			} else {
				toast.error(response.message || 'Failed to update department');
			}
		}

		setSubmitting(false);
	};

	if (loading) {
		return (
			<div className="flex h-[calc(99vh-5rem)] items-center justify-center">
				<div className="text-gray-500">Loading departments...</div>
			</div>
		);
	}

	return (
		<div className="h-fit min-h-[calc(99vh-5rem)] flex-1 rounded-lg bg-white p-6">
			{/* Header */}
			<div className="mb-2 flex items-start justify-between">
				<Label className="text-lg font-semibold text-gray-700">Departments</Label>
				<Button
					className="gap-2 bg-[var(--brandColor)] px-4 py-2 text-white hover:bg-[var(--brandColor-dark)]"
					onClick={handleAdd}>
					<PlusIcon className="h-4 w-4" />
					<span className="font-medium">Add Department</span>
				</Button>
			</div>

			{/* Search and Filter */}
			<div className="flex flex-wrap items-center gap-3 pb-4">
				<div className="w-3xs relative flex items-center">
					<span className="absolute left-3">
						<Search className="h-4 w-4 text-gray-400" />
					</span>
					<input
						type="text"
						placeholder="Search Departments"
						value={search}
						onChange={e => setSearch(e.target.value)}
						className="w-full rounded-md border border-gray-300 py-2 pl-9 pr-9 text-sm focus:border-[var(--brandColor)] focus:ring-0"
					/>
				</div>

				<Select value={selectedProgram} onValueChange={value => setSelectedProgram(value)}>
					<SelectTrigger className="w-52">
						<SelectValue placeholder="Filter by Program" />
					</SelectTrigger>
					<SelectContent>
						<SelectItem value="all">All Programs</SelectItem>
						{programs.map(p => (
							<SelectItem key={p.id} value={p.id}>
								{p.name}
							</SelectItem>
						))}
					</SelectContent>
				</Select>

				<Button
					onClick={() => fetchDepartments(search, selectedProgram)}
					className="gap-2 bg-[var(--brandColor)] px-6 py-2 text-white hover:bg-[var(--brandColor-dark)]">
					<Search className="h-4 w-4" />
					<span className="font-medium">Search</span>
				</Button>
			</div>

			{/* Department Cards */}
			<div className="flex w-full flex-col gap-3">
				{departments.map(department => (
					<div
						key={department.id}
						role="button"
						tabIndex={0}
						onClick={() => handleView(department)}
						onKeyDown={e => {
							if (e.key === 'Enter' || e.key === ' ') {
								e.preventDefault();
								handleView(department);
							}
						}}
						className="group flex cursor-pointer items-center justify-between rounded-lg bg-white transition-shadow duration-300 focus:outline-none"
						style={{
							borderLeft: '4px solid #18C29C',
							borderRight: '1px solid #E5F7F2',
							borderTop: '1px solid #E5F7F2',
							borderBottom: '1px solid #E5F7F2',
						}}>
						<div className="min-w-0 flex-1 py-4 pl-6 pr-2">
							<span className="truncate font-normal text-gray-700">{department.name}</span>
							<span className="ml-2 text-xs text-gray-400">({department.programName})</span>
						</div>

						<div className="flex items-center pr-4">
							<DropdownMenu>
								<DropdownMenuTrigger asChild>
									<Button
										variant="outline"
										className="size-8.5 border-gray-200 text-[var(--brandColor)] !shadow-none hover:!border-[var(--brandColor)] hover:!bg-[var(--brandAccent)] hover:!text-[var(--brandColor-dark)]">
										<EllipsisVerticalIcon className="h-4 w-4" />
									</Button>
								</DropdownMenuTrigger>
								<DropdownMenuContent align="end" className="w-32 text-gray-500">
									<DropdownMenuItem onClick={() => handleEdit(department)}>Edit</DropdownMenuItem>
									<DropdownMenuItem onClick={() => handleDelete(department)}>
										Delete
									</DropdownMenuItem>
								</DropdownMenuContent>
							</DropdownMenu>
						</div>
					</div>
				))}
			</div>

			<DepartmentModal
				open={modalOpen}
				onOpenChange={setModalOpen}
				department={selectedDept}
				mode={modalMode}
				onSubmit={handleSubmit}
				programs={programs}
				submitting={submitting}
			/>

			<CommonModal
				isOpen={confirmOpen}
				onOpenChange={setConfirmOpen}
				title="Confirm Deletion"
				description={`Are you sure you want to delete "${selectedDept?.name}" department?`}
				confirmText="Yes, Delete"
				cancelText="Cancel"
				confirmVariant="destructive"
				onConfirm={confirmDelete}
				isLoading={submitting}
			/>
		</div>
	);
};

export default DepartmentManager;
