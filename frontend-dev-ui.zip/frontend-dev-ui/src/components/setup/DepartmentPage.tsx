import { useEffect, useState } from 'react';
import SettingsSidebar from '@/components/setup/DepartmentSideBar';
import DepartmentTable from './DepartmentTable';
import ProgramTable from './ProgramTable';

export default function DepartmentsPage() {
	const [active, setActive] = useState('departments');

	// On mount, check if ?tab=programs or ?tab=departments in URL
	useEffect(() => {
		const params = new URLSearchParams(window.location.search);
		const tab = params.get('tab');
		if (tab === 'programs' || tab === 'departments') {
			setActive(tab);
		}
	}, []);

	const renderContent = () => {
		switch (active) {
			case 'departments':
				return <DepartmentTable />;
			case 'programs':
				return <ProgramTable />;
			default:
				return null;
		}
	};

	return (
		<section className="w-full px-4 py-3">
			<div className="flex flex-col gap-2 md:flex-row md:gap-3.5">
				<SettingsSidebar active={active} onSelect={setActive} />
				{renderContent()}
			</div>
		</section>
	);
}
