'use client';

import React, { useEffect, useState } from 'react';
import CommonModal from '@/components/common/Modal';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from '@/components/ui/select';

export interface DepartmentModalProps {
	open: boolean;
	onOpenChange: (open: boolean) => void;
	department: { id?: string; name: string; programId: string; programName?: string } | null;
	mode: 'add' | 'edit' | 'view';
	onSubmit: (data: {
		id?: string;
		name: string;
		programId?: string;
		programName?: string;
		newProgram?: boolean;
	}) => void;
	programs: { id: string; name: string }[];
	submitting?: boolean;
}

const ADD_NEW_PROGRAM_VALUE = '__ADD_NEW_PROGRAM__';

const DepartmentModal: React.FC<DepartmentModalProps> = ({
	open,
	onOpenChange,
	department,
	mode,
	onSubmit,
	programs,
	submitting = false,
}) => {
	const [name, setName] = useState('');
	const [newProgramName, setNewProgramName] = useState('');
	const [selectValue, setSelectValue] = useState('');

	useEffect(() => {
		if (department) {
			setName(department.name);
			setNewProgramName('');
			setSelectValue(department.programId ? department.programId : '');
		} else {
			setName('');
			setNewProgramName('');
			setSelectValue('');
		}
	}, [department, open]);

	const handleSelectChange = (val: string) => {
		setSelectValue(val);
		if (val === ADD_NEW_PROGRAM_VALUE) {
			setNewProgramName('');
		} else {
			setNewProgramName('');
		}
	};

	const handleSubmit = () => {
		if (!name.trim()) return;

		if (selectValue === ADD_NEW_PROGRAM_VALUE && newProgramName.trim()) {
			onSubmit({
				id: department?.id,
				name,
				programName: newProgramName.trim(),
				newProgram: true,
			});
		} else if (selectValue && selectValue !== ADD_NEW_PROGRAM_VALUE) {
			onSubmit({
				id: department?.id,
				name,
				programId: selectValue,
				newProgram: false,
			});
		}
	};

	return (
		<CommonModal
			isOpen={open}
			onOpenChange={onOpenChange}
			title={
				mode === 'add'
					? 'Add Department'
					: mode === 'edit'
						? 'Edit Department'
						: 'Department Details'
			}
			description={
				mode === 'view'
					? 'View the department details below.'
					: mode === 'add'
						? 'Add a new department to the system.'
						: 'Edit the selected department.'
			}
			showCancel
			showConfirm={mode !== 'view'}
			confirmText={mode === 'add' ? 'Add' : 'Save Changes'}
			onConfirm={handleSubmit}
			isLoading={submitting}>
			<div className="space-y-3">
				<div className="flex gap-3">
					<div className="flex flex-1 flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">Select Program</Label>
						<Select
							disabled={mode === 'view' || submitting || !!newProgramName}
							value={selectValue}
							onValueChange={handleSelectChange}>
							<SelectTrigger className="border-border w-full rounded-sm border bg-white px-3 py-2">
								<SelectValue placeholder="Choose Program" />
							</SelectTrigger>
							<SelectContent>
								{programs.map(opt => (
									<SelectItem key={opt.id} value={opt.id}>
										{opt.name}
									</SelectItem>
								))}
								{/* Only show "+ Add New Program" option in add mode */}
								{mode === 'add' && (
									<SelectItem value={ADD_NEW_PROGRAM_VALUE}>+ Add New Program</SelectItem>
								)}
							</SelectContent>
						</Select>
					</div>
					{/* Render the new program input only if "+ Add New Program" selected */}
					{selectValue === ADD_NEW_PROGRAM_VALUE && (
						<div className="flex flex-1 flex-col">
							<Label
								htmlFor="newProgram"
								className="text-muted-foreground mb-1 text-sm font-medium">
								Add New Program
							</Label>
							<Input
								id="newProgram"
								placeholder="new program"
								value={newProgramName}
								disabled={mode === 'view' || submitting}
								onChange={e => setNewProgramName(e.target.value)}
							/>
						</div>
					)}
				</div>

				<div>
					<Label
						htmlFor="departmentName"
						className="text-muted-foreground mb-1 text-sm font-medium">
						Department Name
					</Label>
					<Input
						id="departmentName"
						placeholder="Enter department name"
						value={name}
						onChange={e => setName(e.target.value)}
						disabled={mode === 'view' || submitting}
					/>
				</div>
			</div>
		</CommonModal>
	);
};

export default DepartmentModal;
