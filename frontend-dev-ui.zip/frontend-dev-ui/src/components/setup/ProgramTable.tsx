'use client';

import React, { useState, useEffect } from 'react';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Plus, MoreVertical, Search } from 'lucide-react';
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import ProgramModal from '@/components/setup/ProgramModel';
import CommonModal from '@/components/common/Modal';
import {
	createProgram,
	getPrograms,
	editProgram,
	deleteProgram,
	type ProgramData,
} from '@/services/program.service';

export type Program = {
	id: string;
	name: string;
	isDefault?: boolean;
};

export default function ProgramTable() {
	const [programs, setPrograms] = useState<Program[]>([]);
	const [loading, setLoading] = useState(true);
	const [open, setOpen] = useState(false);
	const [modalMode, setModalMode] = useState<'add' | 'edit' | 'view'>('add');
	const [selectedProgram, setSelectedProgram] = useState<Program | null>(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [submitting, setSubmitting] = useState(false);
	const [search, setSearch] = useState('');

	// -------------------------------
	// Fetch Programs
	// -------------------------------
	const fetchPrograms = async (query = '') => {
		setLoading(true);
		try {
			const res = await getPrograms({ search: query });
			if (res.success && res.data) {
				const formatted: Program[] = res.data.map((p: ProgramData) => ({
					id: p.programId,
					name: p.programName,
					isDefault: p.isDefault,
				}));
				setPrograms(formatted);
			} else {
				toast.error(res.message || 'Failed to load programs');
			}
		} catch {
			toast.error('An unexpected error occurred');
		} finally {
			setLoading(false);
		}
	};

	useEffect(() => {
		fetchPrograms();
	}, []);

	// -------------------------------
	// Debounced Search
	// -------------------------------
	useEffect(() => {
		const delay = setTimeout(() => {
			fetchPrograms(search);
		}, 400);
		return () => clearTimeout(delay);
	}, [search]);

	// -------------------------------
	// CRUD handlers
	// -------------------------------
	const handleAdd = () => {
		setSelectedProgram(null);
		setModalMode('add');
		setOpen(true);
	};

	const handleEdit = (program: Program) => {
		setSelectedProgram(program);
		setModalMode('edit');
		setOpen(true);
	};

	const handleView = (program: Program) => {
		setSelectedProgram(program);
		setModalMode('view');
		setOpen(true);
	};

	const handleDeletePrompt = (program: Program) => {
		setSelectedProgram(program);
		setConfirmOpen(true);
	};

	const handleDelete = async () => {
		if (!selectedProgram) return;
		setSubmitting(true);
		try {
			const res = await deleteProgram(selectedProgram.id);
			if (res.success) {
				setPrograms(prev => prev.filter(p => p.id !== selectedProgram.id));
				toast.success(`Program "${selectedProgram.name}" deleted successfully`);
			} else {
				toast.error(res.message || 'Failed to delete program');
			}
		} catch {
			toast.error('Error deleting program');
		} finally {
			setSubmitting(false);
			setConfirmOpen(false);
			setSelectedProgram(null);
		}
	};

	const handleSubmit = async (data: { id?: string; name: string }) => {
		if (!data.name.trim()) {
			toast.error('Program name is required');
			return;
		}
		setSubmitting(true);

		try {
			if (modalMode === 'add') {
				const res = await createProgram({ programName: data.name });
				if (res.success && res.data) {
					setPrograms(prev => [
						...prev,
						{
							id: res.data?.programId as string,
							name: res.data?.programName as string,
							isDefault: res.data?.isDefault,
						},
					]);
					toast.success('Program added successfully');
					setOpen(false);
				} else toast.error(res.message || 'Failed to create program');
			} else if (modalMode === 'edit' && data.id) {
				const res = await editProgram({
					programId: data.id,
					programName: data.name,
				});
				if (res.success) {
					setPrograms(prev => prev.map(p => (p.id === data.id ? { ...p, name: data.name } : p)));
					toast.success('Program updated successfully');
					setOpen(false);
				} else toast.error(res.message || 'Failed to update program');
			}
		} catch {
			toast.error('An unexpected error occurred');
		} finally {
			setSubmitting(false);
		}
	};

	const handleSearchChange = (value: string) => setSearch(value);
	const handleSearchSubmit = () => fetchPrograms(search);

	// -------------------------------
	// Render
	// -------------------------------
	if (loading)
		return (
			<div className="flex h-[calc(99vh-5rem)] items-center justify-center">
				<div className="text-gray-500">Loading programs...</div>
			</div>
		);

	return (
		<div className="h-fit min-h-[calc(99vh-5rem)] flex-1 rounded-lg bg-white p-6">
			{/* Header */}
			<div className="mb-4 flex items-center justify-between">
				<Label className="text-lg font-semibold text-gray-700">Programs</Label>
				<div className="flex flex-row items-center">
					<Button
						className="gap-2 bg-[var(--brandColor)] px-4 py-2 text-white hover:bg-[var(--brandColor-dark)]"
						onClick={handleAdd}>
						<Plus className="h-4 w-4" />
						<span className="font-medium">Add Program</span>
					</Button>
				</div>
			</div>

			{/* Search Section */}
			<div className="flex items-center gap-3 pb-4">
				<div className="w-3xs relative flex items-center">
					<span className="absolute left-3">
						<Search className="h-4 w-4 text-gray-400" />
					</span>
					<input
						type="text"
						placeholder="Search Programs"
						value={search}
						onChange={e => handleSearchChange(e.target.value)}
						onKeyDown={e => e.key === 'Enter' && handleSearchSubmit()}
						className="w-full rounded-md border border-gray-300 py-2 pl-9 pr-9 text-sm focus:border-[var(--brandColor)] focus:ring-0"
					/>
				</div>

				<Button
					onClick={handleSearchSubmit}
					className="gap-2 bg-[var(--brandColor)] px-6 py-2 text-white hover:bg-[var(--brandColor-dark)]">
					<Search />
					<span className="font-medium">Search</span>
				</Button>
			</div>

			{/* Card List */}
			<div className="flex w-full flex-col gap-3">
				{programs.length > 0 ? (
					programs.map(program => (
						<button
							key={program.id}
							type="button"
							onClick={() => handleView(program)}
							onFocus={e =>
								e.currentTarget.classList.add('shadow-[0_2px_12px_0px_rgba(85,104,123,0.06)]')
							}
							onBlur={e =>
								e.currentTarget.classList.remove('shadow-[0_2px_12px_0px_rgba(85,104,123,0.06)]')
							}
							className="group flex cursor-pointer items-center justify-between rounded-lg bg-white transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-[var(--brandColor)] focus:ring-offset-1"
							style={{
								borderLeft: '4px solid #18C29C',
								borderRight: '1px solid #E5F7F2',
								borderTop: '1px solid #E5F7F2',
								borderBottom: '1px solid #E5F7F2',
							}}>
							{/* Program name */}
							<div className="flex min-w-0 flex-1 items-center">
								<span className="truncate py-4 pl-6 pr-2 text-base font-normal text-gray-700 group-hover:text-[var(--brandColor-dark)]">
									{program.name}
								</span>
							</div>

							{/* Actions */}
							<div className="flex items-center pr-4">
								<DropdownMenu>
									<DropdownMenuTrigger asChild>
										<Button
											variant="outline"
											className="size-8.5 border-gray-200 text-[var(--brandColor)] !shadow-none hover:!border-[var(--brandColor)] hover:!bg-[var(--brandAccent)] hover:!text-[var(--brandColor-dark)]">
											<MoreVertical className="h-4 w-4" />
										</Button>
									</DropdownMenuTrigger>
									<DropdownMenuContent align="end" className="w-32 text-gray-500">
										<DropdownMenuItem onClick={() => handleEdit(program)}>Edit</DropdownMenuItem>
										<DropdownMenuItem onClick={() => handleDeletePrompt(program)}>
											Delete
										</DropdownMenuItem>
									</DropdownMenuContent>
								</DropdownMenu>
							</div>
						</button>
					))
				) : (
					<div className="py-12 text-center">
						<div className="flex flex-col items-center gap-2 text-gray-400">
							<span className="text-sm font-medium">No Programs Found</span>
						</div>
					</div>
				)}
			</div>

			{/* Modals */}
			<ProgramModal
				open={open}
				onOpenChange={setOpen}
				program={selectedProgram}
				mode={modalMode}
				onSubmit={handleSubmit}
				submitting={submitting}
			/>
			<CommonModal
				isOpen={confirmOpen}
				onOpenChange={setConfirmOpen}
				title="Confirm Deletion"
				description={`Are you sure you want to delete "${selectedProgram?.name}"?`}
				confirmText="Delete"
				cancelText="Cancel"
				onConfirm={handleDelete}
				isLoading={submitting}
				confirmVariant="destructive"
			/>
		</div>
	);
}
