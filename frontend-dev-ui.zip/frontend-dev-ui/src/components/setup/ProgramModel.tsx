'use client';

import React, { useEffect, useState } from 'react';
import CommonModal from '@/components/common/Modal';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import type { Program } from './ProgramTable';

interface ProgramModalProps {
	open: boolean;
	onOpenChange: (open: boolean) => void;
	program: Program | null;
	mode: 'add' | 'edit' | 'view';
	onSubmit: (data: { id?: string; name: string }) => void;
	submitting?: boolean;
}

const ProgramModal: React.FC<ProgramModalProps> = ({
	open,
	onOpenChange,
	program,
	mode,
	onSubmit,
	submitting = false,
}) => {
	const [name, setName] = useState('');

	useEffect(() => {
		if (program) setName(program.name);
		else setName('');
	}, [program]);

	const handleSubmit = () => {
		if (!name.trim()) return;
		onSubmit({ id: program?.id, name });
	};

	return (
		<CommonModal
			isOpen={open}
			onOpenChange={onOpenChange}
			title={mode === 'add' ? 'Add Program' : mode === 'edit' ? 'Edit Program' : 'Program Details'}
			description={
				mode === 'view'
					? 'View the program details below.'
					: mode === 'add'
						? 'Add a new program to the system.'
						: 'Edit the selected program.'
			}
			showCancel
			showConfirm={mode !== 'view'}
			confirmText={mode === 'add' ? 'Add' : 'Save Changes'}
			onConfirm={handleSubmit}
			isLoading={submitting}>
			<div className="space-y-3">
				<div>
					<Label htmlFor="programName" className="text-muted-foreground mb-1 text-sm font-medium">
						Program Name
					</Label>
					<Input
						id="programName"
						placeholder="Enter program name"
						value={name}
						onChange={e => setName(e.target.value)}
						disabled={mode === 'view' || submitting}
					/>
				</div>
			</div>
		</CommonModal>
	);
};

export default ProgramModal;
