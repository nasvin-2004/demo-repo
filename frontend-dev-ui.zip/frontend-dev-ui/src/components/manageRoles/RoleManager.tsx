import { useEffect, useState } from 'react';
import GlobalFilter, { type FilterFieldType, type FilterValue } from '@/components/common/Filter';
import RolePage, { type Role } from '@/components/manageRoles/RolePage';
// import api from '@/lib/api';
// import { ErrorHandler } from '@/lib/error-handler';
import { getRoles } from '@/services';

export default function RoleManager() {
	const [roles, setRoles] = useState<Role[]>([]);
	const [filterValues, setFilterValues] = useState<Record<string, FilterValue>>({});
	useEffect(() => {
		fetchRoles();
	}, []);

	const fetchRoles = async () => {
		const serviceRoles: Role[] = await getRoles();

		const formattedRoles: Role[] = serviceRoles.map(r => ({
			id: r.id,
			role: r.role,
			members: r.members ?? 0,
			activeCount: r.activeCount ?? 0,
			inactiveCount: r.inactiveCount ?? 0,
			isSystemRole: r.isSystemRole ?? false,
		}));
		setRoles(formattedRoles);
	};

	const filteredRoles = roles.filter(role =>
		Object.keys(filterValues).every(key => {
			const filterVal = filterValues[key];
			if (!filterVal) return true;
			return String(role[key]).toLowerCase().includes(filterVal.toString().toLowerCase());
		}),
	);

	const filterFields: FilterFieldType[] = [
		{ type: 'text', id: 'role', label: 'Role' },
		{ type: 'number', id: 'members', label: 'Members' },
		{ type: 'number', id: 'activeCount', label: 'Active Count' },
		{ type: 'number', id: 'inactiveCount', label: 'Inactive Count' },
	];

	return (
		<div className="flex min-h-[calc(99vh-5rem)] w-full flex-col gap-2 px-4 py-3 md:flex-row md:gap-3.5">
			<GlobalFilter
				fields={filterFields}
				initialValues={filterValues}
				onChange={values => setFilterValues(values)}
			/>

			<RolePage roles={filteredRoles} />
		</div>
	);
}
