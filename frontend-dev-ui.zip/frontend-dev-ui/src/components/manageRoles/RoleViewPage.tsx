import React, { useState, useEffect } from 'react';
import { Switch } from '@/components/ui/switch';
// import api from '@/lib/api';
import { getModulesWithActions, getRolePermissions, type ModuleItems } from '@/services';
import { ErrorHandler } from '@/lib/error-handler';
import { ChevronLeft } from 'lucide-react';

interface ActionPermission {
	name: string;
	allowed: boolean;
}

interface ModulePermission {
	module: string;
	actions: ActionPermission[];
}

interface RoleViewPageProps {
	roleId: string;
	roleName: string; // ✅ new prop
}

const RoleViewPage: React.FC<RoleViewPageProps> = ({ roleId, roleName }) => {
	const [permissions, setPermissions] = useState<ModulePermission[]>([]);
	const [loading, setLoading] = useState(true);

	useEffect(() => {
		const fetchPermissions = async () => {
			try {
				const [modulesRes, roleRes] = await Promise.all([
					getModulesWithActions(),
					getRolePermissions(roleId),
				]);
				const modulesData: ModuleItems[] = modulesRes.data ?? [];
				const rolePermData: ModuleItems[] = roleRes.data ?? [];

				const formattedPermissions: ModulePermission[] = modulesData.map((mod: ModuleItems) => {
					const rolePerm = rolePermData.find(
						(p: ModuleItems) => p.module.toLowerCase() === mod.module.toLowerCase(),
					);

					const actions = mod.actions.map((action: string) => ({
						name: action,
						allowed:
							rolePerm?.actions?.some((a: string) => a.toLowerCase() === action.toLowerCase()) ||
							false,
					}));

					return { module: mod.module, actions };
				});

				setPermissions(formattedPermissions);
			} catch (err) {
				ErrorHandler.logError(err);
			} finally {
				setLoading(false);
			}
		};
		fetchPermissions();
	}, [roleId]);

	if (loading) return <div className="p-10 text-gray-600">Loading...</div>;

	return (
		<div className="flex h-full min-h-[calc(99vh-5rem)] w-full flex-col gap-2 overflow-hidden md:gap-3.5">
			<div className="flex flex-col gap-4 border-t bg-white px-8 py-5 lg:flex-row lg:items-center lg:justify-between">
				<div className="flex items-center gap-2">
					<button
						onClick={() => history.back()}
						className="flex cursor-pointer items-center justify-center hover:!bg-transparent">
						<ChevronLeft className="h-6 w-6 text-gray-600" />
					</button>
					<h1 className="text-lg font-semibold text-gray-800">{roleName} Role</h1>
				</div>
			</div>

			<div className="mx-4 mb-3 flex-1 overflow-auto rounded-lg bg-white px-8 py-6">
				<table className="w-full">
					<thead>
						<tr className="text-left">
							<th className="w-1/4 pb-6 pr-8 text-base font-semibold text-gray-900">Modules</th>
							<th className="pb-6 text-base font-semibold text-gray-900">Actions</th>
						</tr>
					</thead>
					<tbody>
						{permissions.map((perm, i) => (
							<tr key={i} className="border-b border-gray-100 align-top last:border-0">
								<td className="py-5 pr-8 text-sm font-medium text-gray-900">{perm.module}</td>
								<td className="py-5">
									<div className="flex flex-wrap gap-8">
										{perm.actions.map((action, j) => (
											<div key={j} className="flex flex-col items-start gap-2">
												<span className="text-xs font-medium capitalize text-gray-700">
													{action.name}
												</span>
												<Switch
													checked={action.allowed}
													disabled
													className="data-[state=checked]:bg-[#02B686]"
												/>
											</div>
										))}
									</div>
								</td>
							</tr>
						))}
					</tbody>
				</table>
			</div>
		</div>
	);
};

export default RoleViewPage;
