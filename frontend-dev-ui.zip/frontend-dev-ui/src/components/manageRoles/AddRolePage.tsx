import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { ErrorHandler } from '@/lib/error-handler';
// import api from '@/lib/api';
import { getModulesWithActions, type ModuleItems } from '@/services';
import { createRole } from '@/services';
import { ChevronLeft } from 'lucide-react';
import { toast } from 'sonner';

interface ActionPermission {
	name: string;
	allowed: boolean;
}

interface ModulePermission {
	module: string;
	actions: ActionPermission[];
}

const AddRolePage: React.FC = () => {
	const [roleName, setRoleName] = useState('');
	const [permissions, setPermissions] = useState<ModulePermission[]>([]);
	const [loading, setLoading] = useState(true);

	useEffect(() => {
		(async () => {
			try {
				const res = await getModulesWithActions();
				if (!res.success) throw new Error(res.message || 'Failed to fetch modules');
				const initialPermissions: ModulePermission[] = res.data
					? res.data.map((mod: ModuleItems) => ({
							module: mod.module,
							actions: mod.actions.map(act => ({ name: act, allowed: false })),
						}))
					: [];
				setPermissions(initialPermissions);
			} catch (err) {
				ErrorHandler.logError(err);
				toast.error('Failed to load modules.');
			} finally {
				setLoading(false);
			}
		})();
	}, []);

	const handleToggle = (module: string, action: string) => {
		setPermissions(prev =>
			prev.map(perm =>
				perm.module === module
					? {
							...perm,
							actions: perm.actions.map(a =>
								a.name === action ? { ...a, allowed: !a.allowed } : a,
							),
						}
					: perm,
			),
		);
	};

	const handleSave = async () => {
		const payload = {
			roleName,
			permissions: permissions.map(p => ({
				module: p.module,
				actions: p.actions.filter(a => a.allowed).map(a => a.name),
			})),
		};
		try {
			const res = await createRole(payload);
			if (res.success) {
				toast.success('Role created successfully!');
				setTimeout(() => {
					window.location.href = '/manageRoles';
				}, 1000);
			} else {
				toast.error(`${res.message || 'Failed to create role'}`);
			}
		} catch (err) {
			ErrorHandler.logError(err);
			toast.error('Error creating role');
		}
	};

	if (loading) return <div className="p-10 text-gray-600">Loading...</div>;

	return (
		<div className="flex h-full min-h-[calc(99vh-5rem)] w-full flex-col gap-2 overflow-hidden md:gap-3.5">
			<div className="flex flex-col gap-4 border-t bg-white px-8 py-4 lg:flex-row lg:items-center lg:justify-between">
				<div className="flex items-center gap-2">
					<button
						onClick={() => history.back()}
						className="flex cursor-pointer items-center justify-center hover:!bg-transparent">
						<ChevronLeft className="h-6 w-6 text-gray-600" />
					</button>
					<h1 className="text-lg font-semibold text-gray-800">Add Role</h1>
				</div>

				<div className="flex flex-col gap-3 sm:flex-row sm:items-center">
					<Input
						value={roleName}
						onChange={e => setRoleName(e.target.value)}
						placeholder="Enter Role Name"
						className="w-full sm:w-80"
					/>

					<Button
						onClick={handleSave}
						className="bg-[var(--brandColor)] px-8 py-2 font-medium text-white transition-colors hover:bg-[var(--brandColor-dark)]">
						Save
					</Button>
				</div>
			</div>

			<div className="mx-4 mb-3 flex-1 overflow-auto rounded-lg bg-white px-8 py-6">
				<table className="w-full">
					<thead>
						<tr className="text-left">
							<th className="w-1/4 pb-6 pr-8 text-base font-semibold text-gray-900">Modules</th>
							<th className="pb-6 text-base font-semibold text-gray-900">Actions</th>
						</tr>
					</thead>
					<tbody>
						{permissions.map((perm, i) => (
							<tr key={i} className="border-b border-gray-100 align-top last:border-0">
								<td className="py-5 pr-8 text-sm font-medium text-gray-900">{perm.module}</td>
								<td className="py-5">
									<div className="flex flex-wrap gap-8">
										{perm.actions.map((action, j) => (
											<div key={j} className="flex flex-col items-start gap-2">
												<span className="text-xs font-medium capitalize text-gray-700">
													{action.name}
												</span>
												<Switch
													checked={action.allowed}
													onCheckedChange={() => handleToggle(perm.module, action.name)}
													className="data-[state=checked]:bg-[#02B686]"
												/>
											</div>
										))}
									</div>
								</td>
							</tr>
						))}
					</tbody>
				</table>
			</div>
		</div>
	);
};

export default AddRolePage;
