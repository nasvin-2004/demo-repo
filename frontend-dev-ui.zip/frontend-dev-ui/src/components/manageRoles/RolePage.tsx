import { Button } from '@/components/ui/button';
import { Eye, EllipsisVerticalIcon, InboxIcon, PlusIcon } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import type { FilterValue } from '@/components/common/Filter';
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuTrigger,
} from '../ui/dropdown-menu';
// import api from '@/lib/api';
import { toast } from 'sonner';
import { Label } from '../ui/label';
import { deleteRole } from '@/services';
import { useState } from 'react';
import CommonModal from '../common/Modal';

export interface Role {
	id: string;
	role: string;
	members: number;
	activeCount: number;
	inactiveCount: number;
	isSystemRole: boolean;
	readonly [key: string]: FilterValue;
}

// const ITEMS_PER_PAGE = 5;

export default function RolePage({ roles }: { roles: Role[] }) {
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [deleteId, setDeleteId] = useState<string | null>(null);
	const [deleteName, setDeleteName] = useState<string>('');

	const handleView = (id: string, name: string) => {
		window.location.href = `/manageRoles/view-role/${id}?name=${encodeURIComponent(name)}`;
	};

	const handleEdit = (id: string, name: string) => {
		window.location.href = `/manageRoles/edit-role/${id}?name=${encodeURIComponent(name)}`;
	};

	const handleDeleteClick = (id: string, name: string) => {
		setDeleteId(id);
		setDeleteName(name);
		setConfirmOpen(true);
	};

	const handleConfirmDelete = async () => {
		if (!deleteId) return;
		const success = await deleteRole(deleteId);
		if (success) {
			toast.success('Role deleted successfully!');
			window.location.reload();
		} else {
			toast.error('Failed to delete role');
		}
		setConfirmOpen(false);
	};

	return (
		<div className="h-fit min-h-[calc(99vh-5rem)] flex-1 rounded-lg bg-white p-6">
			<div className="mb-4 flex items-center justify-between">
				<Label className="text-lg font-semibold text-gray-700">Roles</Label>
				<a href="/manageRoles/add-role">
					<Button className="gap-2 bg-[var(--brandColor)] px-4 py-2 text-white hover:bg-[var(--brandColor-dark)]">
						<PlusIcon className="h-4 w-4" />
						<span className="font-medium">Add Role</span>
					</Button>
				</a>
			</div>

			<div className="overflow-hidden rounded-md">
				<Table>
					<TableHeader className="bg-gray-100/70">
						<TableRow className="!border-b-0">
							<TableHead className="px-4 py-3 font-semibold text-gray-500/80">S. No</TableHead>
							<TableHead className="px-4 py-3 font-semibold text-gray-500/80">Role</TableHead>
							<TableHead className="px-4 py-3 font-semibold text-gray-500/80">Members</TableHead>
							<TableHead className="px-4 py-3 font-semibold text-gray-500/80">Active</TableHead>
							<TableHead className="px-4 py-3 font-semibold text-gray-500/80">Inactive</TableHead>
							<TableHead className="px-4 py-3 font-semibold text-gray-500/80">Action</TableHead>
						</TableRow>
					</TableHeader>
					<TableBody>
						{roles.length > 0 ? (
							roles.map((item, index) => (
								<TableRow
									key={index}
									onClick={
										item.isSystemRole
											? () => handleView(item.id, item.role)
											: () => handleEdit(item.id, item.role)
									}
									className="cursor-pointer border-b transition-colors last:border-b-0 hover:bg-gray-50/70">
									<TableCell className="px-4 py-3 font-medium text-gray-500/90">
										{index + 1}
									</TableCell>
									<TableCell className="px-4 py-3 font-medium text-gray-500/90">
										{item.role}
									</TableCell>
									<TableCell className="px-4 py-3 font-medium text-gray-500/90">
										{item.members}
									</TableCell>
									<TableCell className="px-4 py-3 font-medium text-gray-500/90">
										{item.activeCount}
									</TableCell>
									<TableCell className="px-4 py-3 font-medium text-gray-500/90">
										{item.inactiveCount}
									</TableCell>
									<TableCell className="px-4 py-3">
										{item.isSystemRole ? (
											<Button
												variant="outline"
												onClick={e => {
													e.stopPropagation();
													handleView(item.id, item.role);
												}}
												className="size-8.5 border-gray-200 text-[var(--brandColor)] !shadow-none hover:!border-[var(--brandColor)] hover:!bg-[var(--brandAccent)] hover:!text-[var(--brandColor-dark)]">
												<Eye />
											</Button>
										) : (
											<DropdownMenu>
												<DropdownMenuTrigger asChild>
													<Button
														variant="outline"
														className="size-8.5 border-gray-200 text-[var(--brandColor)] !shadow-none hover:!border-[var(--brandColor)] hover:!bg-[var(--brandAccent)] hover:!text-[var(--brandColor-dark)]">
														<EllipsisVerticalIcon />
													</Button>
												</DropdownMenuTrigger>
												<DropdownMenuContent align="end" className="w-32 text-gray-500">
													<DropdownMenuItem
														onClick={e => {
															e.stopPropagation();
															handleEdit(item.id, item.role);
														}}>
														Edit
													</DropdownMenuItem>
													<DropdownMenuItem
														onClick={e => {
															e.stopPropagation();
															handleDeleteClick(item.id, item.role);
														}}>
														Delete
													</DropdownMenuItem>
												</DropdownMenuContent>
											</DropdownMenu>
										)}
									</TableCell>
								</TableRow>
							))
						) : (
							<TableRow>
								<TableCell colSpan={6} className="py-12 text-center">
									<div className="flex flex-col items-center gap-2 text-gray-400">
										<InboxIcon className="h-10 w-10" />
										<span className="text-sm font-medium">No data</span>
									</div>
								</TableCell>
							</TableRow>
						)}
					</TableBody>
				</Table>
			</div>
			<CommonModal
				isOpen={confirmOpen}
				onOpenChange={setConfirmOpen}
				title="Confirm Deletion"
				description={`Are you sure you want to delete the role "${deleteName}"? This action cannot be undone.`}
				confirmText="Delete"
				cancelText="Cancel"
				onConfirm={handleConfirmDelete}
			/>
		</div>
	);
}
