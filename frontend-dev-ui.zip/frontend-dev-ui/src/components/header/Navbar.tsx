import {
	NavigationMenu,
	NavigationMenuItem,
	NavigationMenuList,
	NavigationMenuTrigger,
	NavigationMenuContent,
} from '@/components/ui/navigation-menu';

import { Sidebar, SidebarContent, SidebarHeader, SidebarProvider } from '@/components/ui/sidebar';
import { NotificationsSidebar, type Notification } from './NotificationsSidebar';
import {
	UsersIcon,
	BarChart3Icon,
	MailIcon,
	XIcon,
	LayoutDashboardIcon,
	PieChartIcon,
	FileTextIcon,
	ChevronDownIcon,
	Bell,
	Code2,
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import ProfileDropdown from '@/components/header/ProfileDropDown';
import { CustomTrigger } from '@/components/header/CustomTrigger';
import { useSidebar } from '@/components/ui/sidebar';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useEffect, useState } from 'react';

import clsx from 'clsx';
import { $modules, verifyModuleAction, type ModuleItem } from '@/stores/moduleStore';
import { useStore } from '@nanostores/react';
import { $planAccess } from '@/stores/planStore';

const navItems = [
	{
		title: 'Dashboard',
		code: 'PUBLIC',
		icon: LayoutDashboardIcon,
		type: 'Link',
		href: '/dashboard',
	},
	{
		title: 'Playground',
		code: 'PLAYGROUND',
		icon: Code2,
		type: 'Link',
		href: '/playground',
	},
	{
		title: 'Students',
		code: 'STUDENTS',
		icon: UsersIcon,
		type: 'Link',
		href: '/students',
	},
	{
		title: 'Staffs',
		code: 'STAFF',
		icon: UsersIcon,
		type: 'Link',
		href: '/staffs',
	},
	{
		title: 'Reports',
		code: 'REPORTS',
		icon: BarChart3Icon,
		type: 'DropDown',
		links: [
			{
				name: 'Monthly',
				description: 'Review this months key statistics and insights.',
				icon: PieChartIcon,
				href: '/reports/monthly',
			},
			{
				name: 'Annual',
				description: 'Analyze yearly performance and trends.',
				icon: FileTextIcon,
				href: '/reports/annual',
			},
		],
	},
];

export default function Header({
	currentPath,
	modules,
}: {
	currentPath: string;
	modules: ModuleItem[];
}) {
	return (
		<SidebarProvider defaultOpen={false}>
			<MainHeader currentPath={currentPath} modules={modules} />
		</SidebarProvider>
	);
}

function MainHeader({ currentPath, modules }: { currentPath: string; modules: ModuleItem[] }) {
	const { setOpenMobile } = useSidebar();
	const modulesState = useStore($modules);
	const planAccess = useStore($planAccess);
	const [openIndex, setOpenIndex] = useState<number | null>(null);
	const [loaded, setLoaded] = useState(false);
	const [notifOpen, setNotifOpen] = useState(false);
	const sampleNotifications: Notification[] = [
		{
			title: 'Welcome!! - Team QR',
			message: 'Greetings! Welcome aboard, lets embark on a delightful journey together!',
			date: 'a few seconds ago',
			status: 'unread',
		},
	];

	useEffect(() => {
		if (modules && modules.length) {
			$modules.set(modules);
		}
		setLoaded(true);
	}, [modules]);

	if (!loaded) return null;

	const filteredNavItems = navItems
		.filter(item => item.code === 'PUBLIC' || verifyModuleAction(item.code, 'VIEW', modulesState))
		.map(item => {
			const restriction = planAccess.find(p => p.module === item.code);
			if (restriction && restriction.access === false) {
				return {
					...item,
					title: `${item.title} (Upgrade)`,
					href: '/billing', // override
				};
			}
			return item;
		});

	return (
		<header className="sticky top-0 z-50 h-[59px] w-full bg-white px-4 pt-1 shadow-sm">
			<div className="flex justify-between">
				{/* Logo Section */}
				<div className="flex items-center gap-3">
					<CustomTrigger />
					<a href="/" className="cursor-pointer">
						<img src="/Q-connect logo.png" alt="QConnect Logo" width={140} />{' '}
						{/*className="h-[38px] w-[140px]"*/}
					</a>

					{/* Navigation Menu (Desktop) */}
					<NavigationMenu className="hidden md:flex" viewport={false}>
						<NavigationMenuList
							className="flex items-center gap-8 text-sm"
							role="menubar"
							aria-label="Main navigation">
							{filteredNavItems.map((section, index) => {
								const selectedHref =
									section.type === 'Link'
										? currentPath === section.href
										: section.type === 'DropDown'
											? section.links?.some(link => link.href === currentPath)
											: false;

								if (section.type === 'DropDown') {
									if (!section.links?.length) return null;

									return (
										<NavigationMenuItem key={`${section.title}-${index}`}>
											<NavigationMenuTrigger
												className={clsx(
													'flex cursor-pointer flex-row items-center gap-1 !bg-transparent font-medium transition-colors hover:!bg-transparent',
													selectedHref
														? 'text-[var(--brandColor)] hover:!text-[var(--brandColor-dark)] data-[state=open]:!text-[var(--brandColor-dark)]'
														: 'text-gray-500 hover:!text-[var(--brandColor)] data-[state=open]:!text-[var(--brandColor)]',
												)}
												aria-label={`${section.title} menu`}
												aria-expanded={openIndex === index}>
												<section.icon className="h-4 w-4 text-inherit" aria-hidden="true" />
												{section.title}
											</NavigationMenuTrigger>

											<NavigationMenuContent
												className="w-auto min-w-[16rem] rounded-md border border-gray-100 bg-white p-2 shadow-md"
												role="menu"
												aria-label={`${section.title} submenu`}>
												<div className="flex flex-col">
													{section.links.map(link => (
														<a
															key={link.name}
															href={link.href}
															className={clsx(
																'flex w-full flex-row items-start gap-3 rounded-md p-2 text-left transition-colors hover:bg-slate-50',
																link.href === currentPath
																	? 'text-[var(--brandColor)] hover:!text-[var(--brandColor-dark)]'
																	: 'text-gray-500 hover:!text-[var(--brandColor)]',
															)}
															role="menuitem"
															aria-label={`${link.name}: ${link.description}`}>
															<link.icon
																className="mt-1 h-5 w-5 flex-shrink-0 text-inherit"
																aria-hidden="true"
															/>
															<div className="flex flex-col">
																<span className="text-sm font-medium">{link.name}</span>
																<span className="text-xs">{link.description}</span>
															</div>
														</a>
													))}
												</div>
											</NavigationMenuContent>
										</NavigationMenuItem>
									);
								}

								if (section.type === 'Link') {
									return (
										<NavigationMenuItem key={`${section.title}-${index}`}>
											<a
												href={section.href || '#'}
												className={clsx(
													'flex cursor-pointer flex-row items-center gap-1 !bg-transparent font-medium transition-colors hover:!bg-transparent',
													selectedHref
														? 'text-[var(--brandColor)] hover:!text-[var(--brandColor-dark)]'
														: 'text-gray-500 hover:!text-[var(--brandColor)]',
												)}
												role="menuitem"
												aria-label={`Navigate to ${section.title}`}
												aria-current={selectedHref ? 'page' : undefined}>
												<section.icon className="h-4 w-4 text-inherit" aria-hidden="true" />
												{section.title}
											</a>
										</NavigationMenuItem>
									);
								}

								return null;
							})}
						</NavigationMenuList>
					</NavigationMenu>
				</div>

				{/* Right Side - Icons and Profile */}
				<div className="flex items-center gap-5">
					<button
						className="h-5 w-5 cursor-pointer text-gray-600 transition-colors hover:text-[var(--brandColor)]"
						aria-label="Open notifications"
						onClick={() => setNotifOpen(true)}>
						<Bell className="h-5 w-5" aria-hidden="true"></Bell>
					</button>

					<button
						className="h-5 w-5 cursor-pointer text-gray-600 transition-colors hover:text-[var(--brandColor)]"
						aria-label="Open notifications">
						<MailIcon className="h-5 w-5" aria-hidden="true" />
					</button>
					<ProfileDropdown currentPath={currentPath} />
					<NotificationsSidebar
						open={notifOpen}
						setOpen={setNotifOpen}
						notifications={sampleNotifications}
						onReload={() => {
							/* reload logic */
						}}
						onMail={() => {
							/* mail logic */
						}}
					/>
				</div>
			</div>

			{/* Sidebar (Mobile) */}
			<Sidebar
				className="fixed inset-x-0 top-[59px] z-40 h-[calc(100vh-59px)] overflow-y-auto bg-white shadow-md md:hidden"
				role="navigation"
				aria-label="Mobile navigation menu">
				<SidebarHeader className="flex flex-row items-center justify-between border-b px-4">
					<h2 className="text-lg font-semibold text-gray-800">Menu</h2>
					<Button
						variant="ghost"
						size="icon"
						onClick={() => setOpenMobile(false)}
						aria-label="Close mobile menu">
						<XIcon className="h-5 w-5 text-gray-600" aria-hidden="true" />
					</Button>
				</SidebarHeader>

				<SidebarContent className="flex flex-col gap-2 p-4">
					{filteredNavItems.map((menu, index) => {
						const selectedHref =
							menu.type === 'Link'
								? currentPath === menu.href
								: menu.type === 'DropDown'
									? menu.links?.some(link => link.href === currentPath)
									: false;

						if (menu.type === 'DropDown') {
							if (!menu.links?.length) return null;

							return (
								<Collapsible
									key={`${menu.title}-${index}`}
									open={openIndex === index}
									onOpenChange={open => setOpenIndex(open ? index : null)}
									className="border-b pb-2">
									<CollapsibleTrigger asChild>
										<Button
											variant="ghost"
											className={clsx(
												'flex w-full items-center justify-between rounded-md px-3 py-2 font-medium hover:!bg-transparent',
												selectedHref
													? 'text-[var(--brandColor)] hover:!text-[var(--brandColor-dark)]'
													: 'text-gray-500 hover:!text-[var(--brandColor)]',
											)}>
											<div className="flex items-center gap-2">
												<menu.icon className="h-4 w-4" />
												<span>{menu.title}</span>
											</div>

											<ChevronDownIcon
												className={`h-4 w-4 transition-transform ${
													openIndex === index ? 'rotate-180' : ''
												}`}
											/>
										</Button>
									</CollapsibleTrigger>

									<CollapsibleContent className="flex flex-col gap-2 pl-3 pr-2 pt-2">
										{menu.links.map(item => (
											<div key={item.name} className="w-full">
												<a
													href={item.href}
													className={clsx(
														'h-18 flex w-full items-start gap-2 rounded-md bg-white px-3 py-2 text-left transition-colors hover:bg-slate-100',
														item.href === currentPath
															? 'text-[var(--brandColor)] hover:!text-[var(--brandColor-dark)]'
															: 'text-gray-500 hover:!text-[var(--brandColor)]',
													)}>
													<item.icon className="h-5 w-5 flex-shrink-0 text-inherit" />

													<div className="flex w-[85%] flex-col items-start text-left">
														<p className="break-words text-sm font-medium leading-tight">
															{item.name}
														</p>
														<p className="mt-0.5 whitespace-normal break-words text-xs leading-relaxed">
															{item.description}
														</p>
													</div>
												</a>
											</div>
										))}
									</CollapsibleContent>
								</Collapsible>
							);
						}

						if (menu.type === 'Link') {
							return (
								<div key={`${menu.title}-${index}`} className="border-b pb-2">
									<a
										href={menu.href || '#'}
										className={clsx(
											'flex w-full items-center justify-start rounded-md px-3 py-2 font-medium hover:!bg-transparent',
											selectedHref
												? 'text-[var(--brandColor)] hover:!text-[var(--brandColor-dark)]'
												: 'text-gray-500 hover:!text-[var(--brandColor)]',
										)}>
										<menu.icon className="h-4 w-4" />
										<span>{menu.title}</span>
									</a>
								</div>
							);
						}

						return null;
					})}
				</SidebarContent>
			</Sidebar>
		</header>
	);
}
