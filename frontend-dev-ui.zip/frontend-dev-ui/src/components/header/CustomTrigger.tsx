import { useSidebar } from '@/components/ui/sidebar';
import { MenuIcon } from 'lucide-react';
import { Button } from '../ui/button';

export function CustomTrigger() {
	const { toggleSidebar } = useSidebar();
	return (
		<Button
			data-sidebar="trigger"
			data-slot="sidebar-trigger"
			variant="ghost"
			size="icon"
			className="size-7 md:hidden"
			onClick={() => {
				toggleSidebar();
			}}>
			<MenuIcon />
			<span className="sr-only">Toggle Sidebar</span>
		</Button>
	);
}
