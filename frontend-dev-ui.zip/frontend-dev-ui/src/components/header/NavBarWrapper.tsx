/* eslint-disable @typescript-eslint/no-explicit-any */
import { useStore } from '@nanostores/react';
import { $auth } from '@/stores/profileStore';
import NavBar from '@/components/header/Navbar';

interface NavBarWrapperProps {
	currentPath: string;
	modules: any[];
}

export default function NavBarWrapper({ currentPath, modules }: NavBarWrapperProps) {
	const auth = useStore($auth);

	if (!auth) {
		return null;
	}

	return <NavBar currentPath={currentPath} modules={modules} />;
}
