'use client';

import { Sheet, SheetContent } from '@/components/ui/sheet';
import { X, RefreshCw, Mail } from 'lucide-react';
import clsx from 'clsx';

export type Notification = {
	title: string;
	message: string;
	date: string;
	status: 'unread' | 'read' | 'success' | 'error';
};

export function NotificationsSidebar({
	open,
	setOpen,
	notifications,
	onReload,
	onMail,
}: {
	open: boolean;
	setOpen: (b: boolean) => void;
	notifications: Notification[];
	onReload?: () => void;
	onMail?: () => void;
}) {
	return (
		<Sheet open={open} onOpenChange={setOpen}>
			<SheetContent
				side="right"
				className="flex w-[378px] flex-col !rounded-none border-l border-gray-200 bg-white p-0 shadow-xl [&_button[data-sheet-close]]:hidden">
				{/* Header */}
				<div className="flex items-center justify-between border-b bg-white px-6 py-4">
					<div className="flex items-center">
						<button
							className="h-5 w-5 cursor-pointer text-gray-600 transition-colors hover:text-gray-800"
							aria-label="Close notifications"
							onClick={() => setOpen(false)}>
							<X className="h-5 w-5" aria-hidden="true" />
						</button>
						<h2 className="pl-2.5 text-lg font-bold">Notifications</h2>
					</div>
					<div className="flex items-center gap-2">
						<button
							className="h-5 w-5 cursor-pointer text-gray-600 transition-colors hover:text-[var(--brandColor)]"
							aria-label="Reload notifications"
							onClick={onReload}>
							<RefreshCw className="h-4 w-4" />
						</button>
						<button
							className="h-5 w-5 cursor-pointer text-gray-600 transition-colors hover:text-[var(--brandColor)]"
							aria-label="Open mail notifications"
							onClick={onMail}>
							<Mail className="h-4 w-4" />
						</button>
					</div>
				</div>

				{/* Body */}
				<div className="flex-1 overflow-y-auto bg-white">
					<div className="flex flex-col gap-3 px-6 py-4">
						{notifications.length === 0 ? (
							<div className="mt-8 text-center text-sm text-gray-500">No notifications found</div>
						) : (
							notifications.map((n, idx) => (
								<div
									key={idx}
									className={clsx(
										'flex flex-col gap-1 rounded-lg bg-white px-4 py-3',
										n.status === 'error'
											? 'border border-red-200 bg-red-50'
											: 'border border-gray-200',
									)}>
									<div className="flex items-center gap-2">
										<h4 className="text-sm font-semibold">{n.title}</h4>
										{n.status !== 'error' && (
											<span className="relative ml-auto flex h-2 w-2">
												<span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-70" />
												<span className="relative inline-flex h-2 w-2 rounded-full bg-green-400" />
											</span>
										)}
									</div>
									<div className="text-sm text-gray-600">{n.message}</div>
									<span className="text-muted-foreground mt-0.5 text-xs">{n.date}</span>
								</div>
							))
						)}
					</div>
				</div>
			</SheetContent>
		</Sheet>
	);
}
