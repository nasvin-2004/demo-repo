'use client';

import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuSeparator,
	DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

import {
	UsersIcon,
	WrenchIcon,
	CreditCardIcon,
	SettingsIcon,
	LogOutIcon,
	UserRoundIcon,
	KeyRoundIcon,
} from 'lucide-react';

import clsx from 'clsx';
// import api from '@/lib/api';
import { useStore } from '@nanostores/react';
import { useEffect } from 'react';
import { $profile, clearProfile, loadProfileData } from '@/stores/profileStore';
import { logoutUser } from '@/services';
import { ErrorHandler } from '@/lib/error-handler';
import { toast } from 'sonner';

const menuItems = [
	{
		name: 'Manage Users',
		href: '/manageUser',
		icon: UsersIcon,
	},
	{
		name: 'Manage Roles',
		href: '/manageRoles',
		icon: KeyRoundIcon,
	},
	{
		name: 'Setup',
		href: '/setup',
		icon: WrenchIcon,
	},
	{
		name: 'Billing',
		href: '/billing',
		icon: CreditCardIcon,
	},
	{
		name: 'Settings',
		href: '/settings',
		icon: SettingsIcon,
	},
];

export default function ProfileDropdown({ currentPath }: { currentPath: string }) {
	const profile = useStore($profile);

	useEffect(() => {
		if (!profile) loadProfileData();
	}, [profile]);

	const handleLogout = async () => {
		const response = await logoutUser();
		if (response.success) {
			clearProfile();
			// Use full page reload for logout to clear all state
			window.location.href = '/';
		} else {
			ErrorHandler.logError(response.error);
			toast.error(response.message || 'Logout failed. Please try again.');
		}
	};

	const initials =
		profile?.name
			?.split(' ')
			.filter(Boolean)
			.map(w => w[0].toUpperCase())
			.join('') || 'U';

	return (
		<DropdownMenu>
			<DropdownMenuTrigger asChild>
				<Avatar className="size-10 cursor-pointer border border-gray-200">
					<AvatarImage src="" alt="profile" />
					<AvatarFallback className="bg-[var(--brandAccent)] text-base text-gray-500">
						{initials}
					</AvatarFallback>
				</Avatar>
			</DropdownMenuTrigger>

			<DropdownMenuContent
				align="end"
				className="w-64 rounded-xl border border-gray-200 p-0 shadow-lg">
				{/* Profile Section */}
				<div className="flex min-w-0 items-center gap-3 border-b border-gray-100 bg-[var(--brandAccent-dark)] p-4">
					<div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-[var(--brandColor)] text-lg font-semibold text-white">
						<UserRoundIcon className="h-5 w-5" />
					</div>
					<div className="flex min-w-0 flex-col">
						<p className="truncate font-semibold text-gray-900" title={profile?.name || 'User'}>
							{profile?.name || 'User'}
						</p>
						<p className="truncate text-sm text-gray-500" title={profile?.email || 'Email'}>
							{profile?.email || 'Email'}
						</p>
						<p className="text-xs text-gray-400">Asia/Kolkata</p>
					</div>
				</div>

				<DropdownMenuSeparator className="m-0" />

				<div className="py-1">
					{menuItems.map(item => (
						<DropdownMenuItem key={item.name} asChild>
							<a
								href={item.href}
								className={clsx(
									'flex w-full items-center gap-3 px-3 py-2 text-sm hover:!bg-[var(--brandAccent-dark)]',
									currentPath.startsWith(item.href)
										? 'text-[var(--brandColor)] hover:!text-[var(--brandColor-dark)]'
										: 'text-gray-500 hover:!text-[var(--brandColor)]',
								)}>
								<item.icon className="h-4 w-4 text-inherit" />
								{item.name}
							</a>
						</DropdownMenuItem>
					))}
				</div>

				<DropdownMenuSeparator className="m-0" />

				{/* Logout */}
				<DropdownMenuItem
					onSelect={e => {
						e.preventDefault();
						handleLogout();
					}}
					className="flex cursor-pointer items-center gap-3 px-3 py-2 text-red-600 hover:!bg-red-50 hover:!text-red-800">
					<LogOutIcon className="h-4 w-4 text-inherit" />
					Logout
				</DropdownMenuItem>
			</DropdownMenuContent>
		</DropdownMenu>
	);
}
