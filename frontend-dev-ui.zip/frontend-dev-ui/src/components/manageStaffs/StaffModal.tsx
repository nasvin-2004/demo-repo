'use client';

import {
	Dialog,
	DialogContent,
	DialogFooter,
	DialogHeader,
	DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { addStaff, updateStaff, getProgramsWithDepartments, getRolesForUser } from '@/services';
import { StatusCase, type Staff } from './StaffsTable';
import { MultiSelect } from '../common/Multi-Select';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';

export default function StaffModal({
	open,
	onOpenChange,
	staff,
	mode,
}: {
	open: boolean;
	onOpenChange: (b: boolean) => void;
	staff: Staff | null;
	mode: 'edit' | 'view' | 'add';
}) {
	const [form, setForm] = useState({
		userName: '',
		email: '',
		phoneNumber: '',
		departments: [] as { departmentId: string; department: string }[],
		status: 'ACTIVE',
	});

	const [roles, setRoles] = useState<{ value: string; label: string }[]>([]);
	const [selectedRole, setSelectedRole] = useState<string>('');

	const [programs, setPrograms] = useState<
		{ programId: string; programName: string; departments: { id: string; name: string }[] }[]
	>([]);

	const isView = mode === 'view';
	const isAdd = mode === 'add';
	const isEdit = mode === 'edit';

	const getFormValue = (field: 'userName' | 'email' | 'phoneNumber'): string => {
		return form[field] || '';
	};

	useEffect(() => {
		if (staff) {
			setForm({
				userName: staff.userName || '',
				email: staff.email || '',
				phoneNumber: staff.phoneNumber || '',
				departments: staff.departments || [],
				status: staff.status || 'ACTIVE',
			});
			setSelectedRole(staff.roleId || '');
		} else {
			setForm({
				userName: '',
				email: '',
				phoneNumber: '',
				departments: [],
				status: 'ACTIVE',
			});
			setSelectedRole('');
		}
	}, [staff]);

	useEffect(() => {
		const fetchRoles = async () => {
			try {
				const res = await getRolesForUser();
				if (res.success && res.data) {
					const roleOptions = res.data.map((role: { roleId: string; name: string }) => ({
						value: role.roleId,
						label: role.name,
					}));
					setRoles(roleOptions);
				} else {
					toast.error('Failed to fetch roles');
				}
			} catch {
				toast.error('Error fetching roles');
			}
		};
		fetchRoles();
	}, []);

	useEffect(() => {
		const fetchPrograms = async () => {
			const res = await getProgramsWithDepartments();
			if (res.success && res.data) setPrograms(res.data);
			else toast.error(res.message || 'Failed to fetch departments');
		};
		fetchPrograms();
	}, []);

	const handleSubmit = async () => {
		let response;
		if (isEdit) {
			response = await updateStaff({
				userId: staff?.userId as string,
				userName: form.userName,
				email: form.email,
				phoneNumber: form.phoneNumber,
				roleId: selectedRole,
				departments: form.departments,
			});
		} else if (isAdd) {
			response = await addStaff({
				userName: form.userName,
				email: form.email,
				phoneNumber: form.phoneNumber,
				roleId: selectedRole,
				departments: form.departments,
			});
		}

		if (response?.success) {
			toast.success(response.message || 'Staff saved successfully');
			onOpenChange(false);
			window.location.reload();
		} else {
			toast.error(response?.message || 'Something went wrong');
		}
	};

	const options = programs.flatMap(program =>
		program.departments.map(dept => ({
			value: dept.id,
			label: `${program.programName} - ${dept.name}`,
		})),
	);

	const selectedValues: string[] = form.departments.map(d => d.departmentId);

	return (
		<Dialog open={open} onOpenChange={onOpenChange}>
			<DialogContent className="max-w-[520px] rounded-lg bg-white p-6">
				<DialogHeader>
					<DialogTitle className="text-lg font-semibold text-gray-600">
						{isEdit ? 'Edit Staff' : isView ? 'View Staff' : 'Add New Staff'}
					</DialogTitle>
				</DialogHeader>

				<div className="space-y-5 py-4">
					{['userName', 'email', 'phoneNumber'].map(field => (
						<div key={field} className="flex flex-col">
							<Label className="text-muted-foreground mb-1 text-sm font-medium capitalize">
								{field}
							</Label>
							<Input
								value={getFormValue(field as 'userName' | 'email' | 'phoneNumber')}
								onChange={e => setForm({ ...form, [field]: e.target.value })}
								placeholder={`Enter ${field}`}
								disabled={isView}
								className={isView ? 'cursor-not-allowed bg-gray-100' : ''}
							/>
						</div>
					))}

					<div className="flex flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">Role</Label>

						{isView ? (
							<Input
								value={roles.find(r => r.value === selectedRole)?.label || '—'}
								disabled
								className="cursor-not-allowed bg-gray-100"
							/>
						) : (
							<Select
								value={selectedRole}
								onValueChange={val => setSelectedRole(val)}
								disabled={isView}>
								<SelectTrigger
									className={`border-border w-full rounded-sm border px-3 py-2 ${
										isView ? 'cursor-not-allowed bg-gray-100' : ''
									}`}>
									<SelectValue placeholder="Select Role" />
								</SelectTrigger>
								<SelectContent>
									{roles.map(role => (
										<SelectItem key={role.value} value={role.value}>
											{role.label}
										</SelectItem>
									))}
								</SelectContent>
							</Select>
						)}
					</div>

					<div className="flex flex-col">
						<Label className="text-muted-foreground mb-1 text-sm font-medium">Departments</Label>

						{isView ? (
							<div className="flex flex-wrap gap-2">
								{form.departments.length > 0 ? (
									form.departments.map(d => {
										const program = programs.find(p =>
											p.departments.some(dep => dep.id === d.departmentId),
										);
										const programName = program ? program.programName : '';
										return (
											<span
												key={d.departmentId}
												className="rounded-full bg-gray-200 px-2 py-1 text-sm text-gray-700">
												{programName ? `${programName} - ${d.department}` : d.department}
											</span>
										);
									})
								) : (
									<span className="text-sm text-gray-500">—</span>
								)}
							</div>
						) : (
							<MultiSelect
								options={options}
								value={selectedValues}
								onChange={(selected: string[]) => {
									const mapped = selected.map(value => {
										const found = options.find(o => o.value === value);
										return {
											departmentId: value,
											department: found ? found.label.split(' - ')[1] : '',
										};
									});
									setForm({ ...form, departments: mapped });
								}}
								placeholder="Select departments"
							/>
						)}
					</div>

					{isView && (
						<div className="flex flex-col">
							<Label className="text-muted-foreground mb-1 text-sm font-medium">Status</Label>
							<Input
								value={StatusCase[form.status as 'ACTIVE' | 'INACTIVE' | 'PENDING']}
								disabled
								className="cursor-not-allowed bg-gray-100"
							/>
						</div>
					)}
				</div>

				{!isView && (
					<DialogFooter className="flex justify-end gap-3 pt-6">
						<Button variant="outline" onClick={() => onOpenChange(false)}>
							Cancel
						</Button>
						<Button onClick={handleSubmit} className="bg-[var(--brandColor)] text-white">
							{isEdit ? 'Update' : 'Add'}
						</Button>
					</DialogFooter>
				)}
			</DialogContent>
		</Dialog>
	);
}
