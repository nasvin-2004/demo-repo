import { Label } from '@/components/ui/label';
import { CircleIcon, EllipsisVerticalIcon, InboxIcon, Info, PlusIcon, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
	Table,
	TableBody,
	TableCell,
	TableHead,
	TableHeader,
	TableRow,
} from '@/components/ui/table';
import clsx from 'clsx';
import { useState } from 'react';
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuTrigger,
} from '../ui/dropdown-menu';
import StaffModal from './StaffModal';
import CommonModal from '../common/Modal';
import { toast } from 'sonner';
import { updateUserStatus } from '@/services';
import PaginationBar from '../common/Pagination';
import HoverSearchInfoPopover from '../common/SearchInfo';

export type Staff = {
	roleId: string;
	userId: string;
	userName: string;
	email: string;
	role: string;
	phoneNumber?: string;
	status: 'ACTIVE' | 'INACTIVE' | 'PENDING';
	departments: {
		programName: string;
		departmentId: string;
		department: string;
	}[];
};

export const StatusCase = {
	ACTIVE: 'Active',
	INACTIVE: 'Inactive',
	PENDING: 'Pending',
};

interface StaffsTableProps {
	staffs: Staff[];
	search: string;
	onSearchChange: (value: string) => void;
	page: number;
	totalPages: number;
	total: number;
	onPageChange: (page: number) => void;
	limit: number;
	onLimitChange: (limit: number) => void;
}

export default function StaffsTable({
	staffs,
	search,
	onSearchChange,
	page,
	totalPages,
	total,
	onPageChange,
	limit,
	onLimitChange,
}: StaffsTableProps) {
	const [open, setOpen] = useState(false);
	const [editStaff, setEditStaff] = useState<Staff | null>(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [confirmAction, setConfirmAction] = useState<'ACTIVATE' | 'DEACTIVATE' | null>(null);
	const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);
	const [modalMode, setModalMode] = useState<'edit' | 'view' | 'add'>('edit');

	const editStaffData = (staff: Staff) => {
		setEditStaff(staff);
	};

	const handleConfirm = async () => {
		if (!selectedStaff || !confirmAction) return;

		const status = confirmAction === 'ACTIVATE' ? 'ACTIVE' : 'INACTIVE';
		const res = await updateUserStatus({ userId: selectedStaff.userId, status });

		if (res.success) {
			toast.success(
				`Staff ${selectedStaff.userName} has been ${status === 'ACTIVE' ? 'activated' : 'deactivated'} successfully`,
			);
			window.location.reload();
		} else {
			toast.error(res.message || 'Failed to update staff status');
		}

		setConfirmOpen(false);
		setConfirmAction(null);
		setSelectedStaff(null);
	};

	return (
		<div className="h-fit min-h-[calc(99vh-5rem)] flex-1 rounded-lg bg-white p-6">
			<div className="mb-4 flex items-center justify-between">
				<Label className="text-lg font-semibold text-gray-700">Staffs</Label>
				<div className="flex flex-row items-center">
					<div>
						<span className="px-3 text-sm text-gray-500">
							Showing {page} of {totalPages} ({total} staffs)
						</span>
					</div>

					<Button
						className="gap-2 bg-[var(--brandColor)] px-4 py-2 text-white hover:bg-[var(--brandColor-dark)]"
						onClick={() => {
							setEditStaff(null);
							setModalMode('add');
							setOpen(true);
						}}>
						<PlusIcon className="h-4 w-4" />
						<span className="font-medium">Add Staff</span>
					</Button>
				</div>
			</div>

			<div className="flex items-center gap-3 pb-4">
				<div className="w-3xs relative flex items-center">
					<span className="absolute left-3">
						<Search className="h-4 w-4 text-gray-400" />
					</span>

					<input
						type="text"
						placeholder="Search Staffs"
						value={search}
						onChange={e => onSearchChange(e.target.value)}
						className="w-full rounded-md border border-gray-300 py-2 pl-9 pr-9 text-sm focus:border-[var(--brandColor)] focus:ring-0"
					/>

					<span className="absolute right-3">
						<HoverSearchInfoPopover fields={['Name', 'Email', 'PhoneNo']} align="end" />
					</span>
				</div>
				<Button className="gap-2 bg-[var(--brandColor)] px-6 py-2 text-white hover:bg-[var(--brandColor-dark)]">
					<Search />
					<span className="font-medium">Search</span>
				</Button>
			</div>

			<div className="flex min-h-[50vh] flex-col justify-between overflow-hidden rounded-md">
				<div className="flex-1">
					<Table>
						<TableHeader className="bg-gray-100/70">
							<TableRow className="!border-b-0">
								{[
									'S. No',
									'Name',
									'Role',
									'Departments',
									'Email/Phone',
									'Login Status',
									'Action',
								].map(h => (
									<TableHead key={h} className="px-4 py-3 font-semibold text-gray-500/80">
										{h}
									</TableHead>
								))}
							</TableRow>
						</TableHeader>

						<TableBody>
							{staffs.length > 0 ? (
								staffs.map((staff, index) => (
									<TableRow
										key={staff.userId}
										onClick={() => {
											setEditStaff(staff);
											setModalMode('view');
											setOpen(true);
										}}
										className="cursor-pointer border-b transition-colors last:border-b-0 hover:bg-gray-50/70">
										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{(page - 1) * 10 + (index + 1)}
										</TableCell>
										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{staff.userName}
										</TableCell>
										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{staff.role || '—'}
										</TableCell>
										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{staff.departments && staff.departments.length > 0 ? (
												<div className="flex items-center gap-1">
													<span>
														{staff.departments
															.slice(0, 2)
															.map(d => `${d.programName || '—'} - ${d.department}`)
															.join(', ')}
														{staff.departments.length > 2 && '...'}
													</span>

													{staff.departments.length > 2 && (
														<div className="group relative cursor-pointer">
															<Info className="h-4 w-4 text-gray-400 group-hover:text-[var(--brandColor)]" />
															<div className="absolute left-1/2 z-20 hidden w-max -translate-x-1/2 rounded-md bg-gray-800 px-2 py-1 text-xs text-white group-hover:block">
																{staff.departments
																	.map(d => `${d.programName || '—'} - ${d.department}`)
																	.join(', ')}
															</div>
														</div>
													)}
												</div>
											) : (
												'—'
											)}
										</TableCell>

										<TableCell className="px-4 py-3 font-medium text-gray-500/90">
											{staff.email}
											<br />
											{staff.phoneNumber}
										</TableCell>
										<TableCell className="px-4 py-3">
											<div className="flex items-center gap-2 text-gray-500/90">
												<CircleIcon
													className={clsx(
														'h-3 w-3 fill-current',
														staff.status === 'ACTIVE'
															? 'text-[var(--brandColor)]'
															: staff.status === 'PENDING'
																? 'text-[var(--brandYellow)]'
																: 'text-[var(--brandRed)]',
													)}
													aria-hidden="true"
												/>
												<span
													className="font-medium"
													aria-label={`Staff status: ${StatusCase[staff.status]}`}>
													{StatusCase[staff.status]}
												</span>
											</div>
										</TableCell>

										<TableCell className="px-4 py-3">
											<DropdownMenu>
												<DropdownMenuTrigger asChild>
													<Button
														variant="outline"
														className="size-8.5 cursor-pointer border-gray-200 text-[var(--brandColor)] !shadow-none hover:!border-[var(--brandColor)] hover:!bg-[var(--brandAccent)] hover:!text-[var(--brandColor-dark)]"
														aria-label={`Actions for ${staff.userName}`}>
														<EllipsisVerticalIcon aria-hidden="true" />
													</Button>
												</DropdownMenuTrigger>
												<DropdownMenuContent
													align="end"
													className="w-36 text-gray-500"
													role="menu"
													aria-label={`Actions for ${staff.userName}`}>
													{(staff.status === 'ACTIVE' || staff.status === 'INACTIVE') && (
														<DropdownMenuItem
															onClick={e => {
																e.stopPropagation();
																editStaffData(staff);
																setModalMode('edit');
																setOpen(true);
															}}
															role="menuitem"
															aria-label={`Edit ${staff.userName}`}>
															Edit
														</DropdownMenuItem>
													)}

													{staff.status === 'ACTIVE' && (
														<DropdownMenuItem
															onClick={e => {
																e.stopPropagation();
																setSelectedStaff(staff);
																setConfirmAction('DEACTIVATE');
																setConfirmOpen(true);
															}}
															role="menuitem"
															aria-label={`Deactivate ${staff.userName}`}>
															Deactivate
														</DropdownMenuItem>
													)}

													{staff.status === 'INACTIVE' && (
														<DropdownMenuItem
															onClick={e => {
																e.stopPropagation();
																setSelectedStaff(staff);
																setConfirmAction('ACTIVATE');
																setConfirmOpen(true);
															}}
															role="menuitem"
															aria-label={`Activate ${staff.userName}`}>
															Activate
														</DropdownMenuItem>
													)}

													{staff.status === 'PENDING' && (
														<>
															<DropdownMenuItem
																onClick={e => {
																	e.stopPropagation();
																	toast.info(`Send mail to ${staff.userName}`);
																}}
																role="menuitem"
																aria-label={`Send mail to ${staff.userName}`}>
																Send Mail
															</DropdownMenuItem>
															<DropdownMenuItem
																role="menuitem"
																aria-label={`Revoke ${staff.userName}`}>
																Revoke
															</DropdownMenuItem>
														</>
													)}
												</DropdownMenuContent>
											</DropdownMenu>
										</TableCell>
									</TableRow>
								))
							) : (
								<TableRow>
									<TableCell colSpan={7} className="py-12 text-center">
										<div className="flex flex-col items-center gap-2 text-gray-400">
											<InboxIcon className="h-10 w-10" />
											<span className="text-sm font-medium">No data</span>
										</div>
									</TableCell>
								</TableRow>
							)}
						</TableBody>
					</Table>
				</div>
			</div>

			<div className="mt-4 flex justify-end">
				<PaginationBar
					page={page}
					totalPages={totalPages}
					limit={limit}
					onLimitChange={onLimitChange}
					onPageChange={onPageChange}
				/>
			</div>

			<StaffModal open={open} onOpenChange={setOpen} staff={editStaff} mode={modalMode} />
			<CommonModal
				isOpen={confirmOpen}
				onOpenChange={setConfirmOpen}
				title={`Confirm ${confirmAction === 'ACTIVATE' ? 'Activation' : 'Deactivation'}`}
				description={`Are you sure you want to ${confirmAction?.toLowerCase()} ${selectedStaff?.userName}?`}
				confirmText="Yes"
				cancelText="Cancel"
				onConfirm={handleConfirm}
			/>
		</div>
	);
}
