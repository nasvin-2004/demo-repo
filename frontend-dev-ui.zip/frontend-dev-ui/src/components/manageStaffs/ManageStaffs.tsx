import React, { useEffect, useState } from 'react';
import GlobalFilter, { type FilterFieldType, type FilterValue } from '@/components/common/Filter';
import StaffsTable, { type Staff } from '@/components/manageStaffs/StaffsTable';
import { getStaffs, getProgramsWithDepartments, getRolesForUser } from '@/services';
import { toast } from 'sonner';

interface Program {
	departments: Department[];
}

interface Department {
	id: string;
	name: string;
}

interface Role {
	roleId: string;
	name: string;
}

const StaffManager: React.FC = () => {
	const [staffs, setStaffs] = useState<Staff[]>([]);
	const [filterValues, setFilterValues] = useState<Record<string, FilterValue>>({});
	const [departments, setDepartments] = useState<{ value: string; label: string }[]>([]);
	const [search, setSearch] = useState('');
	const [page, setPage] = useState(1);
	const [roles, setRoles] = useState<{ value: string; label: string }[]>([]);
	const [limit, setLimit] = useState(10);
	const [meta, setMeta] = useState({ total: 0, totalPages: 1, page: 1, limit: 10 });

	useEffect(() => {
		const fetchDepartments = async () => {
			const res = await getProgramsWithDepartments();
			if (res.success && res.data) {
				const deptOptions = res.data.flatMap((program: Program) =>
					program.departments.map((dept: Department) => ({
						value: dept.id,
						label: dept.name,
					})),
				);
				setDepartments(deptOptions);
			} else {
				toast.error(res.message || 'Failed to fetch departments');
			}
		};
		fetchDepartments();
	}, []);

	useEffect(() => {
		const fetchRoles = async () => {
			try {
				const res = await getRolesForUser();
				if (res.success && res.data) {
					const roleOptions = res.data.map((role: Role) => ({
						value: role.roleId,
						label: role.name,
					}));
					setRoles(roleOptions);
				} else {
					toast.error('Failed to fetch roles');
				}
			} catch {
				toast.error('Error fetching roles');
			}
		};
		fetchRoles();
	}, []);

	useEffect(() => {
		const fetchStaffs = async () => {
			const response = await getStaffs({
				page,
				limit,
				search,
				status: filterValues.status as string,
				departmentId: filterValues.departmentId as string,
				roleId: filterValues.roleId as string,
			});
			if (response.success && response.data) {
				if (Array.isArray(response.data.users)) {
					setStaffs(response.data.users);
					setMeta(response.data.meta);
				} else if (Array.isArray(response.data)) {
					setStaffs(response.data);
					setMeta(prev => ({ ...prev, total: response.data.length }));
				}
			} else {
				toast.error(response.message || 'Error fetching staffs');
				setStaffs([]);
			}
		};
		fetchStaffs();
	}, [page, limit, search, filterValues]);

	const filterFields: FilterFieldType[] = [
		{
			type: 'select',
			id: 'roleId',
			label: 'Role',
			options: roles,
		},
		{
			type: 'select',
			id: 'departmentId',
			label: 'Department',
			options: departments,
		},
		{
			type: 'select',
			id: 'status',
			label: 'Status',
			options: [
				{ value: 'ACTIVE', label: 'Active' },
				{ value: 'INACTIVE', label: 'Inactive' },
				{ value: 'PENDING', label: 'Pending' },
			],
		},
	];

	return (
		<div className="flex min-h-[calc(99vh-5rem)] w-full flex-col gap-4 px-4 py-3 md:flex-row md:gap-3.5">
			<GlobalFilter fields={filterFields} initialValues={filterValues} onChange={setFilterValues} />

			<div className="flex flex-1 flex-col gap-3">
				<StaffsTable
					staffs={staffs}
					search={search}
					onSearchChange={setSearch}
					page={meta.page}
					totalPages={meta.totalPages}
					total={meta.total}
					onPageChange={setPage}
					limit={meta.limit}
					onLimitChange={newLimit => {
						setLimit(newLimit);
						setPage(1);
					}}
				/>
			</div>
		</div>
	);
};

export default StaffManager;
