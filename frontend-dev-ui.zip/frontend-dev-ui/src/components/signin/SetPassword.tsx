import { toast } from 'sonner';
import { setPassword as setPasswordAPI } from '@/services/auth.service';
import { useState, useMemo } from 'react';
import { Check, X, Eye, EyeOff } from 'lucide-react';

interface SetPasswordProps {
	publicKey?: string;
	token?: string;
}

export default function SetPassword({ publicKey = '', token = '' }: SetPasswordProps) {
	const [password, setPassword] = useState('');
	const [confirmPassword, setConfirmPassword] = useState('');
	const [isLoading, setIsLoading] = useState(false);
	const [showConfirmPassword, setShowConfirmPassword] = useState(false);

	const encryptPassword = async (plainPassword: string, publicKeyPem: string): Promise<string> => {
		try {
			// Import the public key
			const publicKeyData = publicKeyPem
				.replace('-----BEGIN PUBLIC KEY-----', '')
				.replace('-----END PUBLIC KEY-----', '')
				.replace(/\s/g, '');

			const binaryDer = Uint8Array.from(atob(publicKeyData), c => c.charCodeAt(0));

			const key = await crypto.subtle.importKey(
				'spki',
				binaryDer.buffer,
				{
					name: 'RSA-OAEP',
					hash: 'SHA-256',
				},
				false,
				['encrypt'],
			);

			// Encrypt the password
			const encodedPassword = new TextEncoder().encode(plainPassword);
			const encrypted = await crypto.subtle.encrypt(
				{
					name: 'RSA-OAEP',
				},
				key,
				encodedPassword,
			);

			// Convert to base64
			return btoa(String.fromCharCode(...new Uint8Array(encrypted)));
		} catch (error) {
			// eslint-disable-next-line no-console
			console.error('Encryption error:', error);
			throw new Error('Failed to encrypt password');
		}
	};

	// Password validation criteria
	const passwordCriteria = useMemo(() => {
		return {
			minLength: password.length >= 8,
			hasUpperCase: /[A-Z]/.test(password),
			hasLowerCase: /[a-z]/.test(password),
			hasNumber: /[0-9]/.test(password),
			hasSpecialChar: /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(password),
			passwordsMatch:
				password === confirmPassword && password.length > 0 && confirmPassword.length > 0,
		};
	}, [password, confirmPassword]);

	const isPasswordValid = Object.values(passwordCriteria).every(Boolean);

	const handleSetPassword = async () => {
		if (!password || !confirmPassword) {
			toast.error('Please enter both password fields');
			return;
		}

		if (password !== confirmPassword) {
			toast.error('Passwords do not match');
			return;
		}

		if (!isPasswordValid) {
			toast.error('Please meet all password requirements');
			return;
		}

		if (!publicKey) {
			toast.error('Public key not available. Please refresh the page.');
			return;
		}

		if (!token) {
			toast.error('Invalid token. Please check your link.');
			return;
		}

		setIsLoading(true);
		try {
			const encryptedPassword = await encryptPassword(password, publicKey);
			const response = await setPasswordAPI(token, encryptedPassword);

			if (response.success) {
				toast.success('Password set successfully! Redirecting to login...');
				setTimeout(() => {
					window.location.href = '/login';
				}, 2000);
			} else {
				toast.error(response.message || 'Failed to set password');
				setIsLoading(false);
			}
		} catch (error) {
			// eslint-disable-next-line no-console
			console.error('Set password error:', error);
			toast.error('Something went wrong while setting password');
			setIsLoading(false);
		}
	};

	return (
		<div className="slideIn flex h-[100vh] w-[100vw] flex-col items-center justify-center">
			<div className="flex w-full max-w-[420px] flex-col gap-5 p-[40px]">
				<div className="flex flex-col gap-2">
					<h1 className="text-[26px] font-medium">Set your password</h1>
					<p className="text-[16px] text-[#758b89]">Create a secure password for your account</p>
				</div>

				<div className="flex flex-col gap-4">
					<div className="flex flex-col gap-2">
						<label htmlFor="password" className="text-sm font-medium text-gray-700">
							New Password
						</label>
						<input
							id="password"
							type="password"
							value={password}
							onChange={e => setPassword(e.target.value)}
							placeholder="Enter your new password"
							className="w-full rounded-md border border-gray-300 px-4 py-2 text-sm focus:border-[var(--brandColor)] focus:outline-none focus:ring-1 focus:ring-[var(--brandColor)]"
							disabled={isLoading}
						/>
					</div>
					<div className="flex flex-col gap-2">
						<label htmlFor="confirmPassword" className="text-sm font-medium text-gray-700">
							Confirm Password
						</label>
						<div className="relative">
							<input
								id="confirmPassword"
								type={showConfirmPassword ? 'text' : 'password'}
								value={confirmPassword}
								onChange={e => setConfirmPassword(e.target.value)}
								placeholder="Confirm your new password"
								className="w-full rounded-md border border-gray-300 px-4 py-2 pr-10 text-sm focus:border-[var(--brandColor)] focus:outline-none focus:ring-1 focus:ring-[var(--brandColor)]"
								disabled={isLoading}
								onKeyDown={e => {
									if (e.key === 'Enter' && !isLoading) {
										handleSetPassword();
									}
								}}
							/>
							<button
								type="button"
								onClick={() => setShowConfirmPassword(!showConfirmPassword)}
								className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 focus:outline-none"
								disabled={isLoading}
								aria-label={showConfirmPassword ? 'Hide password' : 'Show password'}>
								{!showConfirmPassword ? (
									<EyeOff className="h-4 w-4" />
								) : (
									<Eye className="h-4 w-4" />
								)}
							</button>
						</div>
						{/* Password Requirements - Always Visible */}
						<div className="mt-2 rounded-md bg-gray-50 p-3 text-xs">
							<div className="mb-2 text-xs font-medium text-gray-700">Password Requirements:</div>
							<div className="grid grid-cols-1 gap-y-1.5 md:grid-cols-2 md:gap-x-4">
								<div className="flex items-center gap-2">
									{passwordCriteria.minLength ? (
										<Check className="h-4 w-4 text-green-600" />
									) : (
										<X className="h-4 w-4 text-gray-400" />
									)}
									<span
										className={
											passwordCriteria.minLength ? 'font-medium text-gray-700' : 'text-gray-500'
										}>
										At least 8 characters
									</span>
								</div>
								<div className="flex items-center gap-2">
									{passwordCriteria.hasUpperCase ? (
										<Check className="h-4 w-4 text-green-600" />
									) : (
										<X className="h-4 w-4 text-gray-400" />
									)}
									<span
										className={
											passwordCriteria.hasUpperCase ? 'font-medium text-gray-700' : 'text-gray-500'
										}>
										One uppercase letter
									</span>
								</div>
								<div className="flex items-center gap-2">
									{passwordCriteria.hasLowerCase ? (
										<Check className="h-4 w-4 text-green-600" />
									) : (
										<X className="h-4 w-4 text-gray-400" />
									)}
									<span
										className={
											passwordCriteria.hasLowerCase ? 'font-medium text-gray-700' : 'text-gray-500'
										}>
										One lowercase letter
									</span>
								</div>
								<div className="flex items-center gap-2">
									{passwordCriteria.hasNumber ? (
										<Check className="h-4 w-4 text-green-600" />
									) : (
										<X className="h-4 w-4 text-gray-400" />
									)}
									<span
										className={
											passwordCriteria.hasNumber ? 'font-medium text-gray-700' : 'text-gray-500'
										}>
										One number
									</span>
								</div>
								<div className="flex items-center gap-2">
									{passwordCriteria.hasSpecialChar ? (
										<Check className="h-4 w-4 text-green-600" />
									) : (
										<X className="h-4 w-4 text-gray-400" />
									)}
									<span
										className={
											passwordCriteria.hasSpecialChar
												? 'font-medium text-gray-700'
												: 'text-gray-500'
										}>
										One special character
									</span>
								</div>
								<div className="flex items-center gap-2">
									{passwordCriteria.passwordsMatch ? (
										<Check className="h-4 w-4 text-green-600" />
									) : (
										<X className="h-4 w-4 text-gray-400" />
									)}
									<span
										className={
											passwordCriteria.passwordsMatch
												? 'font-medium text-gray-700'
												: 'text-gray-500'
										}>
										Passwords match
									</span>
								</div>
							</div>
						</div>
					</div>
					<button
						type="button"
						onClick={handleSetPassword}
						disabled={isLoading || !isPasswordValid || password !== confirmPassword}
						className="w-full rounded-md bg-[var(--brandColor)] px-4 py-2 text-sm font-medium text-white hover:bg-[var(--brandColor-dark)] disabled:cursor-not-allowed disabled:opacity-50">
						{isLoading ? 'Setting password...' : 'Set Password'}
					</button>
				</div>

				<div className="flex items-center justify-start gap-1 ">
					<p className="text-[#758b89] ">
						<span className="text-[14px]">Remember your password?</span>
					</p>
					<a href="/login">
						<p className="text-base text-[var(--brandColor)]">Sign In</p>
					</a>
				</div>
			</div>
		</div>
	);
}
