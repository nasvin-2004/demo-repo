export default function SideBar() {
	return (
		<div className="relative flex h-[100vh] w-[45vw] flex-col justify-center bg-[var(--brandColor)] p-[30px] text-white">
			<img
				src="/Q-connect logo white.png"
				height={60}
				width={220}
				alt="Q_Connect"
				className="mb-0.5 -translate-x-[10px] transform"
			/>
			<h1 className="mb-[15px] text-[28px] font-[450] ">Empower Your College Community</h1>
			<p className="mb-5 mb-[20px] text-sm leading-6 opacity-90">
				Join leading colleges using QConnect to streamline student management, enhance academic
				tracking, and foster better communication between students, faculty, and administration.
			</p>
			<div className="flex flex-col gap-[15px] text-sm">
				<div className="flex gap-2 opacity-90">
					<svg
						viewBox="64 64 896 896"
						focusable="false"
						data-icon="check"
						width="1em"
						height="1em"
						fill="currentColor"
						aria-hidden="true">
						<path d="M912 190h-69.9c-9.8 0-19.1 4.5-25.1 12.2L404.7 724.5 207 474a32 32 0 00-25.1-12.2H112c-6.7 0-10.4 7.7-6.3 12.9l273.9 347c12.8 16.2 37.4 16.2 50.3 0l488.4-618.9c4.1-5.1.4-12.8-6.3-12.8z"></path>
					</svg>
					<p>Comprehensive Student Management System</p>
				</div>
				<div className="flex gap-2 ">
					<svg
						viewBox="64 64 896 896"
						focusable="false"
						data-icon="check"
						width="1em"
						height="1em"
						fill="currentColor"
						aria-hidden="true">
						<path d="M912 190h-69.9c-9.8 0-19.1 4.5-25.1 12.2L404.7 724.5 207 474a32 32 0 00-25.1-12.2H112c-6.7 0-10.4 7.7-6.3 12.9l273.9 347c12.8 16.2 37.4 16.2 50.3 0l488.4-618.9c4.1-5.1.4-12.8-6.3-12.8z"></path>
					</svg>
					<p>Real-time Academic Progress Tracking</p>
				</div>
				<div className="flex gap-2 ">
					<svg
						viewBox="64 64 896 896"
						focusable="false"
						data-icon="check"
						width="1em"
						height="1em"
						fill="currentColor"
						aria-hidden="true">
						<path d="M912 190h-69.9c-9.8 0-19.1 4.5-25.1 12.2L404.7 724.5 207 474a32 32 0 00-25.1-12.2H112c-6.7 0-10.4 7.7-6.3 12.9l273.9 347c12.8 16.2 37.4 16.2 50.3 0l488.4-618.9c4.1-5.1.4-12.8-6.3-12.8z"></path>
					</svg>
					<p>Integrated Communication & Collaboration Tools</p>
				</div>
			</div>
			<span className="absolute right-[-60px] top-[-60px] rounded-full bg-[#ffffff1a] p-[75px]"></span>
			<span className="absolute bottom-[40px] right-[-20px] rounded-full bg-[#ffffff1a] p-[50px]"></span>
		</div>
	);
}
