import { GoogleLogin, GoogleOAuthProvider } from '@react-oauth/google';
import type { CredentialResponse } from '@react-oauth/google';
import { toast } from 'sonner';
import { loginWithGoogle, loginWithEmailPassword } from '@/services/auth.service';
import { setLoginData } from '@/stores/profileStore';
import { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface LoginProps {
	publicKey?: string;
}

export default function Login({ publicKey = '' }: LoginProps) {
	const [email, setEmail] = useState('');
	const [password, setPassword] = useState('');
	const [isLoading, setIsLoading] = useState(false);
	const [showPassword, setShowPassword] = useState(false);

	const encryptPassword = async (plainPassword: string, publicKeyPem: string): Promise<string> => {
		try {
			// Import the public key
			const publicKeyData = publicKeyPem
				.replace('-----BEGIN PUBLIC KEY-----', '')
				.replace('-----END PUBLIC KEY-----', '')
				.replace(/\s/g, '');

			const binaryDer = Uint8Array.from(atob(publicKeyData), c => c.charCodeAt(0));

			const key = await crypto.subtle.importKey(
				'spki',
				binaryDer.buffer,
				{
					name: 'RSA-OAEP',
					hash: 'SHA-256',
				},
				false,
				['encrypt'],
			);

			// Encrypt the password
			const encodedPassword = new TextEncoder().encode(plainPassword);
			const encrypted = await crypto.subtle.encrypt(
				{
					name: 'RSA-OAEP',
				},
				key,
				encodedPassword,
			);

			// Convert to base64
			return btoa(String.fromCharCode(...new Uint8Array(encrypted)));
		} catch (error) {
			// eslint-disable-next-line no-console
			console.error('Encryption error:', error);
			throw new Error('Failed to encrypt password');
		}
	};

	const handleEmailPasswordLogin = async () => {
		if (!email || !password) {
			toast.error('Please enter both email and password');
			return;
		}

		if (!publicKey) {
			toast.error('Public key not available. Please refresh the page.');
			return;
		}

		setIsLoading(true);
		try {
			const encryptedPassword = await encryptPassword(password, publicKey);
			const response = await loginWithEmailPassword(email, encryptedPassword);

			if (response.success && response.data) {
				setLoginData(response.data.user, response.data.token, response.data.modules);
				window.location.href = '/dashboard';
			} else {
				toast.error(response.message || 'Login failed');
			}
		} catch (error) {
			// eslint-disable-next-line no-console
			console.error('Login error:', error);
			toast.error('Something went wrong during login');
		} finally {
			setIsLoading(false);
		}
	};

	const handleGoogleLogin = async (credentialResponse: CredentialResponse) => {
		if (credentialResponse.credential) {
			try {
				const response = await loginWithGoogle(credentialResponse.credential);
				if (response.success && response.data) {
					// Update store with login data
					setLoginData(response.data.user, response.data.token, response.data.modules);
					window.location.href = '/dashboard';
				} else {
					toast.error(response.message || 'Login failed');
				}
			} catch (error) {
				// Google login failed
				toast.error('Something went wrong during login');
			}
		} else {
			toast.error('Something went wrong');
		}
	};

	const handleGoogleError = () => {
		toast.error('Google login failed');
	};

	return (
		<div className="slideIn flex h-[100vh] w-[100vw] flex-col justify-center [&]:items-center [@media(min-width:1200px)]:ml-[8vw] [@media(min-width:1200px)]:items-start ">
			<div className="flex max-w-[420px] flex-col gap-5 p-[40px]">
				<div className="flex flex-col gap-2">
					<h1 className="text-[26px] font-medium">Sign in to your account</h1>
					<p className="text-[16px] text-[#758b89]">Sign in with email and password</p>
				</div>

				<div className="flex flex-col gap-4">
					<div className="flex flex-col gap-2">
						<label htmlFor="email" className="text-sm font-medium text-gray-700">
							Email
						</label>
						<input
							id="email"
							type="email"
							value={email}
							onChange={e => setEmail(e.target.value)}
							placeholder="Enter your email"
							className="w-full rounded-md border border-gray-300 px-4 py-2 text-sm focus:border-[var(--brandColor)] focus:outline-none focus:ring-1 focus:ring-[var(--brandColor)]"
							disabled={isLoading}
						/>
					</div>
					<div className="flex flex-col gap-2">
						<div className="flex items-center justify-between">
							<label htmlFor="password" className="text-sm font-medium text-gray-700">
								Password
							</label>
							<a
								href="/forgot-password"
								className="text-sm text-[var(--brandColor)] hover:underline">
								Forgot password?
							</a>
						</div>
						<div className="relative">
							<input
								id="password"
								type={showPassword ? 'text' : 'password'}
								value={password}
								onChange={e => setPassword(e.target.value)}
								placeholder="Enter your password"
								className="w-full rounded-md border border-gray-300 px-4 py-2 pr-10 text-sm focus:border-[var(--brandColor)] focus:outline-none focus:ring-1 focus:ring-[var(--brandColor)]"
								disabled={isLoading}
								onKeyDown={e => {
									if (e.key === 'Enter' && !isLoading) {
										handleEmailPasswordLogin();
									}
								}}
							/>
							<button
								type="button"
								onClick={() => setShowPassword(!showPassword)}
								className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700 focus:outline-none"
								disabled={isLoading}
								aria-label={showPassword ? 'Hide password' : 'Show password'}>
								{!showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
							</button>
						</div>
					</div>
					<button
						type="button"
						onClick={handleEmailPasswordLogin}
						disabled={isLoading}
						className="w-full rounded-md bg-[var(--brandColor)] px-4 py-2 text-sm font-medium text-white hover:bg-[var(--brandColor-dark)] disabled:cursor-not-allowed disabled:opacity-50">
						{isLoading ? 'Signing in...' : 'Sign In'}
					</button>
				</div>

				<div className="flex items-center justify-center gap-2">
					<div className="h-px flex-1 bg-gray-300"></div>
					<span className="text-sm text-gray-500">OR</span>
					<div className="h-px flex-1 bg-gray-300"></div>
				</div>

				<GoogleOAuthProvider clientId={import.meta.env.PUBLIC_GOOGLE_CLIENT_ID || ''}>
					<GoogleLogin
						theme="outline"
						logo_alignment="center"
						onSuccess={handleGoogleLogin}
						onError={handleGoogleError}
					/>
				</GoogleOAuthProvider>

				<div className="flex items-center justify-start gap-1 ">
					<p className="text-[#758b89] ">
						<span className="text-[14px]">Don&apos;t have an account?</span>
					</p>
					<a href="contactUs">
						<p className="text-base text-[var(--brandColor)]">Contact Us</p>
					</a>
				</div>
			</div>
		</div>
	);
}
