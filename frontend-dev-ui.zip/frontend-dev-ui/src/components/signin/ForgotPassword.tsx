import { toast } from 'sonner';
import { forgotPassword as forgotPasswordAPI } from '@/services/auth.service';
import { useState } from 'react';

export default function ForgotPassword() {
	const [email, setEmail] = useState('');
	const [isLoading, setIsLoading] = useState(false);
	const [isSubmitted, setIsSubmitted] = useState(false);

	const handleForgotPassword = async () => {
		if (!email) {
			toast.error('Please enter your email address');
			return;
		}

		// Basic email validation
		const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
		if (!emailRegex.test(email)) {
			toast.error('Please enter a valid email address');
			return;
		}

		setIsLoading(true);
		try {
			const response = await forgotPasswordAPI(email);

			if (response.success) {
				setIsSubmitted(true);
				toast.success(response.message || 'Password reset link sent successfully');
			} else {
				toast.error(response.message || 'Failed to send password reset link');
			}
		} catch (error) {
			// eslint-disable-next-line no-console
			console.error('Forgot password error:', error);
			toast.error('Something went wrong. Please try again.');
		} finally {
			setIsLoading(false);
		}
	};

	if (isSubmitted) {
		return (
			<div className="slideIn flex h-[100vh] w-[100vw] flex-col items-center justify-center">
				<div className="flex w-full max-w-[420px] flex-col gap-5 p-[40px]">
					<div className="flex flex-col gap-2">
						<h1 className="text-[26px] font-medium">Check your email</h1>
						<p className="text-[16px] text-[#758b89]">
							We&apos;ve sent a password reset link to <strong>{email}</strong>
						</p>
						<p className="mt-2 text-[14px] text-[#758b89]">
							Please check your inbox and click the link to reset your password. The link will
							expire in 10 minutes.
						</p>
					</div>

					<div className="flex items-center justify-start gap-1">
						<p className="text-[#758b89]">
							<span className="text-[14px]">Remember your password?</span>
						</p>
						<a href="/login">
							<p className="text-base text-[var(--brandColor)]">Sign In</p>
						</a>
					</div>
				</div>
			</div>
		);
	}

	return (
		<div className="slideIn flex h-[100vh] w-[100vw] flex-col items-center justify-center">
			<div className="flex w-full max-w-[420px] flex-col gap-5 p-[40px]">
				<div className="flex flex-col gap-2">
					<h1 className="text-[26px] font-medium">Forgot Password</h1>
					<p className="text-[16px] text-[#758b89]">
						Enter your email address and we&apos;ll send you a link to reset your password.
					</p>
				</div>

				<div className="flex flex-col gap-4">
					<div className="flex flex-col gap-2">
						<label htmlFor="email" className="text-sm font-medium text-gray-700">
							Email Address
						</label>
						<input
							id="email"
							type="email"
							value={email}
							onChange={e => setEmail(e.target.value)}
							placeholder="Enter your email address"
							className="w-full rounded-md border border-gray-300 px-4 py-2 text-sm focus:border-[var(--brandColor)] focus:outline-none focus:ring-1 focus:ring-[var(--brandColor)]"
							disabled={isLoading}
							onKeyDown={e => {
								if (e.key === 'Enter' && !isLoading) {
									handleForgotPassword();
								}
							}}
						/>
					</div>
					<button
						type="button"
						onClick={handleForgotPassword}
						disabled={isLoading}
						className="w-full rounded-md bg-[var(--brandColor)] px-4 py-2 text-sm font-medium text-white hover:bg-[var(--brandColor-dark)] disabled:cursor-not-allowed disabled:opacity-50">
						{isLoading ? 'Sending...' : 'Send Password Reset Link'}
					</button>
				</div>

				<div className="flex items-center justify-start gap-1">
					<p className="text-[#758b89]">
						<span className="text-[14px]">Remember your password?</span>
					</p>
					<a href="/login">
						<p className="text-base text-[var(--brandColor)]">Sign In</p>
					</a>
				</div>
			</div>
		</div>
	);
}
