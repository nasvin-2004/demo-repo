import { useState, useRef, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import type { editor } from 'monaco-editor';
import {
	Play,
	ChevronLeft,
	ChevronRight,
	ChevronDown,
	FileQuestion,
	History,
	Pause,
	RotateCcw,
	Maximize2,
	Plus,
	MoreVertical,
	Bug,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
	Dialog,
	DialogContent,
	DialogHeader,
	DialogTitle,
	DialogDescription,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
	DropdownMenu,
	DropdownMenuContent,
	DropdownMenuItem,
	DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { SUPPORTED_LANGUAGES } from './languages';
import { cn } from '@/lib/utils';

interface CodeExecution {
	id: string;
	code: string;
	language: string;
	stdin: string;
	output: string;
	timestamp: Date;
}

const PREDEFINED_TEST_CASES = [
	{ id: 1, name: 'Test Case 1', input: '5\n10', expectedOutput: '15' },
	{ id: 2, name: 'Test Case 2', input: '0\n0', expectedOutput: '0' },
	{ id: 3, name: 'Test Case 3', input: '-5\n10', expectedOutput: '5' },
	{ id: 4, name: 'Test Case 4', input: '100\n200', expectedOutput: '300' },
];

interface QuestionData {
	questionlevel?: string;
	image?: string[];
	question?: string;
	[key: string]: unknown;
}

interface CodePlaygroundProps {
	question?: QuestionData | null;
	previewUrl?: string;
}

export default function CodePlayground({
	question = null,
	previewUrl: initialPreviewUrl = '',
}: CodePlaygroundProps) {
	const questionData = question;
	const hasQuestion = !!questionData;

	const [code, setCode] = useState('// Write your code here\nconsole.log("Hello, World!");');
	const [language, setLanguage] = useState('javascript');
	const [stdin, setStdin] = useState('');
	const [activeTab, setActiveTab] = useState<'question' | 'history'>(
		hasQuestion ? 'question' : 'history',
	);
	const [bottomTab, setBottomTab] = useState<'console' | 'testcases' | 'stdin-input' | 'preview'>(
		'console',
	);
	const [previewUrl] = useState(initialPreviewUrl);
	const [isSidebarOpen, setIsSidebarOpen] = useState(true);
	const [history, setHistory] = useState<CodeExecution[]>([]);
	const [isExecuting, setIsExecuting] = useState(false);
	const [isMounted, setIsMounted] = useState(false);
	const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
	const [isRaiseBugModalOpen, setIsRaiseBugModalOpen] = useState(false);
	const [bugReport, setBugReport] = useState('');
	const [isFullscreen, setIsFullscreen] = useState(false);
	const editorContainerRef = useRef<HTMLDivElement | null>(null);
	const [terminalEntries, setTerminalEntries] = useState<
		Array<{ command: string; output: string }>
	>([]);
	const [testResults, setTestResults] = useState<
		Array<{ name: string; status: 'pass' | 'fail'; message?: string }>
	>([]);
	const [timerSeconds, setTimerSeconds] = useState(0);
	const [isTimerRunning, setIsTimerRunning] = useState(false);
	const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);
	const editorRef = useRef<editor.IStandaloneCodeEditor | null>(null);
	const terminalScrollRef = useRef<HTMLDivElement | null>(null);
	const inputRef = useRef<HTMLTextAreaElement | null>(null);

	useEffect(() => {
		setIsMounted(true);
	}, []);

	// Auto-scroll to bottom when terminal entries change
	useEffect(() => {
		if (terminalScrollRef.current) {
			terminalScrollRef.current.scrollTop = terminalScrollRef.current.scrollHeight;
		}
	}, [terminalEntries, stdin]);

	// Focus input and scroll to bottom when console tab is active
	useEffect(() => {
		if (bottomTab === 'console') {
			// Scroll to bottom when console tab is focused
			const scrollToBottom = () => {
				if (terminalScrollRef.current) {
					terminalScrollRef.current.scrollTop = terminalScrollRef.current.scrollHeight;
				}
			};

			// Multiple attempts to ensure scroll happens after DOM update
			setTimeout(scrollToBottom, 0);
			setTimeout(scrollToBottom, 50);
			setTimeout(scrollToBottom, 100);

			if (inputRef.current) {
				setTimeout(() => {
					inputRef.current?.focus();
				}, 100);
			}
		}
	}, [bottomTab]);

	// Timer effect
	useEffect(() => {
		if (isTimerRunning) {
			timerIntervalRef.current = setInterval(() => {
				setTimerSeconds(prev => prev + 1);
			}, 1000);
		} else {
			if (timerIntervalRef.current) {
				clearInterval(timerIntervalRef.current);
				timerIntervalRef.current = null;
			}
		}

		return () => {
			if (timerIntervalRef.current) {
				clearInterval(timerIntervalRef.current);
			}
		};
	}, [isTimerRunning]);

	const formatTime = (seconds: number) => {
		const hours = Math.floor(seconds / 3600);
		const minutes = Math.floor((seconds % 3600) / 60);
		const secs = seconds % 60;
		if (hours > 0) {
			return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
		}
		return `${minutes}:${secs.toString().padStart(2, '0')}`;
	};

	const toggleTimer = () => {
		setIsTimerRunning(prev => !prev);
	};

	const resetTimer = () => {
		setIsTimerRunning(false);
		setTimerSeconds(0);
	};

	const toggleFullscreen = () => {
		if (!editorContainerRef.current) return;

		if (!isFullscreen) {
			// Enter fullscreen
			if (editorContainerRef.current.requestFullscreen) {
				editorContainerRef.current.requestFullscreen();
			}
		} else {
			// Exit fullscreen
			if (document.exitFullscreen) {
				document.exitFullscreen();
			}
		}
	};

	// Listen for fullscreen changes
	useEffect(() => {
		const handleFullscreenChange = () => {
			setIsFullscreen(!!document.fullscreenElement);
		};

		document.addEventListener('fullscreenchange', handleFullscreenChange);
		return () => {
			document.removeEventListener('fullscreenchange', handleFullscreenChange);
		};
	}, []);

	const handleEditorDidMount = (editorInstance: editor.IStandaloneCodeEditor) => {
		editorRef.current = editorInstance;
	};

	const executeCode = async () => {
		if (!code.trim()) {
			const errorOutput = 'Error: No code to execute';
			setTerminalEntries(prev => [...prev, { command: '(execute)', output: errorOutput }]);
			return;
		}

		setIsExecuting(true);
		const commandInput = stdin.trim() || '(no input)';
		const displayCommand = commandInput !== '(no input)' ? commandInput : '(executing code)';

		// Add command to terminal with >> prompt
		setTerminalEntries(prev => [...prev, { command: displayCommand, output: 'Executing...' }]);
		setStdin('');

		// Simulate code execution (replace with actual API call later)
		setTimeout(() => {
			const executionOutput = `Code executed successfully!\nLanguage: ${language}\nInput: ${commandInput === '(no input)' ? '(empty)' : commandInput}\n\nOutput:\nThis is a placeholder output. Integration with actual execution API needed.`;

			const execution: CodeExecution = {
				id: Date.now().toString(),
				code,
				language,
				stdin: commandInput,
				output: executionOutput,
				timestamp: new Date(),
			};

			setHistory(prev => [execution, ...prev]);

			// Update terminal entry with result
			setTerminalEntries(prev => {
				const updated = [...prev];
				updated[updated.length - 1] = { command: displayCommand, output: executionOutput };
				return updated;
			});

			// Simulate test case results (replace with actual test execution)
			// Run predefined test cases
			setTimeout(() => {
				const mockResults = PREDEFINED_TEST_CASES.map((testCase, index) => {
					// Mock: randomly pass or fail for demonstration
					// In real implementation, this would execute the code with testCase.input and compare with testCase.expectedOutput
					const shouldPass = index % 2 === 0; // Alternate pass/fail for demo
					return {
						name: testCase.name,
						status: (shouldPass ? 'pass' : 'fail') as 'pass' | 'fail',
						message: shouldPass
							? 'All assertions passed'
							: `Expected: ${testCase.expectedOutput}, Got: different output`,
					};
				});
				setTestResults(mockResults);
			}, 500);

			setIsExecuting(false);
		}, 1000);
	};

	const loadFromHistory = (execution: CodeExecution) => {
		setCode(execution.code);
		setLanguage(execution.language);
		setStdin(execution.stdin);
	};

	const getLanguageForEditor = (lang: string) => {
		const langMap: Record<string, string> = {
			javascript: 'javascript',
			typescript: 'typescript',
			python: 'python',
			python2: 'python',
			java: 'java',
			cpp: 'cpp',
			c: 'c',
			go: 'go',
			rust: 'rust',
			csharp: 'csharp',
			php: 'php',
			ruby: 'ruby',
			swift: 'swift',
			kotlin: 'kotlin',
			dart: 'dart',
			scala: 'scala',
			html: 'html',
		};
		return langMap[lang] || 'javascript';
	};

	const getCurrentLanguageName = () => {
		const lang = SUPPORTED_LANGUAGES.find(l => l.id === language);
		return lang ? lang.name : 'JavaScript';
	};

	const getLanguageFileExtension = (lang: string) => {
		const extensionMap: Record<string, string> = {
			javascript: 'js',
			typescript: 'ts',
			python: 'py',
			java: 'java',
			cpp: 'cpp',
			c: 'c',
			csharp: 'cs',
			go: 'go',
			rust: 'rs',
			php: 'php',
			ruby: 'rb',
			swift: 'swift',
			kotlin: 'kt',
			dart: 'dart',
			scala: 'scala',
		};
		return extensionMap[lang] || 'txt';
	};

	const programmingLanguages = SUPPORTED_LANGUAGES.filter(l => l.languageType === 'programming');
	const webLanguages = SUPPORTED_LANGUAGES.filter(l => l.languageType === 'web');
	const databaseLanguages = SUPPORTED_LANGUAGES.filter(l => l.languageType === 'database');

	return (
		<div
			ref={editorContainerRef}
			className="flex h-[calc(100vh-59px)] w-full overflow-hidden bg-gray-50">
			{/* Left Sidebar - Question and History */}
			<Collapsible
				open={isSidebarOpen}
				onOpenChange={setIsSidebarOpen}
				className=" border-gray-200 bg-white">
				{!isSidebarOpen ? (
					/* Collapsed State - Show Icon Only */
					<div className="flex h-full w-12 flex-col items-center  border-gray-200">
						<CollapsibleTrigger asChild>
							<Button
								variant="ghost"
								className="flex h-[52px] w-12 items-center justify-center border-b border-gray-200 hover:bg-gray-50">
								<ChevronRight className="h-4 w-4" />
							</Button>
						</CollapsibleTrigger>
						<div className="flex flex-col gap-2 p-2">
							{question && (
								<Button
									variant="ghost"
									size="icon"
									className="h-10 w-10"
									onClick={() => {
										setIsSidebarOpen(true);
										setActiveTab('question');
									}}
									title="Question">
									<FileQuestion className="h-4 w-4" />
								</Button>
							)}
							<Button
								variant="ghost"
								size="icon"
								className="h-10 w-10"
								onClick={() => {
									setIsSidebarOpen(true);
									setActiveTab('history');
								}}
								title="History">
								<History className="h-4 w-4" />
							</Button>
						</div>
					</div>
				) : (
					/* Expanded State */
					<div className="flex h-full w-80 flex-col">
						<CollapsibleTrigger asChild>
							<Button
								variant="ghost"
								className="flex h-[52px] w-full items-center justify-between border-b border-r-0 border-gray-200 px-4 hover:bg-gray-50">
								<span className="font-semibold">Code Playground</span>
								<ChevronLeft className="h-4 w-4" />
							</Button>
						</CollapsibleTrigger>
						<CollapsibleContent className="flex-1 overflow-hidden">
							<Tabs
								value={activeTab}
								onValueChange={value => setActiveTab(value as 'question' | 'history')}
								className="flex h-full flex-col">
								<TabsList
									className={`grid w-full border-b border-gray-200 ${hasQuestion ? 'grid-cols-2' : 'grid-cols-1'}`}>
									{hasQuestion && <TabsTrigger value="question">Question</TabsTrigger>}
									<TabsTrigger value="history">History</TabsTrigger>
								</TabsList>

								{hasQuestion && questionData && (
									<TabsContent value="question" className="flex-1 overflow-auto p-4">
										<div className="prose max-w-none">
											{/* Question Level Badge */}
											{questionData.questionlevel && (
												<div className="mb-4">
													<span
														className={`inline-block rounded-full px-3 py-1 text-xs font-semibold ${
															questionData.questionlevel.toLowerCase() === 'hard'
																? 'bg-red-100 text-red-800'
																: questionData.questionlevel.toLowerCase() === 'medium'
																	? 'bg-yellow-100 text-yellow-800'
																	: 'bg-green-100 text-green-800'
														}`}>
														{questionData.questionlevel}
													</span>
												</div>
											)}

											{/* Images */}
											{questionData.image &&
												Array.isArray(questionData.image) &&
												questionData.image.length > 0 && (
													<div className="mb-4 space-y-2">
														{questionData.image.map((img, index) => (
															<img
																key={index}
																src={img}
																alt={`Question ${index + 1}`}
																className="max-w-full rounded-lg border border-gray-200"
															/>
														))}
													</div>
												)}

											{/* Question Content */}
											{questionData.question && (
												<div
													className="question-content"
													dangerouslySetInnerHTML={{ __html: questionData.question }}
												/>
											)}
										</div>
									</TabsContent>
								)}

								<TabsContent value="history" className="flex-1 overflow-auto p-4">
									{history.length === 0 ? (
										<div className="flex h-full items-center justify-center text-sm text-gray-500">
											No execution history yet
										</div>
									) : (
										<div className="space-y-3">
											{history.map(execution => (
												<button
													key={execution.id}
													type="button"
													className="w-full cursor-pointer rounded-lg border border-gray-200 bg-gray-50 p-3 text-left transition-colors hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-[var(--brandColor)] focus:ring-offset-2"
													onClick={() => loadFromHistory(execution)}
													onKeyDown={e => {
														if (e.key === 'Enter' || e.key === ' ') {
															e.preventDefault();
															loadFromHistory(execution);
														}
													}}>
													<div className="mb-2 flex items-center justify-between">
														<span className="text-xs font-medium text-gray-600">
															{execution.language}
														</span>
														<span className="text-xs text-gray-500">
															{execution.timestamp.toLocaleTimeString()}
														</span>
													</div>
													<div className="mb-2 max-h-32 overflow-hidden">
														<pre className="whitespace-pre-wrap break-words text-xs text-gray-700">
															{execution.code.substring(0, 200)}
														</pre>
													</div>
													{execution.stdin && (
														<div className="mb-2 text-xs text-gray-600">
															<span className="font-medium">Input:</span>{' '}
															{execution.stdin.substring(0, 50)}
															{execution.stdin.length > 50 && '...'}
														</div>
													)}
													<div className="text-xs text-gray-600">
														<span className="font-medium">Output:</span>{' '}
														<span className="text-gray-500">
															{execution.output.substring(0, 100)}
														</span>
														{execution.output.length > 100 && '...'}
													</div>
												</button>
											))}
										</div>
									)}
								</TabsContent>
							</Tabs>
						</CollapsibleContent>
					</div>
				)}
			</Collapsible>

			{/* Main Content Area */}
			<div className="flex flex-1 flex-col overflow-hidden">
				{/* Editor Header Bar */}
				<div className="flex h-[52px] items-center justify-between border-b border-gray-200 bg-white">
					{/* Left Side - File Tab and Plus */}
					<div className="flex items-center">
						<div className="flex items-center border-r border-gray-200">
							<div className="flex h-[52px] items-center gap-1 border-b-2 border-blue-500 px-4 py-2">
								<span className="text-sm font-medium text-gray-700">
									Main.{getLanguageFileExtension(language)}
								</span>
							</div>
							<Button
								variant="ghost"
								size="icon"
								className="h-[52px] w-9 rounded-none"
								title="New File">
								<Plus className="h-4 w-4" />
							</Button>
						</div>
					</div>

					{/* Right Side - Actions */}
					<div className="flex items-center gap-2 border-l border-gray-200 px-2">
						{/* Language Selector */}
						<Button
							variant="outline"
							onClick={() => setIsLanguageModalOpen(true)}
							className="gap-1.5 border-[var(--brandColor)] bg-[var(--brandAccent)] text-[var(--brandColor)] hover:bg-[var(--brandAccent-dark)]">
							<span className="text-xs font-medium">{getCurrentLanguageName().toUpperCase()}</span>
							<ChevronDown className="h-3.5 w-3.5" />
						</Button>

						{/* Timer */}
						<div className="flex items-center gap-2 rounded-md border border-gray-200 bg-gray-50 px-2 py-1">
							<span className="font-mono text-xs text-gray-700">{formatTime(timerSeconds)}</span>
							<Button
								variant="ghost"
								size="icon"
								className="h-6 w-6"
								onClick={toggleTimer}
								title={isTimerRunning ? 'Pause Timer' : 'Start Timer'}>
								{isTimerRunning ? <Pause className="h-3 w-3" /> : <Play className="h-3 w-3" />}
							</Button>
							<Button
								variant="ghost"
								size="icon"
								className="h-6 w-6"
								onClick={resetTimer}
								title="Reset Timer">
								<RotateCcw className="h-3 w-3" />
							</Button>
						</div>

						{/* RUN Button */}
						<Button
							onClick={executeCode}
							disabled={isExecuting}
							className="gap-1.5 bg-[var(--brandColor)] text-xs text-white hover:bg-[var(--brandColor-dark)] disabled:opacity-50">
							<Play className="h-3.5 w-3.5 fill-white" />
							RUN
						</Button>

						{/* More Options */}
						<DropdownMenu>
							<DropdownMenuTrigger asChild>
								<Button variant="ghost" size="icon" className="h-8 w-8">
									<MoreVertical className="h-4 w-4" />
								</Button>
							</DropdownMenuTrigger>
							<DropdownMenuContent align="end">
								<DropdownMenuItem onClick={toggleFullscreen}>
									<Maximize2 className="mr-2 h-4 w-4" />
									{isFullscreen ? 'Exit Fullscreen' : 'Go to Fullscreen'}
								</DropdownMenuItem>
								<DropdownMenuItem onClick={() => setIsRaiseBugModalOpen(true)}>
									<Bug className="mr-2 h-4 w-4" />
									Raise Bug
								</DropdownMenuItem>
							</DropdownMenuContent>
						</DropdownMenu>
					</div>
				</div>

				{/* Main Content - Editor on top, Output below */}
				<div className="flex flex-1 flex-col overflow-hidden">
					{/* Code Editor Section */}
					<div className="flex-1 overflow-hidden border-b border-gray-200">
						{isMounted ? (
							<Editor
								height="100%"
								language={getLanguageForEditor(language)}
								value={code}
								onChange={value => setCode(value || '')}
								onMount={handleEditorDidMount}
								theme="vs-light"
								options={{
									minimap: { enabled: true },
									fontSize: 14,
									wordWrap: 'on',
									automaticLayout: true,
									scrollBeyondLastLine: false,
								}}
							/>
						) : (
							<div className="flex h-full items-center justify-center">Loading editor...</div>
						)}
					</div>

					{/* Bottom Section with Tabs - Below Editor */}
					<div className="flex h-64 flex-col border-t border-gray-300 bg-white">
						<Tabs
							value={bottomTab}
							onValueChange={value => {
								if (
									value === 'console' ||
									value === 'testcases' ||
									value === 'stdin-input' ||
									value === 'preview'
								) {
									setBottomTab(value);
								}
							}}
							className="flex h-full flex-col">
							<TabsList className="inline-flex h-9 items-center justify-start gap-1 border-b border-gray-300 bg-gray-50 px-2.5 py-1">
								<TabsTrigger value="console" className="px-2.5">
									Console
								</TabsTrigger>
								<TabsTrigger value="preview" className="px-2.5">
									Preview
								</TabsTrigger>
								<TabsTrigger value="stdin-input" className="px-2.5">
									Stdin Input
								</TabsTrigger>
								<TabsTrigger value="testcases" className="px-2.5">
									Testcases
								</TabsTrigger>
							</TabsList>

							{/* Console Tab - Merged Input/Output */}
							<TabsContent value="console" className="flex flex-1 flex-col overflow-hidden">
								<div
									ref={terminalScrollRef}
									className="flex-1 overflow-auto bg-white p-3 font-mono text-sm"
									onFocus={() => {
										if (terminalScrollRef.current) {
											setTimeout(() => {
												if (terminalScrollRef.current) {
													terminalScrollRef.current.scrollTop =
														terminalScrollRef.current.scrollHeight;
												}
											}, 0);
										}
									}}>
									<pre className="m-0">
										<code className="block space-y-2">
											{/* Terminal History */}
											{terminalEntries.length === 0 ? (
												<span className="mb-2 text-gray-400">Welcome to QConnect Playground</span>
											) : (
												terminalEntries.map((entry, index) => (
													<div key={index} className="space-y-1">
														{entry.command && (
															<div className="flex items-start gap-2 text-gray-800">
																<span className="text-gray-500">&gt;&gt;</span>
																<span>{entry.command}</span>
															</div>
														)}
														<div className="flex items-start gap-2">
															<span className="text-gray-500">&gt;&gt;</span>
															<div className="flex-1 whitespace-pre-wrap text-gray-700">
																{entry.output}
															</div>
														</div>
													</div>
												))
											)}

											{/* Current Input Prompt - Always at the bottom */}
											<div className="flex items-start gap-2">
												<span className="text-gray-500">&gt;&gt;</span>
												<Textarea
													ref={inputRef}
													id="stdin-input"
													value={stdin}
													onChange={e => {
														setStdin(e.target.value);
														// Auto-resize textarea
														if (inputRef.current) {
															inputRef.current.style.height = 'auto';
															inputRef.current.style.height = `${Math.min(inputRef.current.scrollHeight, 200)}px`;
														}
													}}
													placeholder="Type input here..."
													className="flex-1 resize-none overflow-y-auto border-0 border-b-0 bg-transparent p-0 text-sm text-gray-800 shadow-none placeholder:text-gray-400 focus-visible:ring-0"
													style={{
														borderBottom: 'none',
														outline: 'none',
														textShadow: 'none',
														boxShadow: 'none',
														minHeight: '200px',
														maxHeight: '200px',
													}}
													rows={1}
													onKeyDown={e => {
														if (e.key === 'Enter' && !e.shiftKey) {
															e.preventDefault();
															if (!isExecuting && stdin.trim()) {
																executeCode();
															}
														}
													}}
												/>
											</div>
										</code>
									</pre>
								</div>
							</TabsContent>

							{/* Stdin Input Tab */}
							<TabsContent value="stdin-input" className="flex flex-1 flex-col overflow-hidden p-4">
								<div className="flex flex-1 flex-col gap-2">
									<Textarea
										id="stdin-input-tab"
										value={stdin}
										onChange={e => setStdin(e.target.value)}
										placeholder="Enter input here..."
										className="flex-1 resize-none font-mono text-sm focus-visible:outline-none focus-visible:ring-0"
										style={{ outline: 'none' }}
										onKeyDown={e => {
											if (e.key === 'Enter' && e.ctrlKey) {
												e.preventDefault();
												if (!isExecuting && stdin.trim() && code.trim()) {
													executeCode();
												}
											}
										}}
									/>
								</div>
							</TabsContent>

							{/* Preview Tab */}
							<TabsContent
								value="preview"
								className="relative flex flex-1 flex-col overflow-hidden">
								{previewUrl ? (
									<>
										<Button
											variant="ghost"
											size="icon"
											className="absolute right-2 top-2 z-10 h-8 w-8 bg-white/80 hover:bg-white"
											onClick={() => window.open(previewUrl, '_blank')}
											title="Open in full view">
											<Maximize2 className="h-4 w-4" />
										</Button>
										<iframe
											src={previewUrl}
											className="h-full w-full border-0"
											title="Preview"
											sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals"
										/>
									</>
								) : (
									<div className="flex h-full items-center justify-center text-gray-400">
										No preview URL provided
									</div>
								)}
							</TabsContent>

							{/* Testcases Tab */}
							<TabsContent value="testcases" className="flex flex-1 flex-col overflow-hidden">
								{/* Test Results - Full height and width */}
								<div className="flex h-full w-full flex-col overflow-auto p-4">
									{testResults.length === 0 ? (
										<div className="flex h-full items-center justify-center">
											<span className="text-sm text-gray-400">
												No test results yet. Execute code to see test case results.
											</span>
										</div>
									) : (
										<div className="space-y-2">
											{testResults.map((result, index) => (
												<div key={index} className="flex items-start gap-2 text-sm">
													{result.status === 'pass' ? (
														<span className="font-semibold text-green-600">✓</span>
													) : (
														<span className="font-semibold text-red-600">✗</span>
													)}
													<div className="flex-1">
														<span
															className={`font-medium ${result.status === 'pass' ? 'text-green-700' : 'text-red-700'}`}>
															{result.name}
														</span>
														{result.status === 'pass' ? (
															<span className="ml-2 text-green-600">Passed</span>
														) : (
															<span className="ml-2 text-red-600">Failed</span>
														)}
														{result.message && (
															<div className="mt-1 text-xs text-gray-600">{result.message}</div>
														)}
													</div>
												</div>
											))}
										</div>
									)}
								</div>
							</TabsContent>
						</Tabs>
					</div>
				</div>
			</div>

			{/* Language Selection Modal */}
			<Dialog open={isLanguageModalOpen} onOpenChange={setIsLanguageModalOpen}>
				<DialogContent className="flex max-h-[80vh] max-w-3xl flex-col overflow-hidden">
					<DialogHeader>
						<DialogTitle>Select Language</DialogTitle>
					</DialogHeader>
					<div className="flex-1 overflow-auto">
						<Tabs defaultValue="programming" className="w-full">
							<TabsList className="grid w-full grid-cols-3">
								<TabsTrigger value="programming">Programming</TabsTrigger>
								<TabsTrigger value="web">Web</TabsTrigger>
								<TabsTrigger value="database">Database</TabsTrigger>
							</TabsList>

							<TabsContent value="programming" className="mt-4">
								<div className="flex flex-wrap gap-2">
									{programmingLanguages.map(lang => (
										<Button
											key={lang.id}
											variant="outline"
											className={cn(
												'h-auto w-fit px-3 py-2 text-sm',
												language === lang.id
													? 'border-[var(--brandColor)] bg-[var(--brandColor)] text-white hover:border-[var(--brandColor-dark)] hover:bg-[var(--brandColor-dark)]'
													: 'hover:border-[var(--brandColor)] hover:bg-[var(--brandAccent)] hover:text-[var(--brandColor-dark)]',
											)}
											onClick={() => {
												setLanguage(lang.id);
												setIsLanguageModalOpen(false);
											}}>
											{lang.name}
										</Button>
									))}
								</div>
							</TabsContent>

							<TabsContent value="web" className="mt-4">
								<div className="flex flex-wrap gap-2">
									{webLanguages.map(lang => (
										<Button
											key={lang.id}
											variant="outline"
											className={cn(
												'h-auto w-fit px-3 py-2 text-sm',
												language === lang.id
													? 'border-[var(--brandColor)] bg-[var(--brandColor)] text-white hover:border-[var(--brandColor-dark)] hover:bg-[var(--brandColor-dark)]'
													: 'hover:border-[var(--brandColor)] hover:bg-[var(--brandAccent)] hover:text-[var(--brandColor-dark)]',
											)}
											onClick={() => {
												setLanguage(lang.id);
												setIsLanguageModalOpen(false);
											}}>
											{lang.name}
										</Button>
									))}
								</div>
							</TabsContent>

							<TabsContent value="database" className="mt-4">
								<div className="flex flex-wrap gap-2">
									{databaseLanguages.map(lang => (
										<Button
											key={lang.id}
											variant="outline"
											className={cn(
												'h-auto w-fit px-3 py-2 text-sm',
												language === lang.id
													? 'border-[var(--brandColor)] bg-[var(--brandColor)] text-white hover:border-[var(--brandColor-dark)] hover:bg-[var(--brandColor-dark)]'
													: 'hover:border-[var(--brandColor)] hover:bg-[var(--brandAccent)] hover:text-[var(--brandColor-dark)]',
											)}
											onClick={() => {
												setLanguage(lang.id);
												setIsLanguageModalOpen(false);
											}}>
											{lang.name}
										</Button>
									))}
								</div>
							</TabsContent>
						</Tabs>
					</div>
				</DialogContent>
			</Dialog>

			{/* Raise Bug Modal */}
			<Dialog open={isRaiseBugModalOpen} onOpenChange={setIsRaiseBugModalOpen}>
				<DialogContent className="max-w-2xl">
					<DialogHeader>
						<DialogTitle>Raise Bug</DialogTitle>
						<DialogDescription>
							Report an issue with the code playground. Your current environment details will be
							included.
						</DialogDescription>
					</DialogHeader>
					<div className="space-y-4">
						{/* Current Active Information */}
						<div className="rounded-lg border border-gray-200 bg-gray-50 p-3">
							<p className="mb-2 text-xs font-semibold text-gray-700">
								Current Active Information:
							</p>
							<div className="space-y-1 text-xs text-gray-600">
								<p>
									<span className="font-medium">Language:</span> {getCurrentLanguageName()}
								</p>
								<p>
									<span className="font-medium">File:</span> Main.
									{getLanguageFileExtension(language)}
								</p>
								{questionData && (
									<p>
										<span className="font-medium">Question:</span>{' '}
										{questionData.questionlevel || 'N/A'}
									</p>
								)}
							</div>
							{code && (
								<div className="mt-2">
									<p className="mb-1 text-xs font-medium text-gray-700">Code Preview:</p>
									<pre className="max-h-32 overflow-auto rounded bg-gray-100 p-2 text-xs text-gray-800">
										{code.substring(0, 200)}
										{code.length > 200 ? '...' : ''}
									</pre>
								</div>
							)}
						</div>

						{/* Bug Report Textarea */}
						<div className="space-y-2">
							<label htmlFor="bug-report" className="text-sm font-medium text-gray-700">
								Describe the issue
							</label>
							<Textarea
								id="bug-report"
								value={bugReport}
								onChange={e => setBugReport(e.target.value)}
								placeholder="Please describe the issue you encountered..."
								className="min-h-32"
								rows={6}
							/>
						</div>

						{/* Send Button */}
						<div className="flex justify-end gap-2">
							<Button
								variant="outline"
								onClick={() => {
									setIsRaiseBugModalOpen(false);
									setBugReport('');
								}}>
								Cancel
							</Button>
							<Button
								onClick={() => {
									// TODO: Implement bug report submission
									// Bug report data will be sent to backend
									// const bugData = {
									// 	report: bugReport,
									// 	language: getCurrentLanguageName(),
									// 	file: `Main.${getLanguageFileExtension(language)}`,
									// 	questionLevel: questionData?.questionlevel,
									// 	codePreview: code.substring(0, 200),
									// };
									// Send bug report (implement API call here)
									setIsRaiseBugModalOpen(false);
									setBugReport('');
								}}
								disabled={!bugReport.trim()}
								className="bg-[var(--brandColor)] text-white hover:bg-[var(--brandColor-dark)]">
								Send
							</Button>
						</div>
					</div>
				</DialogContent>
			</Dialog>
		</div>
	);
}
