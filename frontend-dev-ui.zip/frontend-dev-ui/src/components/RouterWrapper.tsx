import { BrowserRouter } from 'react-router-dom';
import { type ReactNode } from 'react';

interface RouterWrapperProps {
	children: ReactNode;
}

export default function RouterWrapper({ children }: RouterWrapperProps) {
	return <BrowserRouter>{children}</BrowserRouter>;
}
