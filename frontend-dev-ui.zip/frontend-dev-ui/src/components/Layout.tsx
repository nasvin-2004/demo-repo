/* eslint-disable @typescript-eslint/no-explicit-any */
import { useStore } from '@nanostores/react';
import { $auth, setLoginDataStateOnly } from '@/stores/profileStore';
import NavBar from '@/components/header/Navbar';
import RouterWrapper from '@/components/RouterWrapper';
import { useEffect } from 'react';
import { setPlanAccess } from '@/stores/planStore';

interface LayoutProps {
	currentPath: string;
	modules: any[];
	userData?: any;
	authData?: any;
	children: React.ReactNode;
}

export default function Layout({
	currentPath,
	modules,
	userData,
	authData,
	children,
}: LayoutProps) {
	useEffect(() => {
		if (userData && authData) {
			setLoginDataStateOnly(userData, authData.modules);
			if (authData.plans) setPlanAccess(authData.plans);
		}
	}, [userData, authData]);

	const auth = useStore($auth);

	return (
		<RouterWrapper>
			{auth && <NavBar currentPath={currentPath} modules={modules} />}
			{children}
		</RouterWrapper>
	);
}
