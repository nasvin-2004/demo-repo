import { useEffect, useState } from 'react';
import { getCurrentWorkspaceActivePlan, type WorkspaceSubscription } from '@/services/plan.service';
import { toast } from 'sonner';
import { CreditCardIcon, PackageIcon } from 'lucide-react';

export default function BillingPage() {
	const [currentActivePlan, setCurrentActivePlan] = useState<WorkspaceSubscription | null>(null);
	const [loading, setLoading] = useState(true);

	useEffect(() => {
		loadData();
	}, []);

	const loadData = async () => {
		setLoading(true);
		try {
			const activePlanResponse = await getCurrentWorkspaceActivePlan();

			if (activePlanResponse.success && activePlanResponse.data) {
				setCurrentActivePlan(activePlanResponse.data);
			} else if (activePlanResponse.data === null) {
				// No active plan found - this is okay, just set to null
				setCurrentActivePlan(null);
			} else {
				toast.error(activePlanResponse.message || 'Failed to load current active plan');
			}
		} catch (error) {
			// eslint-disable-next-line no-console
			console.error('Error loading billing data:', error);
			toast.error('Failed to load billing information');
		} finally {
			setLoading(false);
		}
	};

	const formatPrice = (price: number | null) => {
		if (price === null) return 'N/A';
		return new Intl.NumberFormat('en-IN', {
			style: 'currency',
			currency: 'INR',
		}).format(price);
	};

	const formatDate = (dateString: string) => {
		return new Date(dateString).toLocaleDateString('en-US', {
			year: 'numeric',
			month: 'short',
			day: 'numeric',
		});
	};

	if (loading) {
		return (
			<div className="flex h-[calc(100vh-5rem)] items-center justify-center">
				<div className="text-center">
					<div className="mb-4 inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-[var(--brandColor)] border-r-transparent"></div>
					<p className="text-gray-600">Loading billing information...</p>
				</div>
			</div>
		);
	}

	return (
		<div className="w-full px-4 py-6">
			{/* Header */}
			<div className="mb-6">
				<h1 className="text-2xl font-semibold text-gray-800">Billing & Plans</h1>
				<p className="mt-1 text-sm text-gray-600">View your current active plan</p>
			</div>

			{/* Current Active Plan */}
			<div className="space-y-6">
				{!currentActivePlan ? (
					<div className="rounded-lg bg-white p-8 text-center">
						<PackageIcon className="mx-auto mb-4 h-12 w-12 text-gray-400" />
						<p className="text-lg font-medium text-gray-800">No Active Plan</p>
						<p className="mt-2 text-sm text-gray-600">
							Your workspace does not have an active plan subscription.
						</p>
					</div>
				) : (
					<div className="rounded-lg border border-gray-200 bg-white p-6">
						<div className="mb-6 flex items-start justify-between">
							<div>
								<div className="flex items-center gap-2">
									<h2 className="text-2xl font-semibold text-gray-800">
										{currentActivePlan.plan.name}
									</h2>
									<span
										className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${
											currentActivePlan.plan.type === 'MAIN'
												? 'bg-blue-100 text-blue-800'
												: 'bg-purple-100 text-purple-800'
										}`}>
										{currentActivePlan.plan.type}
									</span>
									<span className="rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
										Active
									</span>
								</div>
								{currentActivePlan.plan.description && (
									<p className="mt-2 text-sm text-gray-600">{currentActivePlan.plan.description}</p>
								)}
								<p className="mt-2 text-sm text-gray-500">
									Workspace: <span className="font-medium">{currentActivePlan.workspace.name}</span>
								</p>
							</div>
							<div className="text-right">
								<div className="text-sm text-gray-500">Monthly</div>
								<div className="text-lg font-semibold text-gray-800">
									{formatPrice(currentActivePlan.plan.priceMonthly)}
								</div>
								<div className="text-sm text-gray-500">Yearly</div>
								<div className="text-lg font-semibold text-gray-800">
									{formatPrice(currentActivePlan.plan.priceYearly)}
								</div>
							</div>
						</div>

						<div className="mb-4 grid grid-cols-1 gap-4 border-t border-gray-200 pt-4 md:grid-cols-2">
							<div>
								<p className="text-xs text-gray-500">Subscription Started</p>
								<p className="text-sm font-medium text-gray-800">
									{formatDate(currentActivePlan.startsAt)}
								</p>
							</div>
							<div>
								<p className="text-xs text-gray-500">Subscription Ends</p>
								<p className="text-sm font-medium text-gray-800">
									{currentActivePlan.endsAt
										? formatDate(currentActivePlan.endsAt)
										: 'No expiry date'}
								</p>
							</div>
						</div>

						{/* Plan Features */}
						{currentActivePlan.plan.features && currentActivePlan.plan.features.length > 0 && (
							<div className="mt-4 border-t border-gray-200 pt-4">
								<h3 className="mb-3 text-sm font-semibold text-gray-700">Plan Features:</h3>
								<div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
									{currentActivePlan.plan.features.map(feature => (
										<div
											key={feature.id}
											className="rounded-md border border-gray-100 bg-gray-50 p-3">
											<div className="flex items-center gap-2">
												<CreditCardIcon className="h-4 w-4 text-[var(--brandColor)]" />
												<span className="text-sm font-medium text-gray-700">
													{feature.identifier.displayName || feature.identifier.key}
												</span>
											</div>
											<div className="mt-1 text-xs text-gray-600">
												{feature.identifier.type === 'CREDIT' ? (
													<span>
														Value: <strong>{feature.valueInt}</strong>
													</span>
												) : (
													<span>
														Access: <strong>{feature.valueBool ? 'Yes' : 'No'}</strong>
													</span>
												)}
											</div>
											{feature.identifier.description && (
												<p className="mt-1 text-xs text-gray-500">
													{feature.identifier.description}
												</p>
											)}
										</div>
									))}
								</div>
							</div>
						)}
					</div>
				)}
			</div>
		</div>
	);
}
