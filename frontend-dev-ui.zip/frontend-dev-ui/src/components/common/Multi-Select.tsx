import * as React from 'react';
import { X, Check, ChevronsUpDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
	Command,
	CommandEmpty,
	CommandGroup,
	CommandInput,
	CommandItem,
	CommandList,
} from '@/components/ui/command';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';

export interface MultiSelectOption {
	label: string;
	value: string;
}

interface MultiSelectProps {
	options: MultiSelectOption[];
	value: string[];
	onChange: (value: string[]) => void;
	placeholder?: string;
}

export const MultiSelect: React.FC<MultiSelectProps> = ({
	options,
	value,
	onChange,
	placeholder = 'Select options',
}) => {
	const [open, setOpen] = React.useState(false);

	const handleSelect = (val: string) => {
		if (value.includes(val)) {
			onChange(value.filter(v => v !== val));
		} else {
			onChange([...value, val]);
		}
	};

	const removeValue = (val: string) => {
		onChange(value.filter(v => v !== val));
	};

	const selectedOptions = options.filter(opt => value.includes(opt.value));

	return (
		<div className="w-full">
			<Popover open={open} onOpenChange={setOpen}>
				<PopoverTrigger asChild>
					<Button
						variant="outline"
						role="combobox"
						aria-expanded={open}
						className={cn(
							'border-border flex min-h-[44px] w-full items-center justify-between overflow-hidden rounded-md border px-3 py-2 text-sm font-normal',
							value.length === 0 && 'text-muted-foreground',
						)}>
						<div className="flex flex-1 flex-wrap items-center gap-1 text-left">
							{selectedOptions.length > 0 ? (
								selectedOptions.map(opt => (
									<span
										key={opt.value}
										className="border-border flex items-center gap-2 rounded-md border bg-gray-100 px-1.5 py-1.5 text-xs text-gray-700">
										{opt.label}
										<button
											onClick={e => {
												e.stopPropagation();
												removeValue(opt.value);
											}}
											className="text-gray-500 hover:text-gray-800">
											<X size={12} />
										</button>
									</span>
								))
							) : (
								<span className="text-muted-foreground truncate">{placeholder}</span>
							)}
						</div>

						<ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
					</Button>
				</PopoverTrigger>

				<PopoverContent
					align="start"
					side="bottom"
					className="w-[var(--radix-popover-trigger-width)] p-0">
					<Command>
						<CommandInput placeholder="Search..." />
						<CommandList>
							<CommandEmpty>No options found.</CommandEmpty>
							<CommandGroup>
								{options.map(option => (
									<CommandItem key={option.value} onSelect={() => handleSelect(option.value)}>
										<Check
											className={cn(
												'mr-2 h-4 w-4',
												value.includes(option.value) ? 'opacity-100' : 'opacity-0',
											)}
										/>
										{option.label}
									</CommandItem>
								))}
							</CommandGroup>
						</CommandList>
					</Command>
				</PopoverContent>
			</Popover>
		</div>
	);
};
