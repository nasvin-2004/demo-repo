import { Info } from 'lucide-react';
import * as Popover from '@/components/ui/popover'; // Use your popover/tooltip abstraction

interface HoverSearchInfoPopoverProps {
	fields: string[];
	align?: 'start' | 'center' | 'end';
}

const HoverSearchInfoPopover: React.FC<HoverSearchInfoPopoverProps> = ({
	fields,
	align = 'start', // left alignment so it's consistent everywhere
}) => {
	return (
		<Popover.Popover>
			<Popover.PopoverTrigger asChild>
				<span className="cursor-pointer text-gray-400 hover:text-[var(--brandColor)]">
					<Info className="h-6 w-4" />
				</span>
			</Popover.PopoverTrigger>
			<Popover.PopoverContent
				align={align}
				side="bottom"
				sideOffset={8}
				className={`
          z-50 w-[245px] rounded-xl border
          border-[#f5f5f7] bg-white px-5
          py-4
          shadow-[0_4px_24px_rgba(0,0,0,0.08)]
        `}>
				<div className="mb-2 flex items-center gap-2">
					<Info className="h-5 w-5 text-[var(--brandColor)]" />
					<span className="text-base font-semibold text-gray-700">Searchable Fields</span>
				</div>
				<div className="mb-3 text-sm font-normal text-gray-500">
					You can search across the following fields:
				</div>
				<ul className="mb-4 mt-1 flex flex-col gap-1 pl-1">
					{fields.map(field => (
						<li key={field} className="flex items-center gap-2 text-sm text-gray-700">
							<span
								className="inline-block h-2 w-2 rounded-full"
								style={{ background: '#17c29c' }}
							/>
							{field}
						</li>
					))}
				</ul>
				<div className="mt-3 flex items-center rounded bg-gray-100/60 px-2 py-2 text-xs text-gray-600">
					<span role="img" aria-label="bulb" className="mr-2">
						💡
					</span>
					Just type your search term – we&apos;ll search across all these fields automatically
				</div>
			</Popover.PopoverContent>
		</Popover.Popover>
	);
};

export default HoverSearchInfoPopover;
