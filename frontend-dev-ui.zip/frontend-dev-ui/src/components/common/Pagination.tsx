import { ChevronDown } from 'lucide-react';

type PaginationBarProps = {
	page: number;
	totalPages: number;
	limit: number;
	onLimitChange: (limit: number) => void;
	onPageChange: (page: number) => void;
	limitOptions?: number[];
};

function PaginationBar({
	page,
	totalPages,
	limit,
	onLimitChange,
	onPageChange,
	limitOptions = [10, 20, 50, 100],
}: PaginationBarProps) {
	const getPageNumbers = (): (number | string)[] => {
		if (totalPages <= 7) return [...Array(totalPages)].map((_, i) => i + 1);
		if (page <= 4) return [1, 2, 3, 4, 5, '...', totalPages];
		if (page >= totalPages - 3)
			return [1, '...', totalPages - 4, totalPages - 3, totalPages - 2, totalPages - 1, totalPages];
		return [1, '...', page - 1, page, page + 1, '...', totalPages];
	};

	return (
		<div className="flex items-center gap-2 py-6">
			<div className="group relative flex items-center">
				<select
					value={limit}
					onChange={e => onLimitChange(Number(e.target.value))}
					className="cursor-pointer appearance-none bg-transparent py-1 pl-2 pr-6 text-sm text-gray-500 focus:outline-none"
					style={{ minWidth: 36 }}>
					{limitOptions.map(val => (
						<option key={val} value={val}>
							{val}
						</option>
					))}
				</select>
				<ChevronDown className="pointer-events-none absolute right-1 h-4 w-4 text-gray-400" />
			</div>

			<button
				disabled={page === 1}
				onClick={() => onPageChange(page - 1)}
				className="h-7 w-7 rounded text-gray-500 hover:bg-gray-100 disabled:text-gray-300"
				aria-label="Previous page">
				&lt;
			</button>
			{getPageNumbers().map((p, idx) =>
				p === '...' ? (
					<span
						key={idx}
						className="flex h-7 w-7 select-none items-center justify-center text-gray-400"
						tabIndex={-1}>
						...
					</span>
				) : (
					<button
						key={p}
						onClick={() => onPageChange(p as number)}
						aria-current={p === page ? 'page' : undefined}
						className={`h-7 w-7 rounded text-sm transition
              ${
								p === page
									? 'bg-transparent font-semibold text-gray-500'
									: 'text-gray-500 hover:bg-gray-100'
							}`}
						disabled={p === page}>
						{p}
					</button>
				),
			)}
			<button
				disabled={page === totalPages}
				onClick={() => onPageChange(page + 1)}
				className="h-7 w-7 rounded text-gray-500 hover:bg-gray-100 disabled:text-gray-300"
				aria-label="Next page">
				&gt;
			</button>
		</div>
	);
}

export default PaginationBar;
