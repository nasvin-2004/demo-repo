'use client';

import * as React from 'react';
import {
	Dialog,
	DialogContent,
	DialogDescription,
	DialogFooter,
	DialogHeader,
	DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { Loader2 } from 'lucide-react';

interface CommonModalProps {
	isOpen: boolean;
	onOpenChange: (open: boolean) => void;
	title?: string;
	description?: string;
	showCancel?: boolean;
	showConfirm?: boolean;
	cancelText?: string;
	confirmText?: string;
	isLoading?: boolean;
	onCancel?: () => void;
	onConfirm?: () => void;
	confirmVariant?: 'default' | 'destructive' | 'outline' | 'secondary';
	children?: React.ReactNode;
	className?: string;
}

const CommonModal: React.FC<CommonModalProps> = ({
	isOpen,
	onOpenChange,
	title = 'Modal Title',
	description,
	showCancel = true,
	showConfirm = true,
	cancelText = 'Cancel',
	confirmText = 'Confirm',
	isLoading = false,
	onCancel,
	onConfirm,
	confirmVariant = 'default',
	children,
	className,
}) => {
	const handleCancel = () => {
		if (isLoading) return;
		onCancel?.();
		onOpenChange(false);
	};

	const handleConfirm = () => {
		if (isLoading) return;
		onConfirm?.();
	};

	return (
		<Dialog open={isOpen} onOpenChange={isLoading ? undefined : onOpenChange}>
			<DialogContent className={cn('w-full rounded-lg bg-white p-6 sm:max-w-lg', className)}>
				{(title || description) && (
					<DialogHeader>
						{title && (
							<DialogTitle className="text-lg font-semibold text-gray-900">{title}</DialogTitle>
						)}
						{description && (
							<DialogDescription className="text-sm text-gray-600">{description}</DialogDescription>
						)}
					</DialogHeader>
				)}

				{/* Custom content area (like inputs, forms, etc.) */}
				{children && <div className="my-5">{children}</div>}

				<DialogFooter className="flex justify-end gap-3 pt-2">
					{showCancel && (
						<Button
							variant="outline"
							onClick={handleCancel}
							disabled={isLoading}
							className="cursor-pointer border-[var(--brandColor)] text-[var(--brandColor)] hover:text-[var(--brandColor-dark)]">
							{cancelText}
						</Button>
					)}
					{showConfirm && (
						<Button
							variant={confirmVariant}
							onClick={handleConfirm}
							disabled={isLoading}
							className="cursor-pointer bg-[var(--brandColor)] hover:!bg-[var(--brandColor-dark)]">
							{isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
							{confirmText}
						</Button>
					)}
				</DialogFooter>
			</DialogContent>
		</Dialog>
	);
};

export default CommonModal;
