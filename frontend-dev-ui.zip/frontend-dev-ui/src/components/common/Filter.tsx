import React, { useEffect, useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { ChevronDown } from 'lucide-react';
import clsx from 'clsx';

// Dropdown component for sidebar-style filters
type MultiFilterDropdownProps = {
	icon?: React.ReactNode;
	label: string;
	options: { label: string; value: string; onClick?: () => void }[];
	className?: string;
};

const MultiFilterDropdown: React.FC<MultiFilterDropdownProps> = ({
	icon,
	label,
	options,
	className = '',
}) => {
	const [open, setOpen] = useState(false);

	return (
		<div className={clsx('flex select-none flex-col', className)}>
			<button
				type="button"
				aria-label={label}
				onClick={() => setOpen(o => !o)}
				className={clsx(
					'flex w-full items-center gap-2 px-2 py-1 text-[16px] font-medium',
					'border-0 bg-transparent text-gray-500 outline-none transition-colors',
				)}
				style={{ userSelect: 'none' }}>
				{icon && <span className="mr-[2px]">{icon}</span>}
				<span>{label}</span>
				<ChevronDown
					className={clsx('ml-auto h-4 w-4 transition-transform', open && 'rotate-180')}
				/>
			</button>
			{open && (
				<div className="mt-1 flex flex-col gap-1 pl-8">
					{options.map(opt => (
						<button
							key={opt.value}
							type="button"
							className="rounded px-0 py-[2px] text-left text-[15px] font-normal text-gray-500 outline-none"
							onClick={opt.onClick}
							tabIndex={0}>
							{opt.label}
						</button>
					))}
				</div>
			)}
		</div>
	);
};

export type FilterFieldType =
	| { type: 'text'; id: string; label: string; placeholder?: string }
	| { type: 'number'; id: string; label: string; placeholder?: string }
	| { type: 'select'; id: string; label: string; options: { value: string; label: string }[] }
	| {
			type: 'multi-dropdown';
			id: string;
			label: string;
			icon?: React.ReactNode;
			options: { value: string; label: string; onClick?: () => void }[];
	  }
	| { type: 'date'; id: string; label: string };

export type FilterValue = string | number | boolean | null;

interface GlobalFilterProps {
	fields?: FilterFieldType[];
	onChange?: (values: Record<string, FilterValue>) => void;
	initialValues?: Record<string, FilterValue>;
}

const GlobalFilter: React.FC<GlobalFilterProps> = ({
	fields = [],
	onChange,
	initialValues = {},
}) => {
	const [values, setValues] = useState<Record<string, FilterValue>>(initialValues);

	useEffect(() => {
		setValues(initialValues);
	}, [initialValues]);

	const handleChange = (id: string, value: FilterValue) => {
		const newValues = { ...values, [id]: value };
		setValues(newValues);
		if (onChange) onChange(newValues);
	};

	const handleClear = () => {
		const resetValues: Record<string, FilterValue> = {};
		fields.forEach(f => {
			resetValues[f.id] = '';
		});
		setValues(resetValues);
		if (onChange) onChange(resetValues);
	};

	return (
		<div className="h-fit w-full rounded-lg bg-white p-4 md:min-h-[calc(99vh-5rem)] md:w-1/5">
			<div className="mb-6 flex items-center justify-between">
				<h2 className="text-xl font-semibold text-gray-600">Filter</h2>
				<Button
					onClick={handleClear}
					variant="ghost"
					className="cursor-pointer text-sm text-[var(--brandColor)] underline hover:!bg-transparent hover:text-[var(--brandColor-dark)]">
					Clear Filters
				</Button>
			</div>

			<div className="flex flex-col gap-5">
				{fields?.map(field => {
					switch (field.type) {
						case 'text':
						case 'number':
							return (
								<div key={field.id} className="flex flex-col">
									<Label className="text-muted-foreground mb-1 text-sm font-medium">
										{field.label}
									</Label>
									<Input
										type={field.type}
										placeholder={field.placeholder || `Enter ${field.label}`}
										value={(values[field.id] as string) || ''}
										onChange={e => handleChange(field.id, e.target.value)}
										className="rounded-sm"
									/>
								</div>
							);
						case 'select':
							return (
								<div key={field.id} className="flex flex-col">
									<Label className="text-muted-foreground mb-1 text-sm font-medium">
										{field.label}
									</Label>
									<Select
										value={(values[field.id] as string) || ''}
										onValueChange={val => handleChange(field.id, val)}>
										<SelectTrigger className="border-border w-full cursor-pointer rounded-sm border px-3 py-2">
											<SelectValue placeholder={`Select ${field.label}`} />
										</SelectTrigger>
										<SelectContent>
											{field.options?.map(opt => (
												<SelectItem key={opt.value} value={opt.value}>
													{opt.label}
												</SelectItem>
											))}
										</SelectContent>
									</Select>
								</div>
							);
						case 'multi-dropdown':
							return (
								<MultiFilterDropdown
									key={field.label}
									icon={field.icon}
									label={field.label}
									options={field.options}
									className="mb-3"
								/>
							);
						case 'date':
							return (
								<div key={field.id} className="flex flex-col">
									<Label className="text-muted-foreground mb-1 text-sm font-medium">
										{field.label}
									</Label>
									<Input
										type="date"
										value={(values[field.id] as string) || ''}
										onChange={e => handleChange(field.id, e.target.value)}
										className="rounded-sm"
									/>
								</div>
							);
						default:
							return null;
					}
				})}
			</div>
		</div>
	);
};

export default GlobalFilter;
