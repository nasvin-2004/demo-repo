'use client';

import { useEffect, useState, useRef } from 'react';

export default function LoadingIndicator() {
	const [isLoading, setIsLoading] = useState(false);
	const timeoutRef = useRef<NodeJS.Timeout | null>(null);

	useEffect(() => {
		if (typeof document === 'undefined' || typeof window === 'undefined') return;

		// Listen for Astro View Transitions events
		const handleTransitionStart = () => {
			// Clear any pending timeout
			if (timeoutRef.current) {
				clearTimeout(timeoutRef.current);
				timeoutRef.current = null;
			}
			setIsLoading(true);
		};

		const handleTransitionEnd = () => {
			// Clear any pending timeout first
			if (timeoutRef.current) {
				clearTimeout(timeoutRef.current);
			}
			// Small delay to ensure smooth transition
			timeoutRef.current = setTimeout(() => {
				setIsLoading(false);
				timeoutRef.current = null;
			}, 100);
		};

		// Astro View Transitions events
		document.addEventListener('astro:before-preparation', handleTransitionStart);
		document.addEventListener('astro:after-swap', handleTransitionEnd);
		document.addEventListener('astro:page-load', handleTransitionEnd);

		return () => {
			document.removeEventListener('astro:before-preparation', handleTransitionStart);
			document.removeEventListener('astro:after-swap', handleTransitionEnd);
			document.removeEventListener('astro:page-load', handleTransitionEnd);
			// Cleanup timeout on unmount
			if (timeoutRef.current) {
				clearTimeout(timeoutRef.current);
			}
		};
	}, []);

	return (
		<div
			className={`fixed left-0 right-0 top-0 z-[10000] h-1 bg-transparent transition-opacity duration-200 ${
				isLoading ? 'opacity-100' : 'opacity-0'
			}`}>
			<div
				className={`h-full bg-[var(--brandColor)] transition-all duration-300 ${
					isLoading ? 'w-full' : 'w-0'
				}`}
				style={{
					animation: isLoading ? 'progress 2s ease-in-out infinite' : 'none',
				}}
			/>
		</div>
	);
}
