/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-console */
/**
 * Standardized error handling utilities for the QConnect application
 */

export interface ApiError {
	message: string;
	status?: number;
	code?: string;
	details?: any;
}

export interface ErrorResponse {
	success: false;
	error: ApiError;
}

/**
 * Standardized error handler for API calls
 */
export class ErrorHandler {
	/**
	 * Handle API errors with consistent formatting
	 */
	static handleApiError(error: any): ApiError {
		// Network error
		if (!error.response) {
			return {
				message: 'Network error. Please check your connection and try again.',
				code: 'NETWORK_ERROR',
			};
		}

		// HTTP error responses
		const { status, data } = error.response;

		return {
			message: data?.message || data?.error || this.getDefaultErrorMessage(status),
			status,
			code: data?.code,
			details: data?.details,
		};
	}

	/**
	 * Get default error messages for HTTP status codes
	 */
	private static getDefaultErrorMessage(status: number): string {
		switch (status) {
			case 400:
				return 'Invalid request. Please check your input and try again.';
			case 401:
				return 'Unauthorized. Please log in again.';
			case 403:
				return 'Access denied. You do not have permission to perform this action.';
			case 404:
				return 'Resource not found.';
			case 409:
				return 'Conflict. The resource already exists.';
			case 422:
				return 'Validation error. Please check your input.';
			case 429:
				return 'Too many requests. Please try again later.';
			case 500:
				return 'Internal server error. Please try again later.';
			case 502:
				return 'Bad gateway. The server is temporarily unavailable.';
			case 503:
				return 'Service unavailable. Please try again later.';
			default:
				return 'An unexpected error occurred. Please try again.';
		}
	}

	/**
	 * Log error for debugging (only in development)
	 */
	static logError(error: any, context?: string): void {
		if (import.meta.env.DEV) {
			console.group(`🚨 Error${context ? ` in ${context}` : ''}`);
			console.error('Error details:', error);
			console.error('Stack trace:', error.stack);
			console.groupEnd();
		}
	}

	/**
	 * Create a standardized error response
	 */
	static createErrorResponse(error: any, context?: string): ErrorResponse {
		this.logError(error, context);
		return {
			success: false,
			error: this.handleApiError(error),
		};
	}
}

/**
 * Higher-order function for async error handling
 */
export function withErrorHandling<T extends any[], R>(
	fn: (...args: T) => Promise<R>,
	context?: string,
) {
	return async (...args: T): Promise<R | ErrorResponse> => {
		try {
			return await fn(...args);
		} catch (error) {
			return ErrorHandler.createErrorResponse(error, context);
		}
	};
}

/**
 * Type guard to check if a response is an error
 */
export function isErrorResponse(response: any): response is ErrorResponse {
	return response && typeof response === 'object' && response.success === false;
}
