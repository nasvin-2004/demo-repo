import type { College, Address } from '@/services/college.service'; // adjust path if needed
/* ------------------------------------------------------ */
/* 🧱 ADDRESS MAPPER                                       */
/* ------------------------------------------------------ */
export const mapAddressFromBackend = (data: Address): Address => ({
	id: data.id,
	addressLine1: data.addressLine1,
	addressLine2: data.addressLine2,
	city: data.city,
	state: data.state,
	country: data.country,
	pincode: data.pincode,
	isPrimary: data.isPrimary,
});

/* ------------------------------------------------------ */
/* 🎓 COLLEGE MAPPER                                      */
/* ------------------------------------------------------ */

export interface WorkspaceBase {
	id: string;
	enterpriseName: string;
	name: string;
	description: string | null;
	websiteUrl: string | null;
	uniqueIdentifier: string;
	isActive: boolean;
	phoneNumber: string | null;
	phoneNumberCountryCode: string | null;
	email: string | null;
	logoUrl: string | null;
	type: 'GOVERNMENT' | 'AIDED' | 'PRIVATE' | 'SELF_FINANCED';

	ugcApproved: boolean;
	naacGrade: string;
	naacScore: number;
	nirfRanking: number | null;
	aicteApproved: boolean;
	nbaAccredited: boolean;
	autonomousStatus: boolean;
	accreditationValidTill: string | null;
	affliation: string;
	afflicationCode: string;

	Address: Address[];
}

export const mapCollegeFromBackend = (w: WorkspaceBase): College => ({
	collegeId: w.id,
	institutionName: w.enterpriseName,
	collegeName: w.name,
	collegeCode: w.uniqueIdentifier,
	description: w.description,
	websiteUrl: w.websiteUrl,
	email: w.email,
	phoneNumber: w.phoneNumber,
	phoneNumberCountryCode: w.phoneNumberCountryCode,
	collegeType: w.type,
	isActive: w.isActive,
	ugcApproved: w.ugcApproved,
	naacGrade: w.naacGrade,
	naacScore: w.naacScore,
	nirfRanking: w.nirfRanking,
	aicteApproved: w.aicteApproved,
	nbaAccredited: w.nbaAccredited,
	autonomousStatus: w.autonomousStatus,
	accreditationValidTill: w.accreditationValidTill,
	affliation: w.affliation,
	afflicationCode: w.afflicationCode,
	logoUrl: w.logoUrl,
	Address: (w.Address || []).map(mapAddressFromBackend),
});
