import { verifyModuleAction, type ModuleItem } from '@/stores/moduleStore';
import type { AstroCookies } from 'astro';
import { verifyToken, type LoginResponse, type Profile } from '@/services/auth.service';
// import { setLoginDataStateOnly, clearProfile } from '@/stores/profileStore';
import { clearProfile } from '@/stores/profileStore';

export interface ProtectResult {
	redirect?: { method: 'redirect' | 'rewrite'; path: string };
	modules: ModuleItem[];
	userData?: Profile;
	authData?: LoginResponse;
}

export async function protectPage(
	moduleName: string,
	cookies: AstroCookies,
): Promise<ProtectResult> {
	const token = cookies.get('token')?.value;
	if (!token) {
		return { redirect: { method: 'redirect', path: '/login' }, modules: [] }; // no login
	}

	const tokenResponse = await verifyToken(token);
	// console.log({tokenResponse});

	if (!tokenResponse.success || !tokenResponse.data) {
		clearProfile();
		return { redirect: { method: 'redirect', path: '/login' }, modules: [] }; // invalid token
	}

	// Don't set state during SSR, instead return the data to be passed to client
	const modules = tokenResponse.data.modules;
	if (moduleName === 'PUBLIC') {
		return {
			modules,
			userData: tokenResponse.data.user,
			authData: tokenResponse.data,
		};
	}
	const hasView = verifyModuleAction(moduleName, 'VIEW', modules);
	if (!hasView) {
		return { redirect: { method: 'rewrite', path: '/403' }, modules };
	}

	// const response = await api.get("/plan");

	const planItem = tokenResponse.data.plans?.find(p => p.module === moduleName);
	// const planItem = response.data.data?.find(p => p.module === moduleName);
	if (planItem && !planItem.access) {
		return { redirect: { method: 'redirect', path: '/billing' }, modules };
	}

	return {
		modules,
		userData: tokenResponse.data.user,
		authData: tokenResponse.data,
		// authData: { ...tokenResponse.data, plans: response.data},
	};
}
