import axios from 'axios';

const api = axios.create({
	baseURL: import.meta.env.PUBLIC_BACKEND_AUTH_SERVICE_URL,
	withCredentials: true,
	headers: {
		Accept: 'application/json',
		'Content-Type': 'application/json',
	},
});

// Add request interceptor for authentication
api.interceptors.request.use(
	config => {
		return config;
	},
	error => {
		return Promise.reject(error);
	},
);

// Add response interceptor for error handling
api.interceptors.response.use(
	response => response,
	error => {
		if (error.response?.status === 401) {
			// Handle unauthorized access
			if (typeof window !== 'undefined') {
				localStorage.removeItem('token');
				window.location.href = '/';
			}
		}
		return Promise.reject(error);
	},
);

export default api;
