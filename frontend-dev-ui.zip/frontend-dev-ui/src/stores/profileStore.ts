import { atom } from 'nanostores';
import { ErrorHandler } from '@/lib/error-handler';
import { getProfile } from '@/services';
import { $modules } from '@/stores/moduleStore';

export interface Profile {
	id: string;
	email: string;
	name: string;
	phoneNumber: string;
	role: string;
	roleId: string;
	workspaceId: string;
}

export const $profile = atom<Profile | null>(null);
export const $loadingProfile = atom<boolean>(false);
export const $auth = atom<boolean>(false);
export const $loginData = atom<Profile | null>(null);

export async function loadProfileData() {
	$loadingProfile.set(true);
	try {
		const response = await getProfile();
		if (response.success && response.data) {
			const profileData: Profile = {
				id: '',
				email: response.data.user.email,
				name: response.data.user.name,
				role: response.data.role.name,
				phoneNumber: response.data.user.phoneNumber,
				roleId: '',
				workspaceId: '',
			};
			$profile.set(profileData);
		} else {
			ErrorHandler.logError('Profile fetch failed:', response.message);
			$profile.set(null);
		}
	} catch (err) {
		ErrorHandler.logError(err, 'Fetching profile');
		$profile.set(null);
	} finally {
		$loadingProfile.set(false);
	}
}

export function clearProfile() {
	$profile.set(null);
	$auth.set(false);
	$loginData.set(null);
	$modules.set([]);

	// Clear localStorage and cookies
	if (typeof window !== 'undefined') {
		localStorage.removeItem('token');
		localStorage.removeItem('user');
		localStorage.removeItem('modules');
		localStorage.removeItem('auth');

		// Clear cookie
		document.cookie = 'token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
	}
}

export function setLoginData(
	profile: Profile,
	token: string,
	modules: { module: string; actions: string[] }[],
) {
	$loginData.set(profile);
	$auth.set(true);

	// Set modules in module store
	$modules.set(modules);

	// Store in localStorage for persistence (excluding token for security)
	if (typeof window !== 'undefined') {
		// Token is handled by httpOnly cookie from backend, not stored in localStorage
		localStorage.setItem('user', JSON.stringify(profile));
		localStorage.setItem('modules', JSON.stringify(modules));
		localStorage.setItem('auth', 'true');

		// Set cookie manually only in LOCAL environment
		const env = import.meta.env.PUBLIC_ENV || import.meta.env.MODE;
		if (env === 'LOCAL') {
			document.cookie = `token=${token}; path=/; max-age=${60 * 60 * 24 * 7}`; // 7 days
		}
	}
}

export function setLoginDataStateOnly(
	profile: Profile,
	modules: { module: string; actions: string[] }[],
) {
	$loginData.set(profile);
	$auth.set(true);
	$modules.set(modules);
}
