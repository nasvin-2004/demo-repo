import { atom } from 'nanostores';

export const $planAccess = atom<{ module: string; access: boolean }[]>([]);

export function setPlanAccess(data: { module: string; access: boolean }[]) {
	$planAccess.set(data);
}
