import { atom } from 'nanostores';
// import api from '@/lib/api';
import { ErrorHandler } from '@/lib/error-handler';
import { getRoleModules, type ModuleItems, type RoleResponse } from '@/services';

export type ModuleItem = { module: string; actions: string[] };

// Reactive store
export const $modules = atom<ModuleItem[]>([]);

/**
 * SSR fetch modules using token/cookie
 * Returns the fetched modules
 */

// export async function loadModulePermissions(token?: string): Promise<ModuleItem[]> {
// 	try {
// 		if (!token) return [];

// 		const response = await api.get('/role/me/modules', {
// 			headers: {
// 				'Content-Type': 'application/json',
// 				Authorization: `Bearer ${token}`,
// 			},
// 		});

// 		const modules: ModuleItem[] = response.data.data || [];
// 		$modules.set(modules);
// 		return modules;
// 	} catch (err) {
// 		ErrorHandler.logError(err, 'loadModulePermissions');
// 		$modules.set([]);
// 		return [];
// 	}
// }

export async function loadModulePermissions(token?: string): Promise<ModuleItems[]> {
	try {
		const res: RoleResponse<ModuleItems[]> = await getRoleModules(token);
		if (res.success && res.data) {
			$modules.set(res.data);
			return res.data;
		} else {
			$modules.set([]);
			ErrorHandler.logError('Module fetch failed:', res.message);
			return [];
		}
	} catch (err) {
		ErrorHandler.logError(err, 'Fetching modules');
		$modules.set([]);
		return [];
	}
}

/**
 * Check if a module has a specific action (VIEW, EDIT, etc.)
 */
export const verifyModuleAction = (
	moduleCode: string,
	action: string,
	modules?: ModuleItem[],
): boolean => {
	const list = modules ?? $modules.get();
	const mod = list.find(m => m.module === moduleCode);
	if (!mod) return false;
	return mod.actions.map(a => a.toUpperCase()).includes(action.toUpperCase());
};
