import api from '@/lib/api';
import { ErrorHandler, type ApiError } from '@/lib/error-handler';

export interface DepartmentResponse<T> {
	success: boolean;
	data?: T;
	message?: string;
	error?: ApiError;
}

export interface CreateDepartmentPayload {
	programId?: string;
	programName?: string;
	departmentName: string;
}

export interface EditDepartmentPayload {
	departmentId: string;
	programId?: string;
	programName?: string;
	departmentName: string;
}

export interface DepartmentData {
	departmentId: string;
	departmentName: string;
	programId: string;
	programName: string;
}

export interface GetDepartmentsParams {
	programId?: string;
	search?: string;
	page?: number;
	limit?: number;
}

/**
 * Fetch all departments with optional filters
 */
export const getDepartments = async (
	params?: GetDepartmentsParams,
): Promise<DepartmentResponse<DepartmentData[]>> => {
	try {
		const res = await api.get('/department', { params });
		return {
			success: true,
			data: res.data.data || [],
			message: 'Departments fetched successfully',
		};
	} catch (err) {
		const errorResponse = ErrorHandler.createErrorResponse(err, 'Fetching departments');
		return {
			success: false,
			data: [],
			message: errorResponse.error?.message || 'Failed to fetch departments',
			error: errorResponse.error,
		};
	}
};

/**
 * Create a new department
 * Can create with existing programId OR new programName
 */
export const createDepartment = async (
	payload: CreateDepartmentPayload,
): Promise<DepartmentResponse<DepartmentData>> => {
	try {
		const res = await api.post('/department', payload);
		return {
			success: res.data.success,
			data: res.data.data,
			message: res.data.message || 'Department created successfully',
		};
	} catch (err) {
		const errorResponse = ErrorHandler.createErrorResponse(err, 'Creating department');
		return {
			success: false,
			message: errorResponse.error?.message || 'Failed to create department',
			error: errorResponse.error,
		};
	}
};

/**
 * Edit an existing department
 */
export const editDepartment = async (
	payload: EditDepartmentPayload,
): Promise<DepartmentResponse<DepartmentData>> => {
	try {
		const res = await api.put('/department', payload);
		return {
			success: res.data.success,
			data: res.data.data,
			message: res.data.message || 'Department updated successfully',
		};
	} catch (err) {
		const errorResponse = ErrorHandler.createErrorResponse(err, 'Updating department');
		return {
			success: false,
			message: errorResponse.error?.message || 'Failed to update department',
			error: errorResponse.error,
		};
	}
};

/**
 * Delete a department (soft delete)
 */
export const deleteDepartment = async (departmentId: string): Promise<DepartmentResponse<null>> => {
	try {
		const res = await api.delete(`/department/${departmentId}`);
		return {
			success: res.data.success ?? false,
			message: res.data.message || 'Department deleted successfully',
		};
	} catch (err) {
		const errorResponse = ErrorHandler.createErrorResponse(err, 'Deleting department');
		return {
			success: false,
			message: errorResponse.error?.message || 'Failed to delete department',
			error: errorResponse.error,
		};
	}
};
