import type { FilterValue } from '@/components/common/Filter';
import api from '@/lib/api';
import { ErrorHandler, type ApiError } from '@/lib/error-handler';

export type ModuleItems = { module: string; actions: string[] };

export interface RolePayload {
	roleName: string;
	permissions: { module: string; actions: string[] }[];
}
export interface RoleResponse<T> {
	success: boolean;
	data?: T;
	message?: string;
	error?: ApiError;
}

export interface SimpleRole {
	roleId: string;
	name: string;
}

export interface Role {
	id: string;
	role: string;
	members: number;
	activeCount: number;
	roleId: string;
	inactiveCount: number;
	isSystemRole: boolean;
	readonly [key: string]: FilterValue;
}

export const getRoleModules = async (token?: string): Promise<RoleResponse<ModuleItems[]>> => {
	try {
		if (!token) {
			return {
				success: false,
				data: [],
				message: 'No token provided',
			};
		}

		const res = await api.get('/role/me/modules', {
			headers: {
				'Content-Type': 'application/json',
				Authorization: `Bearer ${token}`,
			},
		});

		const modules: ModuleItems[] = res.data.data || [];
		return {
			success: true,
			data: modules,
			message: 'Modules fetched successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Fetching role modules');
		return {
			success: false,
			data: [],
			message: 'Failed to fetch modules',
			error: err.error,
		};
	}
};

export const getModulesWithActions = async (): Promise<RoleResponse<ModuleItems[]>> => {
	try {
		const res = await api.get('/role/modules-with-actions');
		return {
			success: true,
			data: res.data.data || [],
			message: 'Modules fetched successfully',
		};
	} catch (err) {
		const errorResponse = ErrorHandler.createErrorResponse(err, 'Fetching modules');
		return {
			success: false,
			message: 'Failed to fetch modules',
			error: errorResponse.error,
		};
	}
};

export const createRole = async (payload: RolePayload): Promise<RoleResponse<null>> => {
	try {
		const res = await api.post('/role/create', payload);
		return {
			success: res.data.success,
			data: res.data.data,
			message: res.data.message || 'Role created successfully',
		};
	} catch (err) {
		const errorResponse = ErrorHandler.createErrorResponse(err, 'Creating role');
		return {
			success: false,
			message: 'Failed to create role',
			error: errorResponse.error,
		};
	}
};

export const getRolePermissions = async (roleId: string): Promise<RoleResponse<ModuleItems[]>> => {
	try {
		const res = await api.get(`/role/${roleId}/modules-with-actions`);
		return {
			success: true,
			data: res.data.data || [],
			message: 'Role permissions fetched successfully',
		};
	} catch (err) {
		const errorResponse = ErrorHandler.createErrorResponse(err, 'Fetching role permissions');
		return {
			success: false,
			message: 'Failed to fetch role permissions',
			error: errorResponse.error,
		};
	}
};

export const updateRolePermissions = async (
	roleId: string,
	payload: RolePayload,
): Promise<RoleResponse<null>> => {
	try {
		const res = await api.post(`/role/${roleId}/update-permissions`, payload);
		return {
			success: res.data.success,
			data: res.data.data,
			message: res.data.message || 'Role updated successfully',
		};
	} catch (err) {
		const errorResponse = ErrorHandler.createErrorResponse(err, 'Updating role');
		return {
			success: false,
			message: 'Failed to update role',
			error: errorResponse.error,
		};
	}
};

export async function getRoles(): Promise<Role[]> {
	const response = await api.get<{ success: boolean; data: Role[] }>('/role/roles');
	if (!response.data.success) return [];
	return response.data.data;
}

export async function deleteRole(id: string): Promise<boolean> {
	const response = await api.delete(`/role/${id}`);
	return response.data.success ?? false;
}

export const getRolesForUser = async (): Promise<RoleResponse<SimpleRole[]>> => {
	try {
		const res = await api.get('/role/forUser');
		return { success: true, data: res.data.data, message: 'Roles fetched successfully' };
	} catch (err) {
		const errorResponse = ErrorHandler.createErrorResponse(err, 'Fetching roles for user');
		return { success: false, message: 'Failed to fetch roles', error: errorResponse.error };
	}
};
