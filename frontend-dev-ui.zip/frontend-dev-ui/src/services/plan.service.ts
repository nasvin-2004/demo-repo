import api from '@/lib/api';
import { ErrorHandler, type ApiError } from '@/lib/error-handler';

export interface PlanFeature {
	id: string;
	planId: string;
	planIdentifierId: string;
	valueInt: number;
	valueBool: boolean;
	identifier: {
		id: string;
		key: string;
		type: 'CREDIT' | 'ACCESS';
		displayName: string | null;
		description: string | null;
	};
}

export interface Plan {
	id: string;
	name: string;
	type: 'MAIN' | 'ADDON';
	description: string | null;
	priceMonthly: number | null;
	priceYearly: number | null;
	createdAt: string;
	updatedAt: string;
	features: PlanFeature[];
}

export interface WorkspaceSubscription {
	id: string;
	workspaceId: string;
	planId: string;
	planType: 'MAIN' | 'ADDON';
	active: boolean;
	startsAt: string;
	endsAt: string | null;
	createdAt: string;
	updatedAt: string;
	plan: {
		id: string;
		name: string;
		type: 'MAIN' | 'ADDON';
		description: string | null;
		priceMonthly: number | null;
		priceYearly: number | null;
		features?: PlanFeature[];
	};
	workspace: {
		id: string;
		name: string;
	};
}

export interface PlanResponse<T> {
	success: boolean;
	data?: T;
	message?: string;
	error?: ApiError;
}

export const getPlans = async (): Promise<PlanResponse<Plan[]>> => {
	try {
		const response = await api.get('/plan');
		return {
			success: true,
			data: response.data.data,
			message: response.data.message || 'Plans fetched successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Get plans');
		return {
			success: false,
			data: [],
			message: 'Failed to fetch plans',
			error: err.error,
		};
	}
};

export const getWorkspaceSubscriptions = async (): Promise<
	PlanResponse<WorkspaceSubscription[]>
> => {
	try {
		const response = await api.get('/plan/workspace-subscriptions');
		return {
			success: true,
			data: response.data.data,
			message: response.data.message || 'Subscriptions fetched successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Get workspace subscriptions');
		return {
			success: false,
			data: [],
			message: 'Failed to fetch workspace subscriptions',
			error: err.error,
		};
	}
};

export const getCurrentWorkspaceActivePlan = async (): Promise<
	PlanResponse<WorkspaceSubscription | null>
> => {
	try {
		const response = await api.get('/plan/current-active-plan');
		return {
			success: true,
			data: response.data.data,
			message: response.data.message || 'Current active plan fetched successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Get current workspace active plan');
		return {
			success: false,
			data: null,
			message: 'Failed to fetch current active plan',
			error: err.error,
		};
	}
};
