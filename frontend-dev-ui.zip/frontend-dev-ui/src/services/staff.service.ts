import api from '@/lib/api';
import { ErrorHandler, type ApiError } from '@/lib/error-handler';

export interface ApiResponse<T> {
	success: boolean;
	data?: T;
	message?: string;
	error?: ApiError;
}

export type Staff = {
	userId: string;
	userName: string;
	email: string;
	phoneNumber?: string;
	roleId?: string;
	role?: string;
	status: 'ACTIVE' | 'INACTIVE' | 'PENDING';
	departments?: {
		departmentId: string;
		department: string;
		programId?: string | null;
		programName?: string | null;
	}[];
};

export type GetStaffsParams = {
	page?: number;
	limit?: number;
	search?: string;
	status?: string;
	departmentId?: string;
	roleId?: string;
	workspaceId?: string;
};

export const getStaffs = async (params: GetStaffsParams) => {
	const response = await api.get('/staff', { params });
	return response.data;
};

export const addStaff = async (payload: {
	userName: string;
	email: string;
	phoneNumber?: string;

	roleId?: string;
	departments: { departmentId: string; department: string }[];
}): Promise<ApiResponse<string>> => {
	try {
		const res = await api.post('/staff', payload);
		return {
			success: true,
			data: res.data,
			message: 'Staff added successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Adding staff');
		return { success: false, error: err.error, message: 'Failed to add staff' };
	}
};

export const updateStaff = async (payload: {
	userId: string;
	userName: string;
	email: string;
	roleId?: string;
	phoneNumber?: string;
	departments: { departmentId: string; department: string }[];
}): Promise<ApiResponse<string>> => {
	try {
		const res = await api.put('/staff', payload);
		return {
			success: true,
			data: res.data,
			message: 'Staff updated successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Updating staff');
		return { success: false, error: err.error, message: 'Failed to update staff' };
	}
};

export const getRolesForStaff = async () => {
	const response = await api.get('/role/forUser');
	return response;
};
