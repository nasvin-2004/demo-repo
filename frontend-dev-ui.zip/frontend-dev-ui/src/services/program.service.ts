import api from '@/lib/api';
import { ErrorHandler, type ApiError } from '@/lib/error-handler';

// -------------------------
// Interfaces
// -------------------------
export interface CreateProgramPayload {
	programName: string;
}

export interface EditProgramPayload {
	programId: string;
	programName: string;
}

export interface ProgramData {
	programId: string;
	programName: string;
	isDefault?: boolean;
}

export interface ProgramResponse<T> {
	success: boolean;
	data?: T;
	message?: string;
	error?: ApiError;
}

// -------------------------
// Create a new program (POST)
// -------------------------
export const createProgram = async (
	payload: CreateProgramPayload,
): Promise<ProgramResponse<ProgramData>> => {
	try {
		const res = await api.post('/program', payload);
		return {
			success: res.data.success,
			data: res.data.data,
			message: res.data.message || 'Program created successfully',
		};
	} catch (err) {
		const errorResponse = ErrorHandler.createErrorResponse(err, 'Creating program');
		return {
			success: false,
			message: errorResponse.error?.message || 'Failed to create program',
			error: errorResponse.error,
		};
	}
};
// Accepts params, uses Axios params for querystring
export const getPrograms = async (params?: {
	search?: string;
}): Promise<ProgramResponse<ProgramData[]>> => {
	try {
		const res = await api.get('/program', { params });
		return {
			success: res.data.success ?? true,
			data: res.data.data || [],
			message: res.data.message || 'Programs fetched successfully',
		};
	} catch (err) {
		const errorResponse = ErrorHandler.createErrorResponse(err, 'Fetching programs');
		return {
			success: false,
			data: [],
			message: errorResponse.error?.message || 'Failed to fetch programs',
			error: errorResponse.error,
		};
	}
};

// -------------------------
// Edit an existing program (PUT)
// -------------------------
export const editProgram = async (
	payload: EditProgramPayload,
): Promise<ProgramResponse<ProgramData>> => {
	try {
		const res = await api.put('/program', payload);
		return {
			success: res.data.success,
			data: res.data.data,
			message: res.data.message || 'Program updated successfully',
		};
	} catch (err) {
		const errorResponse = ErrorHandler.createErrorResponse(err, 'Updating program');
		return {
			success: false,
			message: errorResponse.error?.message || 'Failed to update program',
			error: errorResponse.error,
		};
	}
};

// -------------------------
// Delete a program (DELETE /:programId)
// -------------------------
export const deleteProgram = async (programId: string): Promise<ProgramResponse<null>> => {
	try {
		const res = await api.delete(`/program/${programId}`);
		return {
			success: res.data.success ?? true,
			message: res.data.message || 'Program deleted successfully',
		};
	} catch (err) {
		const errorResponse = ErrorHandler.createErrorResponse(err, 'Deleting program');
		return {
			success: false,
			message: errorResponse.error?.message || 'Failed to delete program',
			error: errorResponse.error,
		};
	}
};
