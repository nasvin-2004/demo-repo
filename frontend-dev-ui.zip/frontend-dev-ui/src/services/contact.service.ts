import type { FilterValue } from '@/components/common/Filter';
import api from '@/lib/api';
import { ErrorHandler, type ApiError } from '@/lib/error-handler';

export interface ContactPayload {
	name: string;
	email: string;
	phone?: string;
	message: string;
}

export interface ContactResponse {
	success: boolean;
	data?: FilterValue;
	message?: string;
	error?: ApiError;
}

export const submitContactForm = async (payload: ContactPayload): Promise<ContactResponse> => {
	try {
		const res = await api.post('/contact/', payload);
		return res.data;
	} catch (error) {
		const errorResponse = ErrorHandler.createErrorResponse(error, 'ContactForm submission');
		return {
			success: false,
			error: errorResponse.error,
		};
	}
};
