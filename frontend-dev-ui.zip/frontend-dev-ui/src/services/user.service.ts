import api from '@/lib/api';
import { ErrorHandler, type ApiError } from '@/lib/error-handler';

export interface ApiResponse<T> {
	success: boolean;
	data?: T;
	message?: string;
	error?: ApiError;
}

export type User = {
	userId: string;
	userName: string;
	departments?: { departmentId: string; department: string }[];
	email: string;
	phoneNumber?: string;
	role: string;
	roleId: string;
	status: 'ACTIVE' | 'INACTIVE' | 'PENDING';
};

type GetUsersResponse = {
	users: User[];
	meta: {
		page: number;
		limit: number;
		total: number;
		totalPages: number;
	};
};

interface GetUsersParams {
	page?: number;
	limit?: number;
	roleId: string;
	search?: string;
	status?: string;
}

export const getUsers = async (params?: GetUsersParams): Promise<ApiResponse<GetUsersResponse>> => {
	try {
		const res = await api.get('/user', { params });
		const data: GetUsersResponse = res.data?.data || {
			users: [],
			meta: { page: 1, limit: 10, total: 0, totalPages: 1 },
		};
		return {
			success: true,
			data,
			message: res.data?.message || 'Users fetched successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Fetching users');
		return {
			success: false,
			data: { users: [], meta: { page: 1, limit: 10, total: 0, totalPages: 1 } },
			message: 'Failed to fetch users',
			error: err.error,
		};
	}
};

/* Add user with multiple departmentIds */
export const addUser = async (payload: {
	userName: string;
	email: string;
	roleId: string;
	phoneNumber?: string;
}): Promise<ApiResponse<string>> => {
	try {
		const res = await api.post('/user', payload);
		return {
			success: true,
			data: res.data,
			message: 'User added successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Adding user');
		return { success: false, error: err.error, message: 'Failed to add user' };
	}
};

/* Update user with multiple departmentIds */
export const updateUser = async (payload: {
	userId: string;
	userName: string;
	email: string;
	phoneNumber?: string;
	roleId: string;
}): Promise<ApiResponse<string>> => {
	try {
		const res = await api.put('/user', payload);
		return {
			success: true,
			data: res.data,
			message: 'User updated successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Updating user');
		return { success: false, error: err.error, message: 'Failed to update user' };
	}
};

/* Update user status */
export const updateUserStatus = async (payload: {
	userId: string;
	status: 'ACTIVE' | 'INACTIVE';
}): Promise<ApiResponse<string>> => {
	try {
		const res = await api.put('/user/status', payload);
		return {
			success: true,
			data: res.data,
			message: `User status updated to ${payload.status}`,
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Updating user status');
		return { success: false, error: err.error, message: 'Failed to update user status' };
	}
};
