import api from '@/lib/api';
import { ErrorHandler, type ApiError } from '@/lib/error-handler';

export interface LogoutResponse {
	success: boolean;
	message: string;
	error?: ApiError;
}

export interface Profiles {
	user: {
		name: string;
		email: string;
		emailVerified: boolean;
		phoneNumber: string;
	};
	role: {
		name: string;
	};
}

export interface Profile {
	id: string;
	email: string;
	name: string;
	roleId: string;
	workspaceId: string;
}

export interface LoginResponse {
	token: string;
	user: Profile;
	modules: {
		module: string;
		actions: string[];
	}[];
	plans: {
		module: string;
		access: boolean;
	}[];
}

export interface AuthResponse<T> {
	success: boolean;
	data?: T;
	message?: string;
	error?: ApiError;
}

export const logoutUser = async (): Promise<LogoutResponse> => {
	try {
		await api.get('/auth/logout');
		return {
			success: true,
			message: 'User logged out successfully',
		};
	} catch (error) {
		const errorResponse = ErrorHandler.createErrorResponse(error, 'User logout');
		return {
			success: false,
			message: 'Failed to log out user',
			error: errorResponse.error,
		};
	}
};

export const loginWithGoogle = async (token: string): Promise<AuthResponse<LoginResponse>> => {
	try {
		const response = await api.post('/auth/loginWithGoogle', { token });
		return {
			success: true,
			data: response.data,
			message: 'Google login successful',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Google login');
		return {
			success: false,
			message: 'Failed to login with Google',
			error: err.error,
		};
	}
};

export const getProfile = async (): Promise<AuthResponse<Profiles>> => {
	try {
		const res = await api.get('/auth/profile');

		return {
			success: true,
			data: res.data.profile || null,
			message: 'Profile fetched successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Fetching profile');
		return {
			success: false,
			message: 'Failed to fetch profile',
			error: err.error,
		};
	}
};

export const verifyToken = async (token: string): Promise<AuthResponse<LoginResponse>> => {
	try {
		const headers: Record<string, string> = {
			token: token,
		};
		const response = await api.get('/auth/verify', { headers });
		return {
			success: true,
			data: response.data,
			message: 'Token verified successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Token verification');
		return {
			success: false,
			message: 'Token verification failed',
			error: err.error,
		};
	}
};

export const getPublicKey = async (): Promise<AuthResponse<{ publicKey: string }>> => {
	try {
		const response = await api.get('/auth/public-key');
		return {
			success: true,
			data: response.data,
			message: 'Public key retrieved successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Get public key');
		return {
			success: false,
			message: 'Failed to retrieve public key',
			error: err.error,
		};
	}
};

export const loginWithEmailPassword = async (
	email: string,
	encryptedPassword: string,
): Promise<AuthResponse<LoginResponse>> => {
	try {
		const response = await api.post('/auth/login', {
			email,
			encryptedPassword,
		});
		return {
			success: true,
			data: response.data,
			message: 'Login successful',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Email/password login');
		return {
			success: false,
			message: 'Login failed',
			error: err.error,
		};
	}
};

export const setPassword = async (
	token: string,
	encryptedPassword: string,
): Promise<AuthResponse<{ message: string }>> => {
	try {
		const response = await api.post('/auth/set-password', {
			token,
			encryptedPassword,
		});
		return {
			success: true,
			data: response.data,
			message: 'Password set successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Set password');
		return {
			success: false,
			message: 'Failed to set password',
			error: err.error,
		};
	}
};

export const forgotPassword = async (email: string): Promise<AuthResponse<{ message: string }>> => {
	try {
		const response = await api.post('/auth/forgot-password', {
			email,
		});
		return {
			success: true,
			data: response.data,
			message: response.data.message || 'Password reset link sent successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Forgot password');
		return {
			success: false,
			message: 'Failed to send password reset link',
			error: err.error,
		};
	}
};

export const validateResetToken = async (
	token: string,
): Promise<AuthResponse<{ valid: boolean; message: string }>> => {
	try {
		const response = await api.get('/auth/validate-reset-token', {
			params: { token },
		});
		return {
			success: true,
			data: response.data,
			message: response.data.message || 'Token validation completed',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Validate reset token');
		return {
			success: false,
			data: { valid: false, message: 'Token validation failed' },
			message: 'Failed to validate token',
			error: err.error,
		};
	}
};

export const updateProfile = async (phoneNumber: string): Promise<AuthResponse<null>> => {
	try {
		const response = await api.put('/auth/profile', {
			phoneNumber,
		});
		return {
			success: true,
			data: response.data,
			message: response.data.message || 'Phone number updated successfully',
		};
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Update phone number');
		return {
			success: false,
			message: 'Failed to update phone number',
			error: err.error,
		};
	}
};
