import api from '@/lib/api';
import { ErrorHandler, type ApiError } from '@/lib/error-handler';

export type Student = {
	studentId: string;
	userId: string;
	name: string;
	email: string;
	phoneNumber: string;
	rollNumber: string;
	program: string;
	department: string;
	departmentId: string;
	section: string;
	graduationYear: number;
	batch: string;
	admissionNumber: string;
	status: 'ACTIVE' | 'INACTIVE' | 'PENDING';
};

export interface StudentResponse<T> {
	success: boolean;
	data?: T;
	message?: string;
	error?: ApiError;
	limitReached?: boolean;
}

export const getStudents = async (params?: {
	page?: number;
	limit?: number;
	search?: string;
	departmentId?: string;
	status?: string;
}): Promise<
	StudentResponse<{
		students: Student[];
		meta: {
			total: number;
			page: number;
			limit: number;
			totalPages: number;
		};
	}>
> => {
	try {
		const res = await api.get('/student', { params });

		const { students = [], meta = { total: 0, page: 1, limit: 10, totalPages: 1 } } =
			res.data?.data || {};

		return {
			success: true,
			data: { students, meta },
			message: res.data?.message || 'Students fetched successfully',
		};
	} catch (error) {
		const errorResponse = ErrorHandler.createErrorResponse(error, 'Fetching students');
		return {
			success: false,
			data: { students: [], meta: { total: 0, page: 1, limit: 10, totalPages: 1 } },
			message: 'Failed to fetch students',
			error: errorResponse.error,
		};
	}
};

export const createStudent = async (
	payload: Omit<Student, 'studentId' | 'userId' | 'status' | 'department' | 'program'>,
): Promise<StudentResponse<null>> => {
	try {
		const res = await api.post('/student', payload);
		return {
			success: true,
			message: res.data?.message || 'Student added successfully',
			limitReached: res.data?.limitReached,
		};
	} catch (error) {
		const errorResponse = ErrorHandler.createErrorResponse(error, 'Creating student');
		return { success: false, message: 'Failed to add student', error: errorResponse.error };
	}
};

export const updateStudent = async (
	payload: Omit<Student, 'status' | 'department' | 'program'>,
): Promise<StudentResponse<null>> => {
	try {
		const res = await api.put('/student', payload);
		return { success: true, message: res.data?.message || 'Student updated successfully' };
	} catch (error) {
		const errorResponse = ErrorHandler.createErrorResponse(error, 'Updating student');
		return { success: false, message: 'Failed to update student', error: errorResponse.error };
	}
};

export const deleteStudent = async (studentId: string): Promise<StudentResponse<null>> => {
	try {
		const res = await api.delete(`/student/${studentId}`);
		return { success: true, message: res.data?.message || 'Student deleted successfully' };
	} catch (error) {
		const errorResponse = ErrorHandler.createErrorResponse(error, 'Deleting student');
		return { success: false, message: 'Failed to delete student', error: errorResponse.error };
	}
};

export const getProgramsWithDepartments = async (): Promise<
	StudentResponse<
		{ programId: string; programName: string; departments: { id: string; name: string }[] }[]
	>
> => {
	try {
		const res = await api.get('/student/programDepartments');
		const programs = res.data?.data || [];
		return {
			success: true,
			data: programs,
			message: 'Programs with departments fetched successfully',
		};
	} catch (error) {
		const errorResponse = ErrorHandler.createErrorResponse(
			error,
			'Fetching program-department data',
		);
		return {
			success: false,
			message: 'Failed to fetch program-department data',
			error: errorResponse.error,
		};
	}
};
