export { submitContactForm, type ContactPayload, type ContactResponse } from './contact.service';

// Export user service functions and types
export { getUsers, addUser, updateUser, updateUserStatus } from './user.service';

// Existing staff service exports
export { getStaffs, addStaff, updateStaff, type Staff } from './staff.service';

export {
	getStudents,
	createStudent,
	updateStudent,
	deleteStudent,
	getProgramsWithDepartments,
	type Student,
} from './student.service';

export { getProfile, type Profiles, logoutUser, type LogoutResponse } from './auth.service';

export {
	getRoleModules,
	getModulesWithActions,
	getRolePermissions,
	updateRolePermissions,
	deleteRole,
	createRole,
	getRoles,
	getRolesForUser,
	type RolePayload,
	type ModuleItems,
	type RoleResponse,
	type SimpleRole,
} from './role.service';

export {
	getDepartments,
	createDepartment,
	editDepartment,
	deleteDepartment,
	type DepartmentData,
	type CreateDepartmentPayload,
	type EditDepartmentPayload,
	type DepartmentResponse,
	type GetDepartmentsParams,
} from './department.service';
