import api from '@/lib/api';
import { ErrorHandler, type ApiError } from '@/lib/error-handler';
import { mapCollegeFromBackend } from '@/lib/mapper';

export interface Address {
	id?: string;
	addressLine1: string;
	addressLine2?: string;
	city: string;
	state: string;
	country: string;
	pincode: string;
	isPrimary?: boolean;
}
export interface College {
	collegeId: string;
	institutionName: string; // institutionId
	collegeName: string;
	collegeCode: string;
	description: string | null;
	websiteUrl: string | null;
	logoUrl: string | null;
	email: string | null;
	phoneNumber: string | null;
	phoneNumberCountryCode: string | null;
	collegeType: 'GOVERNMENT' | 'AIDED' | 'PRIVATE' | 'SELF_FINANCED';
	isActive: boolean;
	ugcApproved: boolean;
	naacGrade: string;
	naacScore: number;
	nirfRanking: number | null;
	aicteApproved: boolean;
	nbaAccredited: boolean;
	autonomousStatus: boolean;
	accreditationValidTill: string | null;
	affliation: string | null;
	afflicationCode: string | null;
	Address: Address[];
}
export const CollegeTypeCase: Record<string, string> = {
	GOVERNMENT: 'Government',
	AIDED: 'Aided',
	PRIVATE: 'Private',
	SELF_FINANCED: 'Self Financed',
};
export interface Institution {
	institutionId: string;
	institutionName: string;
	institutionCode: string | null;
	institutionType: string;
	primaryContactName: string;
	primaryEmail: string;
	primaryPhone: string;
	primaryPhoneCountryCode: string;
	Address: Address[];
	logoUrl: string | null;
	establishedYear: number | null;
	websiteUrl: string | null;
	description: string;
	status: 'ACTIVE' | 'INACTIVE' | 'SUSPENDED';
	onboardStatus: 'COMPLETED' | 'IN_PROGRESS' | 'PENDING';
}
export interface ApiResponse<T> {
	success: boolean;
	data?: T;
	message?: string;
	error?: ApiError;
}
export const fetchCollege = async (): Promise<ApiResponse<College>> => {
	try {
		const res = await api.get('/workspace');
		const w = res.data?.data;
		if (!w) return { success: false, message: 'No College found' };
		const formatted = mapCollegeFromBackend(w);
		return { success: true, data: formatted, message: 'College fetched successfully' };
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Fetching College by ID');
		return { success: false, error: err.error, message: 'Failed to fetch College' };
	}
};
export const getInstitutionsSimple = async (): Promise<
	ApiResponse<{ enterpriseId: string; enterpriseName: string }[]>
> => {
	try {
		const res = await api.get('/enterprise/simple');
		const data = res.data?.data;
		return { success: true, data: data, message: 'Institutions fetched successfully' };
	} catch (error) {
		const err = ErrorHandler.createErrorResponse(error, 'Fetching Institutions');
		return { success: false, error: err.error, message: 'Failed to fetch Institutions' };
	}
};
