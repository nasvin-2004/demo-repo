/// <reference types="astro/client" />

interface ImportMetaEnv {
	readonly PUBLIC_BACKEND_AUTH_SERVICE_URL?: string;
	readonly PUBLIC_ENV?: string;
	readonly PUBLIC_GOOGLE_CLIENT_ID?: string;
}

interface ImportMeta {
	readonly env: ImportMetaEnv;
}
